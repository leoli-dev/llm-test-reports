# Independent review: arcade-F (tank) and story-F (story)

- Reviewer: Claude Opus 5.5 (`claude-opus-5-5`), working alone as an Orca worker (task_e984dc069d96)
- Date: 2026-11-26
- Browser: Thorium 156.0.8078.28 (`/Applications/Thorium.app/Contents/MacOS/Thorium`), headless, driven by Playwright from `~/Code/canada-fire-calculator/node_modules/playwright`. WebGL 1.0 was confirmed available in this Thorium build before the tank was probed.
- Viewports: desktop 1440 × 900 and mobile 390 × 844 (touch, DPR 2). Extra checks on the story at 1280 × 720, 1024 × 640 and 844 × 390.
- Scope: the frozen submissions in `review/arcade-F` and `review/story-F`, judged against the original `prompts/tank.txt` and `prompts/story.txt`, with the categories in `harness/evaluation-plan.md`. The formal precursor runs produced no files (`review/evidence/*-formal-source.json`: `files: []`, `has_entry_point: false`), so only these two supplemental artifacts are scored. No Codex scores, inference statistics or historical results were used.
- Integrity: before testing, I diffed every file served on :18421 and :18422 against `review/arcade-F` and `review/story-F`. All files were byte-identical. On :18423, only `js/levels.js` differs, by the single line `if (Array.isArray(mapStr)) mapStr = mapStr.join('\n');`. I made no source edits. My tank probe adds a runtime *observer* through `page.evaluate`. It wraps the global `Renderer.*` draw calls to record their arguments, such as player and enemy positions, without changing behaviour.

## Score summary

| Submission | Code /10 | UI /10 |
| --- | --- | --- |
| **arcade-F (tank, original, primary)** | **2** | **2** |
| story-F (story) | 7 | 7 |
| arcade-F + one-line diagnostic patch (:18423) | not scored, diagnostic only | not scored, diagnostic only |

### Category scores (0 = absent or broken, 1 = partial, 2 = met)

| Category | arcade-F | story-F |
| --- | --- | --- |
| Code: build/brief fit | 1 | 1 |
| Code: core behavior | 0 | 2 |
| Code: edge cases | 0 | 1 |
| Code: maintainability | 1 | 2 |
| Code: tests/reproducibility | 0 | 1 |
| **Code total** | **2** | **7** |
| UI: visual coherence | 1 | 2 |
| UI: readability | 1 | 1 |
| UI: interaction feedback | 0 | 2 |
| UI: keyboard/mobile use | 0 | 1 |
| UI: task-specific depth/finish | 0 | 1 |
| **UI total** | **2** | **7** |

---

## 1. arcade-F: "IRON RALLY" (primary)

### Blocker, confirmed firsthand: DEPLOY never starts the game
- **Source cause.** `js/levels.js:10-111` defines `MAPS` as arrays of row strings. `parse()` at `js/levels.js:114` calls `mapStr.trim()`, a string method. `Level.build()` therefore throws `TypeError: mapStr.trim is not a function` every time it runs.
- **First failure point.** `Game.bootstrap()` calls `Level.build(0)` at `js/game.js:657` *before* `requestAnimationFrame(frame)` at `js/game.js:662`. The render loop therefore never starts, and the WebGL canvas stays empty behind the title.
- **DEPLOY and Enter.** Both reach `newGame()`, then `loadLevel()`, then `Level.build()`, and throw again. `state` never becomes `'playing'`, and the title overlay is never hidden.
- **What Thorium showed (desktop and mobile).**
  - 4 page errors per view, all `mapStr.trim is not a function`: one at load, one on the DEPLOY click or tap, one on Enter, and a later repeat.
  - The draw-call observer counted **0 frames** over about 95 s on desktop.
  - The title screen stayed visible after DEPLOY, after Enter, after 6 s of driving keys, after held fire, and over a 60 s idle window.
  - The HUD stayed at score 0, wave 1, enemies 0. The touch MOVE and FIRE pads appear on mobile but do nothing.
  - There were no external requests. The only 404 was the browser's favicon request.
- Screens: `claude-screens/tank-original-desktop-menu.png`, `tank-original-desktop-after-deploy.png`, `tank-original-mobile-after-deploy.png`.

### Further code defects (from source review; several confirmed through the diagnostic build)
1. **Undefined arena size.** `global.LEVEL_SIZE` is used in `js/game.js:6` and `js/levels.js:162` but is never defined (grep shows no assignment). `SIZE` and `HALF` become `NaN`. As a result, `UTIL.clamp(v, NaN, NaN)` is a no-op, tanks have no arena bounds, and the shell edge test (`nx < -HALF+0.5 …`) is never true.
2. **Swapped enemy-fire arguments.** `enemyFire` (`js/game.js:144`) calls `fireShell(x, 0.28, z, 'enemy', …)` against the signature `fireShell(x, z, ang, owner, …)`. Enemy shells are created at world z = 0.28, and their heading is set to the tank's z coordinate.
3. **Movement mapping rotated 90°.** `atan2(ax, -ay)` (`js/game.js:325`) maps W/Up to heading 0 (+x, screen right), D to +z (screen down), and so on.
4. **Core drawn in the wrong place.** `Renderer.drawCore` always draws at (0, 0), while collision and the base-damage test use the map's `F` cell (`level.core`). On maps 2–4 that cell is far from the origin, so the visible core and the hittable core separate.
5. **No navigation.** Chasers steer straight at the player and stop on walls. There is no pathing around obstacles.
6. **Map data inconsistent with the parser.** Rows vary from 20 to 26 characters and are silently cropped or padded to 22. Maps 2–4 contain several `F` cells, and all but the first are ignored.
7. **No tests or self-checks.** The README's run instructions are accurate, but its gameplay claims are not reachable in the shipped code.

### Rationale for the code score (2/10)
- **Build/brief fit 1.** It is a static site with no dependencies, no CDN and no external requests. It uses procedural WebGL geometry and WebAudio, original names and four original map layouts, and the brief's features are all present in code. The brief's central requirement, a playable game, fails.
- **Core behavior 0.** Nothing beyond the title screen runs.
- **Edge cases 0.** Defects 1–4 above.
- **Maintainability 1.** The module split (math / renderer / audio / input / levels / game) is clean and readable. The modules disagree on data contracts (arrays vs strings), an undefined global and the argument order.
- **Tests/reproducibility 0.** There are no tests, and the claimed behavior cannot be reproduced from the shipped code.

### Rationale for the UI score (2/10)
- **Visual coherence 1.** The title and HUD share a consistent terminal-green style, but the WebGL scene behind them is permanently black.
- **Readability 1.**
  - Desktop: title and controls text are readable.
  - At 390 px the 5-stat HUD needs 534 px of content inside a 370 px bar. LIVES and most of the BASE bar are cut off (`tank-original-mobile-menu.png`).
  - The bottom hint box overlaps the touch pads.
- **Interaction feedback 0.** DEPLOY has hover and press styling, but clicking it produces no visible change and no error message.
- **Keyboard/mobile use 0.** Enter, WASD, Space and the touch pads have no effect.
- **Task-specific depth 0.** No battlefield, tanks or shots are ever displayed.

## 1b. Diagnostic only: :18423 (array-to-string normalization line added)
This section is kept separate from the scores above, which apply to the unmodified submission. With the one-line patch, Thorium showed the following on desktop and mobile:
- **What works.**
  - No page errors, and the render loop runs (26 frames at the title, about 5,900 frames by the end).
  - DEPLOY hides the title, shows a "WAVE 1" banner, and spawns enemies.
  - Walls (54), crates (32) and the core render as lit 3D blocks under a near-overhead camera.
  - Held Space fires. Score rose 0 → 100 → 200 → 725, "DISTRICT CLEARED" appeared, and wave 2 loaded the next map (92 walls, 14 crates).
  - Touch FIRE fired 4 shells. Touch MOVE drove the tank.
- **Controls are rotated 90°, confirmed by the observer.**
  - W gave heading 0 rad (dx +2.22, i.e. right).
  - D gave π/2 (moving down the screen).
  - S gave π (left).
  - A gave 3π/2 (up).
  - Dragging the touch pad *up* moved the tank right (dx +2.35, dz −1.81).
- **No arena bounds.** The player reached x = −34.6, outside the ±22 arena. Player shells flew to z ≈ −38 and enemy shells to x ≈ −49, far beyond the walls.
- **Enemy fire is harmless and misplaced.** Enemy shells appeared at off-arena positions with unrelated headings. Over about 95 s with 2–4 enemies alive, which included 60 s idle at spawn, BASE stayed at 100% and LIVES at ●●●.
- **Enemy navigation fails.** In wave 2, four chasers stayed frozen at the same coordinates for more than 60 s, blocked by walls.
- **Game over and restart were never reached**, so the restart loop could not be exercised.
- **Visuals.** The ground is very dark, so the playfield reads as near-black. On mobile the follow camera keeps the tank near the left edge, and the HUD clipping persists.
- **Conclusion.** The normalization line removes the startup crash. The downstream game still fails on movement, arena containment, enemy threat to the player and base, and the lose/restart loop. Even with this patch, I would still score its core behavior and edge cases at 0–1.
- Screens: `claude-screens/tank-diagnostic-*.png`. Raw runs: `claude-probe/tank-diagnostic-run.json`.

---

## 2. story-F: "Snowfall"

### Firsthand checks (Thorium)
- **Load and assets.**
  - No page errors on desktop or mobile, and no external requests.
  - No external `src` or `href` values. The fonts are system serif stacks.
  - The artwork is 7 inline SVGs plus one Canvas for the snowfall overlay.
- **Scenes.** All 7 were enumerated and photographed on both viewports: Window, Mirror, Wood, Cottage, Apple, Still as Snow, First Snow of Spring. The mirror, cottage, poisoned apple and resolution are all present. SVG node counts per scene range from 100 to 310.
- **Pointer navigation.**
  - Next steps 1 → 7. At 7 it is disabled, and clicking it does nothing.
  - Prev steps back. Clicking dot 3 jumps to scene 3.
- **Keyboard.**
  - Home, ArrowRight, Space, ArrowLeft, `5`, End and PageUp all behave correctly.
  - ArrowRight at the end does nothing.
  - Enter or Space on a focused Next button advances exactly once, with no double step.
  - Focus is placed on `#book` at load, so keys work immediately.
- **Progress indicators.**
  - The counter `n / 7` updates.
  - The progress fill goes 14.29% → 100%.
  - Dots show the current scene and completed scenes.
  - Prev is disabled at scene 1 and Next at scene 7.
  - A live region announces each scene.
- **Mobile swipe** (synthetic touch events): a left swipe goes to the next scene and a right swipe goes back.
- **No horizontal overflow** at any tested width.

### Confirmed blockers and defects
1. **Captions clipped on narrow screens (390 × 844).**
   - The caption is absolutely positioned inside the 4:3 frame (278 px tall, `overflow:hidden`), and the captions are 400–850 characters long.
   - Measured caption height: s1 231, s2 273, s3 315, s4 336, s5 378, s6 357, s7 411 px.
   - The opening lines of scenes 4–7 are cut off at the top of the frame: 10, 52, 31 and 73 px hidden, about 1–3 lines.
   - The caption covers 83–100% of the illustration in every mobile scene, so on a phone the pictures are effectively hidden.
   - Below the frame, roughly 400 px of empty space sits unused (`story-mobile-s7.png`, `story-mobile-s5.png`).
2. **The frame overflows the nav bar at shorter viewports.**
   - The `.frame` keeps its aspect ratio regardless of the stage height.
   - At 1280 × 720 the Prev button is covered.
   - At 1024 × 640 and at 844 × 390 (phone landscape), both Prev and Next are covered, and a real Playwright click on Next timed out.
   - Pointer navigation there falls back to the dots and swipe, and keyboard navigation still works (`story-1024x640-nav-covered.png`, `story-mobile-landscape.png`, `claude-probe/story-nav-coverage.txt`).
3. **Desktop layout issues (1440 × 900).**
   - The frame is left-aligned (36 px left gap, 224 px right gap) rather than centered.
   - Captions cover 38–58% of each picture and hide key subjects, such as the cottage in scene 4 and much of the bier scene in 7.
   - The fixed keyboard-hint row overlaps the progress bar and title.
4. **Art and text inconsistency.** The heroine is drawn with near-white hair (`C.hair = '#f3f0f8'`, used by `snowWhite()`), while the text wishes for hair "as dark as the ebony".
5. **Accessibility and markup.**
   - Each SVG repeats the same `<defs>` IDs, giving 9 duplicate IDs.
   - The tabs have no `aria-controls`, and the tabpanels have no `aria-labelledby`.
   - Each SVG is `aria-hidden`, so the pictures are not described. The caption carries the content.

### Narration and illustration, scene by scene (judgment)
1. **Window.** A warm dawn interior: arched window, a crowned queen, and a cradle-like figure. The text is evocative, but its closing line ("the window frame … turned to black") is obscure.
2. **Mirror.** A strong central gilt mirror with a fog-cloud face, and the queen pointing. A clear mirror beat with original wording.
3. **Wood.** A bright green forest with a small heroine figure. The text has the huntsmen "sent to bring the girl back" with no explicit order to kill, which softens the motive. It reads fine but the logic is vague.
4. **Cottage.** Seven original dwarf names (Grumble, Quick, Smoky, Brave, Tidy, Hum, Quiet), which is a nice touch. In the picture, the cottage and dwarfs sit mostly under the caption.
5. **Apple.** The best composition: an orchard tree, a glowing offered apple, the hag and the heroine. The hag's face reads as bearded and mustached.
6. **Still as Snow.** A dark night room with a glowing bier and a window. Sparse and dark, with the subject small at the left.
7. **First Snow of Spring.** A sunset clearing with the prince, dwarfs and bier. The resolution is clear. The queen's fate ("put her to work in the ground") is ambiguous.

The illustrative style (flat cut-paper with ink outlines and a consistent palette) is coherent across all 7 scenes. Each composition is specific to its scene rather than reused.

### Rationale for the code score (7/10)
- **Build/brief fit 1.** Static, with no external assets, 7 scenes in code-drawn art, visible navigation, keyboard support and progress, so most of the brief is met. The explicit brief items "readable captions" and "usable mobile layout" fail at 390 px (clipped text).
- **Core behavior 2.** Every navigation path worked firsthand, including the boundaries.
- **Edge cases 1.** Boundaries, reduced motion and the Enter-on-dot guard are handled. Caption overflow, frame-versus-bar overflow and the duplicate IDs are not.
- **Maintainability 2.** Clean separation between `scenes.js` (data and art helpers), `main.js` (controller) and `style.css`, with reusable figure helpers.
- **Tests/reproducibility 1.** There are no tests. The README is accurate, and the static output is deterministic.

### Rationale for the UI score (7/10)
- **Visual coherence 2.**
- **Readability 1.** Readable on desktop, but the captions are oversized, cover the art, and are clipped on mobile.
- **Interaction feedback 2.** Dots, counter, progress fill, disabled states, hover and focus rings, and transitions.
- **Keyboard/mobile use 1.** Keyboard support is excellent. On mobile, the clipped captions and the nav buttons covered in landscape and short viewports cost the point.
- **Task-specific depth 1.** The scene-specific compositions are real, but much of the art is hidden behind text. There are character-design inconsistencies, and scene 6 is thin.

---

## Firsthand vs evidence-only
- **Firsthand (my own Thorium runs, this review):**
  - Tank original: all checks above on desktop and mobile.
  - Tank diagnostic: all checks above, including the movement vectors, arena escape, frozen chasers and no damage over about 95 s.
  - Story: all navigation, captions, layout coverage and screenshots on desktop, mobile, 1280 × 720, 1024 × 640 and 844 × 390.
  - Served-file integrity diffs.
- **From source only (not observed at runtime):**
  - Tank: the core render and collision position mismatch, the map row-length cropping, the multiple-`F` handling, and the exact cause of the enemy-shell heading.
  - Story: the hair-color mismatch is from source, and also visible in the screenshots.
- **Prior evidence consulted, but not relied on for scoring:**
  - `review/evidence/tank-browser.json` (the same `mapStr.trim` error and a failed "deploy opens the battlefield" check). It agrees with my run.
  - `review/evidence/story-browser.json` (its aria-labelledby check failed). It agrees with my markup finding.
  - `review/evidence/*-formal-source.json` (formal runs produced no files).
  - `review/evidence/tank-diagnostic.md` (the patch text, which I verified against :18423).

## Artifacts
- `evidence/review/claude-review.md`, `evidence/review/claude-review.json`
- Screenshots: `evidence/review/claude-screens/` (tank-original-*, tank-diagnostic-*, story-*)
- Probe scripts and raw results: `evidence/review/claude-probe/` (tank-probe.cjs, story-probe.cjs, story-cover.cjs, tank-original-run.json, tank-diagnostic-run.json, story-run.json, story-nav-coverage.txt)
