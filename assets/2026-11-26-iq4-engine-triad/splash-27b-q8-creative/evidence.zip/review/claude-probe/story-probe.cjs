const { chromium } = require('~/Code/canada-fire-calculator/node_modules/playwright');
const fs = require('fs');
const SHOTS = 'splash-27b-q8-creative/evidence/review/claude-screens';
const url = 'http://127.0.0.1:18422/';
const sleep = ms => new Promise(r=>setTimeout(r,ms));
const state = p => p.evaluate(()=>{
  const cur = document.querySelector('.scene.is-current');
  const fr = cur.querySelector('.frame').getBoundingClientRect();
  const cap = cur.querySelector('.caption'); const cr = cap.getBoundingClientRect();
  const para = cap.querySelector('p').getBoundingClientRect();
  const stage = document.getElementById('stage').getBoundingClientRect();
  const bar = document.querySelector('.bar').getBoundingClientRect();
  const art = cur.querySelector('.artwork svg');
  return {
    scene: document.body.dataset.scene, counter: document.getElementById('counter').textContent,
    title: document.getElementById('title').textContent, fill: document.getElementById('fill').style.width,
    prevDisabled: document.getElementById('prev').disabled, nextDisabled: document.getElementById('next').disabled,
    dots: [...document.querySelectorAll('.dot')].map(d=>d.classList.contains('is-current')?'C':d.classList.contains('is-done')?'d':'.').join(''),
    active: document.activeElement ? (document.activeElement.id||document.activeElement.className) : null,
    frame: {top:Math.round(fr.top), bottom:Math.round(fr.bottom), left:Math.round(fr.left), right:Math.round(fr.right), h:Math.round(fr.height)},
    stage: {top:Math.round(stage.top), bottom:Math.round(stage.bottom), left:Math.round(stage.left), right:Math.round(stage.right)},
    barTop: Math.round(bar.top), barBottom: Math.round(bar.bottom),
    caption: {top:Math.round(cr.top), h:Math.round(cr.height), paraTop:Math.round(para.top), paraBottom:Math.round(para.bottom),
      textClippedTop: para.top < fr.top - 0.5, textHiddenPx: Math.max(0, Math.round(fr.top - para.top)),
      coversFramePct: Math.round(100*Math.min(cr.height, fr.height)/fr.height)},
    frameOverlapsBar: fr.bottom > bar.top + 0.5, frameExceedsStage: fr.bottom > stage.bottom + 0.5,
    svgNodes: art ? art.querySelectorAll('*').length : 0,
    scrollW: document.documentElement.scrollWidth, innerW: innerWidth, innerH: innerHeight
  };
});
(async()=>{
  const browser = await chromium.launch({executablePath:'/Applications/Thorium.app/Contents/MacOS/Thorium', headless:true});
  const out = {url, browser:'Thorium '+browser.version(), views:{}};
  for (const view of ['desktop','mobile']) {
    const ctx = await browser.newContext(view==='desktop' ? {viewport:{width:1440,height:900}} : {viewport:{width:390,height:844}, isMobile:true, hasTouch:true, deviceScaleFactor:2});
    const page = await ctx.newPage();
    const r = out.views[view] = {errors:[], console:[], external:[], steps:[]};
    page.on('pageerror', e=>r.errors.push(String(e.message)));
    page.on('console', m=>{ if(m.type()==='error'||m.type()==='warning') r.console.push(m.type()+': '+m.text()); });
    page.on('request', q=>{ const u=q.url(); if(!u.startsWith(url) && !u.startsWith('data:')) r.external.push(u); });
    await page.goto(url, {waitUntil:'load'}); await sleep(900);
    r.static = await page.evaluate(()=>({
      scenes: document.querySelectorAll('.scene').length, dots: document.querySelectorAll('.dot').length,
      ids: (()=>{const m={}; document.querySelectorAll('[id]').forEach(e=>m[e.id]=(m[e.id]||0)+1); return Object.entries(m).filter(([k,v])=>v>1).length;})(),
      dotsAriaControls: [...document.querySelectorAll('.dot')].every(d=>d.hasAttribute('aria-controls')),
      externalRefs: [...document.querySelectorAll('[src],[href]')].map(e=>e.getAttribute('src')||e.getAttribute('href')).filter(u=>/^https?:|^\/\//.test(u)),
      fontsUsed: getComputedStyle(document.querySelector('.caption p')).fontFamily,
      focusAtLoad: document.activeElement && document.activeElement.id
    }));
    const rec = async (step, shot) => { const s = await state(page); s.step=step; if(shot){ const f=`story-${view}-${shot}.png`; await page.screenshot({path:`${SHOTS}/${f}`}); s.screenshot=f; } r.steps.push(s); return s; };
    await rec('initial', 's1');
    // pointer: Next button through all scenes
    for (let i=2;i<=7;i++){ if(view==='desktop') await page.click('#next'); else await page.tap('#next'); await sleep(650); await rec('next-click', 's'+i); }
    if(view==='desktop') await page.click('#next', {force:true}).catch(()=>{}); await sleep(300); await rec('next-at-end');
    // pointer: prev
    if(view==='desktop') await page.click('#prev'); else await page.tap('#prev'); await sleep(600); await rec('prev-click');
    // dot click
    const dot = page.locator('.dot').nth(2); if(view==='desktop') await dot.click(); else await dot.tap(); await sleep(600); await rec('dot-3');
    if (view==='desktop') {
      // keyboard
      await page.keyboard.press('Home'); await sleep(300); await rec('key-Home');
      await page.keyboard.press('ArrowRight'); await sleep(300); await rec('key-ArrowRight');
      await page.keyboard.press('Space'); await sleep(300); await rec('key-Space');
      await page.keyboard.press('ArrowLeft'); await sleep(300); await rec('key-ArrowLeft');
      await page.keyboard.press('5'); await sleep(300); await rec('key-5');
      await page.keyboard.press('End'); await sleep(300); await rec('key-End');
      await page.keyboard.press('ArrowRight'); await sleep(300); await rec('key-ArrowRight-at-end');
      await page.keyboard.press('PageUp'); await sleep(300); await rec('key-PageUp');
      // Tab focus traversal from start
      await page.keyboard.press('Home'); await page.evaluate(()=>document.activeElement.blur());
      const tabs=[]; for(let i=0;i<6;i++){ await page.keyboard.press('Tab'); tabs.push(await page.evaluate(()=>{const a=document.activeElement; return a? (a.id||a.className)+(a.getAttribute('aria-label')?':'+a.getAttribute('aria-label'):''):null;})); }
      r.tabOrder = tabs;
      // Enter on focused next button: does it double-advance? (keydown handler + button click)
      await page.keyboard.press('Home'); await page.focus('#next'); await page.keyboard.press('Enter'); await sleep(300); await rec('enter-on-next-button');
      await page.keyboard.press('Home'); await page.focus('#next'); await page.keyboard.press('Space'); await sleep(300); await rec('space-on-next-button');
      // narrow desktop window (e.g., 1024x640 laptop) caption check
      await page.setViewportSize({width:1024,height:640}); await page.keyboard.press('End'); await sleep(600); await rec('1024x640-s7','1024-s7');
    } else {
      // swipe left on stage
      await page.keyboard.press('Home').catch(()=>{});
      await page.evaluate(()=>{ const t=(x,y)=>new Touch({identifier:1,target:document.body,clientX:x,clientY:y});
        window.dispatchEvent(new TouchEvent('touchstart',{changedTouches:[t(300,400)],touches:[t(300,400)]}));
        window.dispatchEvent(new TouchEvent('touchend',{changedTouches:[t(120,405)],touches:[]})); });
      await sleep(600); await rec('swipe-left');
      await page.evaluate(()=>{ const t=(x,y)=>new Touch({identifier:1,target:document.body,clientX:x,clientY:y});
        window.dispatchEvent(new TouchEvent('touchstart',{changedTouches:[t(100,400)],touches:[t(100,400)]}));
        window.dispatchEvent(new TouchEvent('touchend',{changedTouches:[t(300,402)],touches:[]})); });
      await sleep(600); await rec('swipe-right');
      // landscape phone
      await page.setViewportSize({width:844,height:390}); await sleep(600); await rec('landscape-844x390','landscape');
    }
    await ctx.close();
  }
  await browser.close();
  fs.writeFileSync('story.json', JSON.stringify(out,null,1));
})().catch(e=>{console.error(e); process.exit(1);});
