const { chromium } = require('~/Code/canada-fire-calculator/node_modules/playwright');
(async()=>{
  const b = await chromium.launch({executablePath:'/Applications/Thorium.app/Contents/MacOS/Thorium', headless:true});
  for (const vp of [{width:1440,height:900},{width:1280,height:720},{width:1024,height:640},{width:844,height:390},{width:390,height:844}]) {
    const p = await b.newPage({viewport:vp}); await p.goto('http://127.0.0.1:18422/'); await p.waitForTimeout(500);
    await p.keyboard.press('2'); await p.waitForTimeout(600);
    const r = await p.evaluate(()=>{ const hit = id=>{ const e=document.getElementById(id).getBoundingClientRect(); const t=document.elementFromPoint(e.left+e.width/2, e.top+e.height/2); return t && (t.id===id || document.getElementById(id).contains(t)) ? 'clickable' : 'covered by '+(t?(t.className.baseVal!==undefined?t.tagName:t.className||t.tagName):'none'); };
      const f=document.querySelector('.scene.is-current .frame').getBoundingClientRect();
      return {prev:hit('prev'), next:hit('next'), title:hit('title'), frameLeft:Math.round(f.left), frameRightGap:Math.round(innerWidth-f.right)}; });
    let clicked=null; try { await p.click('#next',{timeout:1500}); clicked=await p.evaluate(()=>document.body.dataset.scene); } catch(e){ clicked='click failed: '+e.message.split('\n')[0]; }
    console.log(JSON.stringify(vp), JSON.stringify(r), 'after next click scene=', clicked);
    if (vp.width===1024) await p.screenshot({path:'splash-27b-q8-creative/evidence/review/claude-screens/story-1024x640-nav-covered.png'});
    await p.close();
  }
  await b.close();
})();
