const { chromium } = require('~/Code/canada-fire-calculator/node_modules/playwright');
const fs = require('fs');
const SHOTS = 'splash-27b-q8-creative/evidence/review/claude-screens';
const [,, url, tag, outJson] = process.argv;
const sleep = ms => new Promise(r=>setTimeout(r,ms));
// observer only: wraps global Renderer draw calls to record arguments; no source edits
const OBS = () => {
  if (window.__obs) return true;
  if (!window.Renderer) return false;
  const o = window.__obs = {frames:0, player:null, playerHist:[], enemies:[], shells:[], core:null, walls:0, crates:0};
  const R = window.Renderer;
  const wrap = (name, fn) => { const orig = R[name]; R[name] = function(){ fn.apply(null, arguments); return orig.apply(this, arguments); }; };
  wrap('beginFrame', ()=>{ o.frames++; o._en=[]; o._sh=[]; o._w=0; o._c=0; });
  wrap('drawPlayer', (x,z,b,t,a)=>{ o.player={x,z,body:b,turret:t,alpha:a}; });
  wrap('drawEnemy', (k,x,z)=>{ o._en.push({k,x,z}); });
  wrap('drawEnemyFlash', (p,x,z)=>{ o._en.push({k:'flash',x,z}); });
  wrap('drawShell', (x,y,z,ang,col)=>{ o._sh.push({x,z,ang,enemy:col[0]===1}); });
  wrap('drawCore', (hp)=>{ o.core=hp; });
  wrap('drawBlock', ()=>{ o._w++; });
  wrap('drawCrate', ()=>{ o._c++; });
  wrap('particles', ()=>{ o.enemies=o._en; o.shells=o._sh; o.walls=o._w; o.crates=o._c; });
  return true;
};
const hud = p => p.evaluate(()=>({
  score: document.getElementById('score').textContent,
  wave: document.getElementById('wave').textContent,
  enemies: document.getElementById('enemies').textContent,
  base: document.getElementById('basefill').style.width,
  lives: document.getElementById('lives').textContent,
  title: !document.getElementById('title-screen').classList.contains('hidden'),
  over: !document.getElementById('over-screen').classList.contains('hidden'),
  overText: document.getElementById('over-screen').innerText,
  banner: document.getElementById('wave-banner').textContent,
  obs: window.__obs ? {frames:window.__obs.frames, player:window.__obs.player, nEnemies:window.__obs.enemies.length, enemies:window.__obs.enemies.slice(0,4), nShells:window.__obs.shells.length, shells:window.__obs.shells.slice(0,6), core:window.__obs.core, walls:window.__obs.walls, crates:window.__obs.crates} : null
}));
(async()=>{
  const browser = await chromium.launch({executablePath:'/Applications/Thorium.app/Contents/MacOS/Thorium', headless:true, args:['--use-angle=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist','--autoplay-policy=no-user-gesture-required']});
  const result = {url, tag, browser:'Thorium '+browser.version(), views:{}};
  for (const view of ['desktop','mobile']) {
    const ctxOpts = view==='desktop' ? {viewport:{width:1440,height:900}} : {viewport:{width:390,height:844}, isMobile:true, hasTouch:true, deviceScaleFactor:2};
    const ctx = await browser.newContext(ctxOpts);
    const page = await ctx.newPage();
    const r = result.views[view] = {errors:[], console:[], external:[], steps:[]};
    page.on('pageerror', e=>r.errors.push(String(e.message)));
    page.on('console', m=>{ if(m.type()==='error'||m.type()==='warning') r.console.push(m.type()+': '+m.text()); });
    page.on('request', q=>{ const u=q.url(); if(!u.startsWith(url) && !u.startsWith('data:')) r.external.push(u); });
    const step = async (name, extra) => { const h = await hud(page); r.steps.push(Object.assign({step:name}, h, extra||{})); return h; };
    const shot = async name => { const f = `${tag}-${view}-${name}.png`; await page.screenshot({path:`${SHOTS}/${f}`}); r.steps[r.steps.length-1].screenshot=f; };
    await page.goto(url, {waitUntil:'load'});
    await sleep(800);
    r.observer = await page.evaluate(OBS);
    await sleep(500);
    const layout = await page.evaluate(()=>{ const h=document.getElementById('hud-top').getBoundingClientRect(); return {scrollW:document.documentElement.scrollWidth, innerW:innerWidth, hudRight:h.right, hudWidth:h.width, hudScrollW:document.getElementById('hud-top').scrollWidth, touchOn:document.getElementById('touch').classList.contains('on')}; });
    await step('menu', {layout}); await shot('menu');
    if (view==='desktop') await page.click('#start-btn'); else await page.tap('#start-btn');
    await sleep(2500);
    await step('after-deploy'); await shot('after-deploy');
    await page.keyboard.press('Enter'); await sleep(800);
    await step('after-enter');
    if (view==='desktop') {
      // movement probes: hold each key 700ms, record player displacement
      const moves = {};
      for (const key of ['KeyW','KeyD','KeyS','KeyA']) {
        const a = (await hud(page)).obs; await page.keyboard.down(key); await sleep(700); await page.keyboard.up(key); await sleep(300);
        const b = (await hud(page)).obs;
        moves[key] = (a&&a.player&&b&&b.player) ? {dx:+(b.player.x-a.player.x).toFixed(2), dz:+(b.player.z-a.player.z).toFixed(2), body:+b.player.body.toFixed(2)} : null;
      }
      await step('movement', {moves}); await shot('moved');
      await page.keyboard.down('Space'); await sleep(1500);
      await step('firing'); await shot('firing');
      await page.keyboard.up('Space');
      // drive in one direction for a long time to test arena bounds
      await page.keyboard.down('KeyW'); await page.keyboard.down('ShiftLeft'); await sleep(6000); await page.keyboard.up('KeyW'); await page.keyboard.up('ShiftLeft');
      await step('drive-6s-W'); await shot('drive-far');
      // idle then fight: hold fire + steer toward enemies for a while
      await page.keyboard.down('KeyS'); await sleep(3000); await page.keyboard.up('KeyS');
      await page.keyboard.down('Space');
      for (let i=0;i<10;i++){ await sleep(3000); const h=await step('combat-'+i); if(h.over) break; }
      await page.keyboard.up('Space');
      await shot('combat-end');
      // let enemies act for up to 60s to see if a game over can occur
      for (let i=0;i<12;i++){ await sleep(5000); const h=await step('idle-'+i); if(h.over) { await shot('gameover'); break; } }
      const h = await hud(page);
      if (h.over) { await page.click('#restart-btn'); await sleep(1500); await step('after-restart'); await shot('restart'); }
    } else {
      const t = await page.evaluate(()=>{ const a=document.getElementById('t-left').getBoundingClientRect(), b=document.getElementById('t-fire').getBoundingClientRect(); return {touchOn:document.getElementById('touch').classList.contains('on'), move:[a.x,a.y,a.width], fire:[b.x,b.y,b.width]}; });
      // hold fire via touch events
      await page.evaluate(()=>{ const el=document.getElementById('t-fire'); const t=new Touch({identifier:9,target:el,clientX:330,clientY:780}); el.dispatchEvent(new TouchEvent('touchstart',{touches:[t],changedTouches:[t],bubbles:true,cancelable:true})); });
      await sleep(1500);
      await step('touch-fire', {touch:t}); await shot('touch-fire');
      await page.evaluate(()=>{ const el=document.getElementById('t-fire'); const t=new Touch({identifier:9,target:el,clientX:330,clientY:780}); el.dispatchEvent(new TouchEvent('touchend',{touches:[],changedTouches:[t],bubbles:true,cancelable:true})); });
      // drag move pad upward
      const a = (await hud(page)).obs;
      await page.evaluate(async()=>{ const el=document.getElementById('t-left'); const r=el.getBoundingClientRect(); const cx=r.left+r.width/2, cy=r.top+r.height/2;
        const mk=(x,y)=>new Touch({identifier:3,target:el,clientX:x,clientY:y});
        el.dispatchEvent(new TouchEvent('touchstart',{touches:[mk(cx,cy)],changedTouches:[mk(cx,cy)],bubbles:true,cancelable:true}));
        el.dispatchEvent(new TouchEvent('touchmove',{touches:[mk(cx,cy-50)],changedTouches:[mk(cx,cy-50)],bubbles:true,cancelable:true}));
        await new Promise(r=>setTimeout(r,900));
        el.dispatchEvent(new TouchEvent('touchend',{touches:[],changedTouches:[mk(cx,cy-50)],bubbles:true,cancelable:true})); });
      await sleep(300);
      const b = (await hud(page)).obs;
      await step('touch-move-up', {move: (a&&a.player&&b&&b.player)?{dx:+(b.player.x-a.player.x).toFixed(2), dz:+(b.player.z-a.player.z).toFixed(2)}:null}); await shot('touch-move');
    }
    await ctx.close();
  }
  await browser.close();
  fs.writeFileSync(outJson, JSON.stringify(result,null,1));
  console.log(JSON.stringify(result,null,1).slice(0,200));
})().catch(e=>{console.error(e); process.exit(1);});
