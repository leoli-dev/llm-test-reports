import fs from "node:fs/promises";
import path from "node:path";
import { createRequire } from "node:module";
const { chromium } = createRequire(import.meta.url)(process.env.TRIAD_PLAYWRIGHT);
const [destination, url = "http://127.0.0.1:18421/"] = process.argv.slice(2);
await fs.mkdir(destination,{recursive:true});
const browser = await chromium.launch({
  executablePath: "/Applications/Thorium.app/Contents/MacOS/Thorium",
  headless: true,
  args: ["--enable-unsafe-swiftshader","--disable-background-networking"]
});
const report = { browser: "Thorium", version: browser.version(), checks: [], captures: [], errors: [], externalRequests: [] };
async function record(view, check, operation) {
  try {
    const result = await operation();
    report.checks.push({ view, check, ok: result.ok, ...result });
    return result.ok;
  } catch (error) {
    report.checks.push({ view, check, ok: false, error: error.message.split("\n")[0] });
    return false;
  }
}
try {
  for (const [view, viewport] of [["desktop",{width:1440,height:900}], ["mobile",{width:390,height:844}]]) {
    const context = await browser.newContext({viewport, hasTouch:view==="mobile"});
    await context.route("**/*", route => {
      const request = new URL(route.request().url());
      if (request.origin === new URL(url).origin || !["http:","https:"].includes(request.protocol)) return route.continue();
      report.externalRequests.push({ view, origin: request.origin, path: request.pathname });
      return route.abort();
    });
    const page = await context.newPage();
    page.setDefaultTimeout(6500);
    const errors = new Set();
    for (const [event, message] of [
      ["pageerror", item => item.message],
      ["console", item => item.type()==="error" ? item.text() : null],
      ["response", item => item.status()>=400 ? `${item.status()} ${new URL(item.url()).pathname}` : null],
    ]) {
      page.on(event, item => { const value = message(item); if (value) errors.add(value); });
    }
    const capture = async name => {
      const file = `${view}-${name}.png`;
      await page.screenshot({path:path.join(destination,file),timeout:12000});
      report.captures.push(file);
    };
    const visible = async selector => {
      await page.locator(selector).waitFor({state:"visible"});
      return {ok:true};
    };
    const read = () => page.evaluate(() => window.benchmarkObservation);
    const captureSafe = name => record(view, `screenshot ${name}`, async () => { await capture(name); return {ok:true}; });
    try {
      await record(view,"static page loads", async () => ({ok:(await page.goto(url,{waitUntil:"load"})).ok()}));
      await record(view,"deploy menu appears", () => visible("#start-btn"));
      await captureSafe("menu");
      await record(view,"WebGL frame observer initialized", async () => {
        const state = await page.evaluate(() => {
          const observation = {frames:0, ships:0, shots:0, enemyShots:0, shells:0, player:null};
          window.benchmarkObservation = observation;
          if (!window.Renderer || !window.Game || !window.Input) return false;
          for (const [object, method, note] of [
            [Renderer,"beginFrame",()=>observation.frames++],
            [Renderer,"drawPlayer",(x,z)=>observation.player=[x,z]],
            [Renderer,"drawEnemy",()=>observation.ships++],
            [Renderer,"drawShell",()=>observation.shells++],
            [Audio,"shoot",()=>observation.shots++],
            [Audio,"enemyShoot",()=>observation.enemyShots++],
          ]) {
            const original = object[method];
            if (typeof original !== "function") continue;
            object[method] = function (...args) { note(...args); return original.apply(this,args); };
          }
          return true;
        });
        await page.waitForFunction(() => window.benchmarkObservation?.frames>=4);
        return {ok:state,...await read()};
      });
      if (!await record(view,"deploy opens the battlefield", async () => {
        await page.locator("#start-btn").click();
        await page.locator("#title-screen").waitFor({state:"hidden"});
        return {ok:true};
      })) continue;

      await record(view,"HUD fits the viewport", async () => {
        const bounds = await page.locator("#hud-top .stat").evaluateAll(elements => elements.map(el => {
          const box=el.getBoundingClientRect();
          return {label:el.innerText.split("\n")[0],left:box.left,right:box.right};
        }));
        return {ok:bounds.length===5 && bounds.every(box=>box.left>=0&&box.right<=viewport.width), bounds};
      });

      if (view === "desktop") {
        await record(view,"arrow keys move the tank",async () => {
          const before=(await read()).player;
          await page.keyboard.down("ArrowLeft");
          await page.waitForTimeout(1100);
          await page.keyboard.up("ArrowLeft");
          const after=(await read()).player;
          return {ok:before?.some((value,i)=>Math.abs(value-after?.[i])>.25) ?? false,before,after};
        });
        await record(view,"space launches a rendered shot",async () => {
          const before=await read();
          await page.keyboard.down("Space");
          await page.waitForTimeout(1000);
          await page.keyboard.up("Space");
          const after=await read();
          return {ok:after.shots>before.shots && after.shells>before.shells,before,after};
        });
        await record(view,"enemy enters the rendered battlefield",async () => {
          await page.waitForFunction(()=>window.benchmarkObservation?.ships>0,{},{timeout:10000});
          return {ok:true,...await read()};
        });
        await captureSafe("battle");
        const over = await record(view,"natural failure reaches game over",async () => {
          await page.locator("#restart-btn").waitFor({state:"visible",timeout:65000});
          return {ok:true,reason:await page.locator("#over-title").textContent(),...await read()};
        });
        if (over) {
          await captureSafe("game-over");
          await record(view,"redeploy starts wave one",async () => {
            await page.locator("#restart-btn").click();
            await page.locator("#over-screen").waitFor({state:"hidden"});
            await page.waitForFunction(()=>document.querySelector("#wave")?.textContent==="1");
            return {ok:true};
          });
        }
        await record(view,"low-health core renderer accepts the state", async () => {
          return await page.evaluate(() => {
            try {
              Renderer.drawCore(0.49,0);
              return {ok:true};
            } catch (error) {
              return {ok:false,error:error.message};
            }
          });
        });
      } else {
        await record(view,"touch Fire launches a rendered shot",async () => {
          const fire=page.locator("#t-fire");
          await fire.waitFor({state:"visible"});
          const box=await fire.boundingBox();
          const before=await read();
          const cdp=await context.newCDPSession(page);
          await cdp.send("Input.dispatchTouchEvent",{type:"touchStart",touchPoints:[{x:box.x+box.width/2,y:box.y+box.height/2}]});
          await page.waitForTimeout(750);
          await cdp.send("Input.dispatchTouchEvent",{type:"touchEnd",touchPoints:[]});
          const after=await read();
          return {ok:after.shots>before.shots && after.shells>before.shells,before,after};
        });
        await captureSafe("battle");
      }
    } finally {
      report.errors.push(...[...errors].map(error=>({view,error})));
      await context.close();
    }
  }
} finally {
  await browser.close();
  await fs.writeFile(path.join(destination,"browser.json"),JSON.stringify(report,null,2)+"\n");
}
