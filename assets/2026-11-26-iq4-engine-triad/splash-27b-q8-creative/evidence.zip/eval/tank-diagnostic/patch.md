# Diagnostic-only patch

```diff
--- a/js/levels.js
+++ b/js/levels.js
@@ -111,6 +111,7 @@
 ];
 
 function parse(mapStr){
+  if (Array.isArray(mapStr)) mapStr = mapStr.join('\n');
   var raw = mapStr.trim().split(/\n/).map(function(l){ return l.replace(/\s+$/,''); });
   // normalize each row to exactly N characters
   var rows = raw.slice(0, N).map(function(l){
```
