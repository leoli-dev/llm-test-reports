# POS candidate C — independent review

Reviewer model: **Claude Opus 5.5 (`claude-opus-5-5`)**, Orca worker task_40a8a6c89d34 · 2026-11-26
Target: `review/pos-C` vs `prompts/pos.txt` · Live demo `http://127.0.0.1:18301/` (API `:18302`)
Browser: Thorium 156.0.8078.28 via Playwright `executablePath` (verified with `browser.version()`)

**Scores: Code 7/10 · UI 8/10**

## Clean-volume outcome (preserved)
- **Supplied:** on a fresh `pos-data` volume the API crash-looped: `open store: seed database: open /data/db.json.tmp: permission denied` (`evidence/api-start-failure.log`). The evaluator then made a one-time change, giving `/data` to uid 10001 (`evidence/test-volume-init.log`). After that, the stack started and all supplied API and browser checks passed.
- **Own (code):** root cause confirmed. `backend/Dockerfile` adds user `pos` (uid 10001) and sets `USER pos` with `VOLUME ["/data"]`, but never creates or chowns `/data`. A new named volume is therefore root-owned. The documented `docker compose up --build` does **not** work as shipped.
- **After setup (own):** `/api/health` showed 4 pre-existing sales from the supplied runs. Both containers were up (API healthy) on 18301/18302. Running on non-default ports shows the port variables work.

## Code — 7/10
| Dimension | Score | Basis |
|---|---|---|
| Build / brief fit | 1 | Every feature in the brief is present: Go stdlib API, Vue 3 + nginx same-origin `/api` proxy (`frontend/nginx.conf`, relative `BASE` in `store.js:6`), loopback `POS_WEB_PORT`/`POS_API_PORT`, 34 seeded SKUs, README run/reset/test steps and API routes. It loses a point because the clean-volume start fails (see above). |
| Core behavior | 2 | Server-side catalog price, integer cents and half-up tax (`store.go:183`). It validates every line before mutating and commits atomically under a mutex with a tmp-file + rename write (`checkout.go:38-143`). Own: cash sale S-000005 and card sale S-000006 decremented stock on the server (spinach 3→2) and were recorded in `/api/sales`. |
| Edge cases | 1 | Own API probes: qty −1 → 400 `invalid_quantity`; 1.5 / "2" → 400 `bad_request`; duplicate lines merged and 2+2>3 → 409; out-of-stock → 409; short cash → 422; bad method → 400; GET → 405. **Defects:** (a) the client tax estimate rounds twice (`store.js:79`, `Math.round((x+5000)/10000)`), so it can sit 1¢ above the server (own: cart $7.58 vs receipt $7.57); (b) if `save()` fails, stock and sales already changed in memory are not rolled back (`checkout.go:129-140`); (c) after a 409 the cart's stock snapshot is not refreshed. |
| Maintainability | 2 | Small, clearly split files (store / checkout / handlers / errors / seed; Vue store plus 4 components) with useful comments and structured error codes. Nits: `gofmt -l` flags `checkout.go`, `checkout_test.go`, `handlers.go`; there is a stray `frontend/src/components/_unused.vue` placeholder. |
| Tests / reproducibility | 1 | Own: `go test -race -count=1` passes in a disposable copy (11 tests: happy path, merge, 409 + no mutation, whole-cart atomicity, invalid qty, unknown SKU, tender, persistence across reopen, rounding, search) and `go vet` is clean. The supplied `go-test.log` agrees. It loses a point because the README's main run path does not reproduce on a clean volume, and the frontend has no tests. |

## UI — 8/10
| Dimension | Score | Basis |
|---|---|---|
| Visual coherence | 2 | Consistent dark header, teal accent, card grid, stock badges (ok / low / out) and a thermal-style receipt (own screenshots `claude-screens/desktop-checkout.png`, `mobile-receipt.png`; supplied `desktop-register.png`). |
| Readability | 2 | High-contrast prices, SKU in mono, clear totals block, and a monospace receipt that fits 390 px (own: modal 20–370 px of 390). The receipt number wraps awkwardly on mobile ("S-" / "000006"). |
| Interaction feedback | 2 | Own: a toast on stock cap ("Only 3 of … available"), a typed qty of 9 clamped to 3, live change due / short-by text, a `role=alert` checkout error, "Sale recorded" toast, and stock badges that refresh after a sale. No console or page errors (own and supplied). |
| Keyboard / mobile use | 1 | Own: `/` focuses search, Enter adds the top result, F2 opens checkout with focus in the tender field, Enter completes the sale, focus lands on "Start new sale", and Esc closes; focus rings are visible. **Problems:** no focus trap (Tab leaves the dialog after 2 presses; supplied evidence agrees). The modal-level Enter handler (`CheckoutModal.vue:30-34`) captures Enter on every button: Enter on **Cancel completed a real sale** (own, S-000006), and Enter on "$20 ↑" does nothing (Space works). Mobile (own, iPhone 13 profile): no horizontal overflow, but the cart is stacked below all 34 cards unless the list is filtered, and the category chips are 36 px tall. |
| POS workflow finish | 1 | The happy path is complete and the receipt is clear: number, time, lines with SKU@price, subtotal, tax, total, tender and change. However, the checkout modal labels the client estimate a "server-confirmed total" (`CheckoutModal.vue:70`). It showed $7.58 and "Change due $12.42" while the receipt and server recorded $7.57 and $12.43. |

## Checks: own vs supplied
- **Own:** source read; Go tests (with -race), vet and gofmt in a disposable copy; 8 rejecting API probes (no state change); Thorium desktop keyboard-only cash sale (S-000005, spinach + kettle chips, $7.57); Thorium mobile touch card sale (S-000006, 2× sourdough, $10.83, submitted through Enter on Cancel); focus-trap, quick-tender and overflow probes; screenshots in `results/claude-screens/`.
- **Supplied (accepted, not re-run):** clean-volume failure log and volume init; `api.json` (validation, cash/card, restart persistence of sales + stock); `browser.json` and its 4 screenshots; `go-test.log`.
- **Not done:** I did not restart the stack or change ports myself (persistence across restart is supplied evidence only, plus the own Go reopen test), did not rebuild the images, and did not touch Docker data ownership.

## Top risks
1. A first `docker compose up` on a clean volume fails (volume permissions). One line fixes it: `RUN mkdir /data && chown pos /data` before `USER`.
2. A keyboard Enter on Cancel or any modal button submits the sale.
3. The displayed total and change can be 1¢ off from the receipt while labeled "server-confirmed".
4. No modal focus trap; there is no in-memory rollback if persisting a sale fails.
