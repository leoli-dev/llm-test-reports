"""Run the POS acceptance checks on the isolated Compose project."""
import json
import os
import subprocess
import time
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

BASE = f"http://127.0.0.1:{os.environ['POS_API_PORT']}"
SKU = "BEV-1001"
checks = []


def request(path, payload=None):
    body = json.dumps(payload).encode() if payload is not None else None
    try:
        response = urlopen(Request(BASE + path, data=body, headers={"Content-Type": "application/json"}), timeout=5)
    except HTTPError as error:
        response = error
    with response:
        return response.status, json.load(response)


def check(name, ok, evidence):
    checks.append({"check": name, "ok": bool(ok), "evidence": evidence})


def product():
    status, catalog = request(f"/api/products?q={SKU}")
    if status != 200:
        raise RuntimeError(f"catalog returned HTTP {status}")
    return next(row for row in catalog["products"] if row["sku"] == SKU)


def checkout(method, quantity):
    return request("/api/checkout", {"items": [{"sku": SKU, "qty": quantity}],
                                    "payment": {"method": method, "tendered_cents": 2000}})


try:
    first = product()
    before = first["stock"]
    status, result = checkout("cash", 0)
    check("quantity zero rejected", status == 400, {"status": status, "body": result})
    status, result = checkout("cash", before + 1)
    check("insufficient stock rejected", status == 409, {"status": status, "body": result})
    check("rejections leave inventory unchanged", product()["stock"] == before, {"stock": product()["stock"]})
    for method in ("cash", "card"):
        status, result = checkout(method, 1)
        sale = result.get("sale", {})
        ok = (status == 201 and sale.get("payment_method") == method and
              sale.get("subtotal_cents") == first["price_cents"] and bool(sale.get("number")))
        check(f"{method} sale returns receipt with catalog price", ok, {"status": status, "body": result})
    check("inventory decremented twice", product()["stock"] == before - 2, {"stock": product()["stock"], "was": before})
    before_status, before_history = request("/api/sales?limit=20")
    subprocess.run(["docker", "compose", "--project-name", "triad-pos-dflash2", "restart", "api"],
                   check=True, capture_output=True, timeout=45)
    for attempt in range(30):
        try:
            if request("/api/health")[0] == 200:
                break
        except (URLError, OSError):
            pass
        time.sleep(1)
    after_status, after_history = request("/api/sales?limit=20")
    check("sales survive backend restart", before_status == after_status == 200 and before_history == after_history,
          {"status": after_status, "count": len(after_history.get("sales", []))})
    check("inventory survives backend restart", product()["stock"] == before - 2, {"stock": product()["stock"]})
except Exception as error:
    check("runner completed", False, repr(error))

print(json.dumps(checks, indent=2))
raise SystemExit(0 if all(row["ok"] for row in checks) else 1)
