# Paired evaluation plan

One fresh Pi run per engine and brief. Store the first telemetry-covered run; distinguish a harness failure from a model failure. Preserve generated source without evaluator changes. Record timeouts and incomplete output. Run the teams' own checks and independent probes. Build/run only after inspecting generated container instructions and scripts.

The first formal Splash tank request exhausted the output cap in thinking and created no files. A follow-up paired round uses the same tank brief and system prompt in fresh directories, with Pi thinking disabled and the relay setting the explicit common API value `reasoning_effort: none`. It retains the 16,384-token cap, sampling, tools, and time allowance. Report both rounds separately.

| Product | Splash | Strata |
| --- | --- | --- |
| POS web / API | 18101 / 18102 | 18201 / 18202 |
| Tank | 18103 | 18203 |
| Story | 18104 | 18204 |

POS ports are bound to loopback and use different Compose project names and volumes. Tank and story are served over loopback with a static HTTP server. Use Thorium for all browser checks, with desktop at 1440 × 900 and mobile at 390 × 844. Capture initial and meaningful interacted states. Record failures rather than correcting generated source.

## Acceptance

- POS: Compose resolves and boots on assigned ports, Go tests, catalog search, cart quantity, cash/card flow, receipt and refreshed stock, invalid quantity and insufficient stock rejected, state survives backend restart. Review authority for prices, totals and stock, persistence, and keyboard use.
- Tank: scene renders with depth and readable orientation, move and shoot, solid obstacles, enemies and defendable objective, progression and restart, browser errors and narrow-screen fit. Distinguish gameplay observed directly from behavior inferred from code.
- Story: initial render, enumerate all scenes, mirror/cottage/apple/resolution, navigation by pointer and keyboard, mobile fit, inspect code provenance and no runtime external assets. Assess narration and illustration scene by scene.

## Review

Each reviewer scores code and UI separately out of 10, giving five categories 0, 1 or 2 (absent/broken, partial, met). Code categories: build/brief fit, core behavior, edge cases, maintainability, tests/reproducibility. UI categories: visual coherence, readability, interaction feedback, keyboard/mobile use, task-specific depth or finish. Scores are reviewer judgments. Acceptance evidence and differences of opinion stay explicit. Claude receives frozen outputs and neutral labels without Codex scores.

## Telemetry

Keep native per-request timing, API usage, actual outbound sampling fields and time to first streamed content. Aggregate rates per task by total effective tokens divided by total applicable measured interval. Splash's prompt count includes reused tokens; subtract cache count. Strata's prompt count is already processed tokens. For generation infer the effective native token numerator from its reported rate and interval, retaining original fields. Report the observed allocation and utilization definitions, sample count, missing values, and whole-system background load. Separate the initial interrupted pilot before telemetry was enabled.
