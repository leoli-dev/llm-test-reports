# 独立代码与 UI 评审（盲评）

- 评审模型：Claude Opus 5.5（`claude-opus-5-5`），作为 Orca 派发的 worker 执行
- 评审日期：2026-11-26
- 输入：只读 `review/blind/`（各案例的 `source/`、`evidence/`、`url.txt`、`prompts/`）。没有读取协调者的评分和别名映射，也没有搜索上层实验目录。
- 评分：每个维度 5 项，每项取 0–2 分。代码维度依次为：构建与需求契合、核心行为、边界处理、可维护性、测试与可复现性。UI 维度依次为：视觉一致性、可读性、交互反馈、键盘与移动端可用性、任务深度与完成度。
- 证据分级：**[复现]** 表示我亲自运行并观察到；**[源码]** 表示阅读源码确认；**[证据]** 表示仅来自归档的 evidence；**[视觉判断]** 表示主观审美判断。截图只当作采集到的证据，不能据此认定交互通过。

## 我实际运行了什么

1. **浏览器**：Thorium，`/Applications/Thorium.app/Contents/MacOS/Thorium`，通过全局安装的 Playwright 1.62.1 的 `launchPersistentContext({executablePath})` 启动 headless 模式。每次运行都使用 scratchpad 下全新的临时 profile，结束后删除。CDP `Browser.getVersion` 返回 `Chrome/156.0.8078.28`，与 evidence 里的 Thorium 156.0.8078.28 一致。没有使用 Chrome，也没有连接任何已有浏览器。脚本放在 scratchpad 的 `probe/` 目录（`pos.js`、`story.js`、`tank.js`、`tankA2.js`）。
2. **Go 测试**：把两个 POS 的 `backend/` 复制到 scratchpad，用本机 Go 1.26.3 执行 `go vet`、`go test -count=1 ./...` 和 `gofmt -l`。项目只用标准库，没有安装任何依赖。对 pos-B，我还在 **scratch 副本**里做了一行修正后重跑，只用来判断其余测试是否成立。产品源码没有改动。
3. **tank-B 自带 harness**：复制到 scratchpad 后执行 `node harness.js`。
4. **对后端数据的改动**：只有正常的演示操作。pos-A 产生了 2 笔 Olive Oil 交易（各 2 件，其中 1 笔来自第一次脚本中断前，在卡支付单选框上按 Enter 触发了提交），pos-B 产生了 1 笔 Olive Oil 交易（2 件）。没有做重置，也没有其他写操作。
5. **没有验证的部分**：没有自己执行 `docker compose up --build`，也没有测试改端口和容器重启。持久化和端口相关结论来自 `evidence/api.json` 和当前在线实例。没有执行 `npm run build`。坦克游戏没有用真实触屏测试，音频也没有实际听。

---

## 一、POS（pos-A / pos-B）

### pos-A — 代码 10/10 `[2,2,2,2,2]`，UI 9/10 `[2,2,2,1,2]`

**代码**
- 需求契合：Go（只用标准库）+ Vue 3 + nginx 同源代理（`frontend/nginx.conf:11-18`）。Compose 把两个端口都绑定到回环地址，并支持 `POS_WEB_PORT` / `POS_API_PORT`（`docker-compose.yml:12,24`）。种子数据 26 个商品，含 SKU、分类、价格、库存，其中 Granola 故意只设 3 件库存，方便演示（`backend/seed.go`）。README 写清了运行、重置（`down -v`）、测试和 API 路由表。
- 核心行为 **[复现]**：在 Thorium 中按 `/` 聚焦搜索，输入 "olive"，用 Tab 切到 Add 后按 Enter，把数量改为 2，按 F2 打开支付。现金输入 1.00 时提示 "Tendered amount is less than the $20.64 total"；改为卡支付后提交，回执显示 R000005、小计 $18.98、税 $1.66、合计 $20.64。之后通过 API 查询，库存从 17 降到 15。
- 边界处理 **[源码]**：`store.go:256-268` 先按商品合并数量再校验库存，拆分成多行也绕不过库存检查。`store.go:261,274` 校验 ≤0 和 >99 的数量。小数数量会被 JSON 解码拒绝，返回 400。服务端忽略客户端传来的价格。持久化失败时回滚库存和单号（`store.go:327-345`）。写盘采用 tmp 文件加 rename 的原子写法。**[复现]** 在购物车里输入 999 会被截到库存上限，并弹出提示 "Only 17 × … in stock"（`App.vue:106-120`）。
- 可维护性：分层清楚，store、handlers、seed 和组件分离，体量小。小瑕疵是 `store.go` 没有过 gofmt（`Store` 结构体字段未对齐，`gofmt -l` 列出了它），以及超过 500 笔的旧销售记录会被静默截断（`store.go:346-349`），README 没有说明。
- 测试 **[复现]**：在 scratch 副本中 `go vet` 无输出，`go test` 结果为 `ok posapi`，与 `evidence/go-test.log` 一致。共 10 个测试，覆盖现金、卡支付、库存不足、合并行、非法数量、找零不足、价格篡改、重启持久化和并发防超卖。

**UI**
- 视觉与可读性 **[视觉判断]**：浅色卡片网格，分类 chip 和库存标签层次清楚，"Only 3 left" 用琥珀色提醒。回执采用等宽小票样式，可读性好。
- 交互反馈：有 toast、支付框内的错误提示（role=alert）、找零预览、快捷现金按钮，以及提交时的 "Processing…" 状态。
- 键盘与移动端（1 分）：键盘方面，`/`、F2、Esc 和 Tab 都能完成主流程 **[复现]**。但存在两个问题。**[复现]** 打开回执对话框后连续按 6 次 Tab，焦点全部落在背景元素上：`ReceiptDialog.vue:92` 的 `autofocus` 对动态插入的元素不生效，也没有焦点陷阱。另外，移动端 390px 宽时购物车位于 26 个商品之后，没有吸底的合计或结账入口，操作路径很长 **[证据截图+源码 `App.vue:332-334`]**。移动端没有横向溢出 **[复现]**。
- 任务深度：有回执打印、最近销售抽屉，以及按 SKU 片段搜索。

### pos-B — 代码 9/10 `[2,2,2,2,1]`，UI 9/10 `[2,2,2,1,2]`

**代码**
- 需求契合：Go + Vue + nginx 同源代理，代理使用延迟 DNS 解析（`nginx.conf:19-32`）。另外提供了 `.env.example`、Makefile、healthcheck，以及额外的 `/api/quote` 预估接口（`store.go:451-469`），README 有 210 行。
- 核心行为 **[复现]**：页面加载后搜索框自动获得焦点。输入 olive 后按 Alt+1 加入购物车，输入 999 被截到 14，改为 2 后右侧显示服务端 quote 的合计 $25.87（税率 8.25%）。按 Ctrl+Enter 直接以默认的精确现金完成支付，回执为 `20261126-0004`，库存从 14 降到 12。
- 边界处理 **[源码]**：这是两者中更严格的一个。请求使用严格 JSON 解码并拒绝未知字段（`handlers.go:106-125`）。有找零上下限检查（`store.go:501-511`）。合并 SKU 后对总量做上限校验（`store.go:360-392`）。写盘时 fsync 临时文件和目录（`store.go:242-274`）。数据目录有 flock，防止两个进程同时写（`store.go:176-184`）。前端 quote 请求有序号校验，过期响应会被丢弃（`App.vue:182-205`）。
- 可维护性：结构清晰，错误带有可读的 code。小问题有三处：4 个文件没有过 gofmt；`StockMove.SaleID` 字段始终没有赋值（`store.go:533`）；`invalid_quantity` 错误里也会带上 `"available":0`，容易误导（`evidence/api.json`）。
- 测试（1 分）**[复现]**：按交付状态，测试**无法编译**：`checkout_test.go:33:12: cannot use app.Stor.Close (value of type func() error) as func() value in argument to t.Cleanup`，与 `evidence/go-test.log` 相同。因此 `make test`（`Makefile:31-33`，用 docker build `--target test` 运行 `go test`）也会失败。在 scratch 副本中把这一行改成 `t.Cleanup(func(){ _ = app.Stor.Close() })` 后，14 个测试全部通过，测试本身设计很全面。但交付物不能直接运行测试，所以给 1 分。

**UI**
- 视觉与可读性 **[视觉判断]**：深色顶栏，有 "Register online · N sales on file" 状态胶囊，表格式回执带 MOCK 标记，整体完成度高。
- 交互反馈：数量变化后实时请求服务端 quote，库存问题会提前提示（`CartPanel.vue` 中的 `payHint`）。还有可关闭的 toast，以及标注 "Exact" 的找零建议。
- 键盘与移动端（1 分）：键盘体验是两者中最好的，包括自动聚焦、`/`、Ctrl+K、Alt+1–9、Ctrl+Enter，以及快捷键面板。**[复现]** 回执对话框有焦点陷阱，6 次 Tab 都留在对话框内。但移动端 **[复现]** 在 390px 宽时 `scrollWidth=494`，横向溢出来自 `.topbar-actions`、`.btn-ghost` 和 `.kbd-hint`，与 evidence 中失败的检查一致。截图里 "Shortcuts" 按钮被裁掉，顶栏文字也挤成了多行。
- 任务深度：有回执重打、Void 清空、模拟卡号后 4 位。

### POS A/B 对比
两者都满足需求核心，后端都以服务端为准，并经过合并行和并发测试。B 的后端防御更细（严格解码、fsync、flock、quote 接口），键盘快捷键和焦点管理也更好。但 B 交付的测试编译失败，移动端顶栏有可复现的横向溢出。A 更朴素，所有测试都能通过，移动端没有溢出，但回执对话框没有焦点管理，移动端结账路径长。综合看代码 A 略优（可直接运行的测试），UI 两者打平，各有一项硬伤。

---

## 二、白雪公主绘本（story-A / story-B）

### story-A — 代码 9/10 `[2,2,2,2,1]`，UI 9/10 `[2,2,2,2,1]`

**代码**
- 需求契合：6 个 inline SVG 场景（`index.html:34-898`），每个 svg 都有 `role="img"` 和 `aria-labelledby`。没有外部资源 **[复现]**：Thorium 网络日志中没有任何非 127.0.0.1 请求。有进度条（`role="progressbar"`）、"Scene n of 6" 计数和场景标题。
- 核心与边界 **[复现]**：在第 6 场按 → 停在第 6 场，在第 1 场按 ← 停在第 1 场；数字键 4 跳到第 4 场；在第 4 场左滑后进入第 5 场。首尾按钮会 disabled（`story.js:26-43`）。输入框内的按键会被忽略（`story.js:52`）。有 `prefers-reduced-motion`（`styles.css:304`）和移动端断点（`styles.css:311`）。390px 宽时没有横向溢出 **[复现]**。
- 可维护性：控制器只有 83 行，简洁。SVG 内联写在 HTML 中，属于预期做法。
- 测试与可复现：静态站点，README 提供了 `python3 -m http.server` 的运行方式。没有任何自动检查，因此给 1 分（两个故事案例同样处理）。
- 小问题：场景切换没有 aria-live 播报，但有 `aria-current` 和计数器。

**UI**
- 视觉 **[视觉判断]**：深蓝夜色加金色标题，配羊皮纸样式的说明牌和首字下沉，6 个场景风格统一。七个矮人有原创名字（Pip、Bram、Thistle 等），并且在 3 个场景中重复出现。整体是原创扁平插画风格，没有模仿电影形象。
- 可读性：说明牌放在插图**下方**，不遮挡画面 **[复现]**：桌面端说明与插图的重叠为 0%。文字对比度高。
- 交互反馈：进度条、计数器、标题、圆点高亮和按钮禁用状态都齐全。
- 任务深度（1 分）：构图因场景而异（镜子、黑森林、草顶小屋、苹果、玻璃棺加雪原、婚礼拱门）。扣分来自几处完成度问题：森林场景中主角的下半身被画框底边截断，苹果场景里白雪公主的造型比较含糊，不同场景的说明长度不同导致导航按钮的垂直位置跳动（证据截图中约 937–992px）。移动端插图只有约 278px 宽，显得偏小。

### story-B — 代码 8/10 `[2,2,1,2,1]`，UI 8/10 `[2,1,2,2,1]`

**代码**
- 需求契合：6 个 SVG 场景，用 symbol 复用元素（`index.html:13`），有 aria-live 播报（`story.js:60`），场景按钮使用 `role=tab` 和 `aria-controls`。没有外部请求 **[复现]**。
- 核心 **[复现]**：方向键、数字键、Home/End 和滑动都可用。390px 宽时没有溢出。
- 边界（1 分）**[复现]**：`goTo` 对场景序号取模循环（`story.js:44`）。在最后一场按 → 会回到第 1 场，在第 1 场按 ← 会跳到第 6 场。第 6 场已经显示 "Here Ends The Story"，但 Onward 按钮仍然可点，并且会把读者带回开头。按钮也从不禁用。此外 `ArrowUp/ArrowDown` 被截获（`story.js:77-83`），用键盘无法滚动页面。`role=tablist` 也没有实现方向键在 tab 之间移动的语义。
- 可维护性：JS 清楚，有注释。
- 测试与可复现：同 story-A，给 1 分。

**UI**
- 视觉 **[视觉判断]**：奶油色纸纹背景加深色画框，插图更大、更有电影感（暴雨闪电中的苹果场景、黎明的玻璃棺场景），风格统一。
- 可读性（1 分）**[复现]**：桌面端的说明牌 `.plate` 绝对定位在插图底部（`styles.css:170-179`），实测覆盖插图高度的 **35%**。我用 Thorium 截取第 4 场的视口截图后确认，白雪公主被说明文字完全遮住。森林场景的鹿和狐狸、小屋场景的矮人、结局场景的王子和公主，在 evidence 截图中同样都在说明牌后面。移动端的说明则移到了插图下方（`styles.css:319-345`），没有这个问题。
- 交互反馈：进度条、计数器加标题、aria-live 和聚焦描边都具备。
- 键盘与移动端：可用，移动端布局是 B 做得较好的部分。
- 任务深度（1 分）：构图有野心，但在主要的桌面视图里，关键人物多被遮挡。另外第 5 场的标题 "The Glass **Berthal**" 是一个不存在的词，正文中也这样写（`index.html:554`），属于文案错误。
- 属于截图伪影、不扣分的现象：evidence 全页截图顶部的白色条带，来自 `background-attachment: fixed`（`styles.css:29`）与全页截图的组合。我截的视口截图中没有出现，因此不算产品缺陷。

### Story A/B 对比
A 的插图与文字分区清楚，导航语义完整（到达首尾即停，按钮禁用），六个场景完整讲述了故事。B 的单幅画面更有氛围，移动端排版更好，可访问性播报也更全。但桌面端说明牌遮住了约三分之一的画面，主角在多个场景中看不见；首尾循环与 "Here Ends The Story" 也相互矛盾，还有一个不存在的词出现在标题里。A 综合更稳。

---

## 三、坦克游戏（tank-A / tank-B）

### tank-A — 代码 7/10 `[2,2,1,1,1]`，UI 7/10 `[1,1,2,2,1]`

**代码**
- 需求契合：在 Canvas2D 上手写了软件 3D 管线（`js/geo3d.js`），并实现了核心防守、3 种敌人、8 波、流场寻路（`game.js:373-428`）、可破坏木箱、拾取物和触屏摇杆。没有外部请求 **[证据+复现无 pageerror]**。
- 核心行为 **[复现]**：按 Enter 开始游戏，原地按住 Space 60 秒。约 25 秒后敌人接近，hull 和 core 开始掉血；30 秒时击毁 1 辆，分数 100，敌人数从 4 降到 3；55 秒时 hull 归零，出现结束卡片；按 Enter 重开后回到波次 1，分数 0。`Esc` 能暂停。整个过程没有 pageerror。`frame()` 先调用 `requestAnimationFrame`（`game.js:1537-1538`），出错时也不会停止循环。
- 边界（1 分）：
  - **[复现+源码]** 结束卡片的标题始终写 "CORE BREACHED"（`game.js:1621`）。我复现的情况是 hull 归零、core 还剩 83.3%，标题依然是 "CORE BREACHED"，只有副标题区分了原因。
  - **[源码]** `buildArena(level)` 为第 3 和第 5 关准备的额外掩体（`game.js:251-258`）永远不会生效：开局只调用 `buildArena(1)`（`game.js:1564`），之后再没有按关卡调用。实际上只有一张固定的镜像地图。
- 可维护性（1 分）：`game.js` 有 1689 行，写在一个 IIFE 里，依赖大量模块级可变状态。注释和分节都清楚，但耦合度高。
- 测试与可复现：没有测试，README 提供了运行方式，给 1 分。

**UI**
- 菜单和 HUD **[视觉判断]**：菜单卡片、按键提示和 HUD 面板完成度高，移动端菜单也排得很好。
- 视觉一致性与可读性（各 1 分）**[复现截图]**：这是本作最大的问题。游戏内画面在我自己的截图中（t=3s、中段、t=30s）呈现为大块半透明斜面和单面板。核心立方体占据大半个屏幕，玩家坦克只是一组绿色长条，敌人只是小方块，第一波大约 20 秒都看不到敌人。障碍物的 3D 高度和轮廓很难分辨，不符合需求里 "readable 3D height, obstacle silhouettes" 的要求。我没有判定这是投影 bug 还是设计选择，只评价可读性的结果。
- 交互反馈：屏幕震动、威胁环（`drawAimAssist`）、波次播报、伤害闪白都有。
- 键盘与移动端：键盘支持完整（WASD、方向键、Space、Shift、B、P/Esc、M，Enter 开局）。移动端有摇杆和 FIRE/BRAKE/BOOST 按钮，390px 宽时没有溢出 **[证据]**。但移动端游戏画面同样难以辨认 **[复现截图]**。
- 任务深度：循环完整（波次、清场奖励、拾取物、最高分存 localStorage），但战斗画面的可读性削弱了游戏手感。

### tank-B — 代码 3/10 `[1,0,0,1,1]`，UI 5/10 `[2,2,0,1,0]`

**代码**
- 需求契合（1 分）：设计层面最贴近需求，包括三个原创地图（SANDGATE FLATS、RAFFIA CONVOY、KORVEL BASTION）、BFS 流场、4 种敌人、独立炮塔瞄准和触屏摇杆。但游戏无法完成基本循环。
- 核心行为（0 分）**[复现]**，有两条互相独立的致命路径：
  1. **开启声音时开火**：`P.panner()` 对玩家自身位置调用 `IV.Audio.pan`。由于距离小于 1，返回的 `{node: A.master}` 不含 `atten`（`audio.js:70`），于是 `A.shoot` 中的 `0.28 * p.atten` 得到 NaN（`audio.js:92`），抛出 `TypeError: ... linearRampToValueAtTime ... non-finite`。`frame()` 把 `requestAnimationFrame` 放在末尾，又没有 try/catch（`game.js:1061-1086`），所以循环永久停止。我复现时，开火后 `game.t` 停在 0.92，后续 1.5 秒画面哈希不再变化。
  2. **静音时**：`Enemy.update` 调用了 `g.targetFor(this)`（`entities.js:241`），但出货的 `game.js` 里**没有定义** `targetFor`（全部 js 文件中都搜不到）。敌人出生 0.9 秒后抛出 `TypeError: g.targetFor is not a function`。我复现时，静音后 `game.t` 停在 2.27，此后 8 秒没有变化，画面冻结，与 `evidence/muted-browser.json` 一致。
  - 因此游戏结束和重开流程从未出现，evidence 中 90 秒超时也印证了这一点。
- 边界（0 分）**[源码+复现]**：`entities.js:251` 在 `var dx/dz/dist` 声明之前（第 255–256 行）就使用了它们，由于变量提升，值为 undefined，结果是 NaN。我在 scratch 副本中运行它自带的 `node harness.js`，复现了 `Error: NaN scout`，与 `evidence/generated-smoke.log` 一致。
- 可维护性（1 分）：模块拆分合理（math、audio、world、entities、render、game）。但交付物里留有 `game2.tmp.js`、`game3.tmp.js`、`game.js.tmp1`、`harness.js.tmp` 和 `merge.js`（会把 tmp 文件追加进 game.js），说明拼接流程没有收尾，缺失的 `targetFor` 很可能也是这个原因。
- 测试（1 分）：有 headless harness，README 第 92 行也提到了它，并且它确实能跑通渲染和地图冒烟测试。但它自身会在 NaN 断言处失败，而且 harness 为假 game 对象补上了 `targetFor`（`harness.js:109`），正好掩盖了真实缺陷。

**UI**
- 视觉与可读性 **[证据截图+复现]**：这是三个坦克案例中静态画面最好的。近俯视角度，方块有明显高度和阴影，坦克轮廓清楚，HUD 等宽字体统一，菜单简洁，还有 "SECTOR 1 — DEFEND THE CORE" 横幅。
- 交互反馈（0 分）：瞄准线、准星、边缘标记等在代码中都有，但几秒内就冻结，实际体验不到，也没有错误提示。
- 键盘与移动端（1 分）：控制映射完整，有触屏 DASH/FIRE。但移动端截图中 "SOUND: ON" 按钮压在右上 HUD 面板上 **[证据截图]**，而且实际无法游玩。
- 任务深度（0 分）：无法完成一局，也到不了游戏结束和重开。

### Tank A/B 对比
B 的渲染质量、关卡设计和代码分层都优于 A，但出货时有两处致命运行时错误（未定义的 `targetFor` 和音频 NaN），加上帧循环不容错，游戏在 1–2 秒内冻结。A 的画面可读性差，地图没有逐关变化，但它是三个坦克案例中唯一能完整走通 "开局 → 交战 → 击杀 → 失败 → 重开" 的。按 "可玩性优先"，A 明显胜出。

---

## 四、tank-formal 组（不同推理配置，单独评估）

### tank-formal-A — 代码 3/10 `[1,0,0,1,1]`，UI 2/10 `[1,1,0,0,0]`

- **致命启动错误 [复现+源码]**：`update()` 在 `game.js:518` 调用 `R.screenToGround(...)` 时，相机基向量 `this.right/upv/fwd` 还没有初始化。这些向量只在 `render()` 里的 `beginFrame` 中赋值（`engine.js:55-66`），而 `frame()` 先执行 update 再执行 render（`game.js:691-698`）。第一帧就抛出 `Cannot read properties of undefined (reading 'x')`（`engine.js:237`），而 `requestAnimationFrame` 在末尾，所以循环再也不会继续。我复现时画面哈希始终为 0（canvas 全空），只剩 DOM 层的 "IRONVALE / DEFEND THE CORE" 标题和 HUD。这是一行就能修的初始化顺序问题，但交付物完全不可玩。
- 需求契合（1 分）：设计上有 3 个命名地图（Ashfield Flats、Razor Gulch、Foundry Ring，见 `world.js:37-92`）、A* 寻路加路径平滑（`world.js:163-212`）、HQ 核心和波次，结构是 ES modules。但**没有任何触屏输入**（全仓库搜不到 touch 或 pointer），完全依赖鼠标瞄准。
- 可维护性（1 分）：模块划分清楚（engine、world、game）。小 bug：HUD 显示 "WAVE WAVE 1"，因为 `index.html:16` 已有 "WAVE" 前缀，`game.js:111` 又拼接了一次 `'WAVE ' + w`。
- 测试与可复现：没有测试，README 给出了运行方式，可以稳定复现上面的崩溃，给 1 分。
- UI：标题和 HUD 字体风格统一，可读，各 1 分。交互反馈、移动端和任务深度都是 0。移动端截图中，底部的控制提示还与 HULL/CORE 进度条重叠 **[证据截图]**。

### tank-formal-B — 代码 0/10，UI 0/10
`outcome.txt`："No files were delivered. The first request reached its output limit before any tool call." 没有任何交付物，按规则全部记 0。

### formal 组对比
formal-A 至少交付了结构合理的代码，但因为初始化顺序错误，首帧崩溃，没有画面；formal-B 什么都没有交付。两者都没有可用产品，formal-A 仅在 "有代码且问题可定位" 这一点上占优。这一组的推理配置不同，不应与上面的 tank-A/B 直接横向比较。

---

## 汇总

| 别名 | 代码 | UI | 关键依据 |
|---|---|---|---|
| pos-A | 10 | 9 | 测试全部通过；回执对话框没有焦点管理；移动端结账路径长 |
| pos-B | 9 | 9 | 测试编译失败（一行即可修复）；移动端溢出 494/390；键盘体验最佳 |
| story-A | 9 | 9 | 文字与插图分区；首尾停止；少量构图截断 |
| story-B | 8 | 8 | 桌面端说明遮挡插图 35%；首尾循环；"Berthal" |
| tank-A | 7 | 7 | 可完整游玩一局；3D 画面可读性差；单一地图 |
| tank-B | 3 | 5 | `targetFor` 未定义加音频 NaN，1–2 秒后冻结 |
| tank-formal-A | 3 | 2 | 首帧崩溃，不渲染；没有触屏 |
| tank-formal-B | 0 | 0 | 无交付 |

## 不确定与需要注意的地方
- POS 的 Docker 构建、自定义端口和容器重启持久化，我没有亲自运行，依据是 evidence 中的 api.json 和当前在线实例都正常。
- tank-A 画面难以辨认，可能来自投影或剔除的实现问题，也可能是镜头参数（`geo3d.js:62-69`）造成的。我只按观察到的结果评分，没有断言根因。
- tank-A 的敌人在开局约 20 秒内都没有进入视野。这可能与地图尺度和出生点有关，我没有测量具体距离。
- story-B 首尾循环是否算缺陷有一定主观性。我扣分是因为它与 "Here Ends The Story" 和 Onward 的语义冲突。
- 视觉判断（插画质量、可读性）是本评审者的主观看法，已与可复现的缺陷分开标注。
