"""Run POS behavior probes against the isolated stack."""
import json
import os
import subprocess
import time
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

BASE = "http://127.0.0.1:" + os.environ["POS_API_PORT"]
WEB = "http://127.0.0.1:" + os.environ["POS_WEB_PORT"]
SKU = "SOUR-LOAF"
checks = []


def request(path, payload=None, base=BASE):
    body = json.dumps(payload).encode() if payload is not None else None
    try:
        response = urlopen(Request(base + path, data=body, headers={"Content-Type": "application/json"}), timeout=5)
    except HTTPError as error:
        response = error
    with response:
        return response.status, json.load(response)


def check(name, ok, evidence):
    checks.append({"check": name, "ok": bool(ok), "evidence": evidence})


def product():
    code, catalog = request(f"/api/products?q={SKU}")
    if code != 200:
        raise RuntimeError(f"catalog returned HTTP {code}")
    return next(row for row in catalog["products"] if row["sku"] == SKU)


def checkout(method, quantity, tendered=10000):
    return request("/api/checkout", {
        "items": [{"sku": SKU, "qty": quantity, "unit_price_cents": 1}],
        "payment": method, "tendered_cents": tendered, "total_cents": 1,
    })


try:
    code, via_web = request("/api/health", base=WEB)
    check("web-origin proxy works on reassigned port", code == 200 and via_web.get("status") == "ok", via_web)
    first = product()
    before = first["stock"]
    code, result = checkout("cash", 0)
    check("quantity zero rejected", 400 <= code < 500, {"status": code, "body": result})
    code, result = checkout("cash", before+1)
    check("insufficient stock rejected", 400 <= code < 500, {"status": code, "body": result})
    code, result = request("/api/checkout", {
        "items": [{"sku": SKU, "qty": before - 1}, {"sku": SKU, "qty": 2}], "payment": "card",
    })
    check("duplicate lines together exceeding stock rejected", 400 <= code < 500,
          {"status": code, "body": result})
    current = product()["stock"]
    check("rejections leave inventory unchanged", current == before, {"stock": current})
    for method in ("cash", "card"):
        code, result = checkout(method, 1, 535 if method == "cash" else None)
        sale = result.get("sale", {})
        check(f"{method} sale ignores client price and returns a receipt",
              code in (200, 201) and bool(sale.get("id")) and sale.get("payment") == method
              and sale.get("subtotal_cents") == first["price_cents"], {"status": code, "body": sale})
        check(f"{method} receipt charges the stated 7.25% and exact total",
              sale.get("subtotal_cents") == 499 and sale.get("tax_cents") == 36 and sale.get("total_cents") == 535
              and (method != "cash" or sale.get("change_cents") == 0), {"status": code, "body": sale})
    current = product()["stock"]
    check("inventory decremented twice", current == before - 2, {"stock": current, "was": before})
    before_status, before_history = request("/api/sales")
    subprocess.run(["docker", "compose", "restart", "api"], check=True, capture_output=True, timeout=45)
    for attempt in range(30):
        try:
            if request("/api/health")[0] == 200:
                break
        except (URLError, OSError):
            pass
        time.sleep(1)
    after_status, after_history = request("/api/sales")
    check("sales survive backend restart", before_status == after_status == 200 and before_history == after_history,
          {"status": after_status, "count": len(after_history.get("sales", []))})
    current = product()["stock"]
    check("inventory survives backend restart", current == before - 2, {"stock": current})
except Exception as error:
    check("runner completed", False, repr(error))

print(json.dumps(checks, indent=2))
raise SystemExit(0 if all(row["ok"] for row in checks) else 1)
