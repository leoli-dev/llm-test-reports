# Claude review — POS candidate E

**Model under test:** Qwen3.8-27B, `unsloth/Qwen3.8-27B-GGUF` UD-Q8_K_XL (draft `incoai/Qwen3.8-27B-DFlash2`), per `evidence/model-provenance.json`.
**Reviewer:** Claude Opus 5.5 (`claude-opus-5-5`). Browser: Thorium 156.0.8078.28 via Playwright `executablePath`.

| Code | Score | UI | Score |
|---|---|---|---|
| Build / brief fit | 1 | Visual coherence | 2 |
| Core behavior | 2 | Readability | 2 |
| Edge cases | 2 | Interaction feedback | 2 |
| Maintainability | 2 | Keyboard / mobile use | 1 |
| Tests / reproducibility | 1 | POS workflow finish | 2 |
| **Code total** | **8/10** | **UI total** | **9/10** |

## Firsthand probes
- **Go tests (disposable copy, go1.26.3):** `go vet` clean; `go test -race ./...` **FAIL** — 12/13 pass, `TestCheckoutDuplicateLinesCannotBypassStock` fails. The test sends 3+3 SOUR-LOAF against stock 6, which is a legal sale, so the backend is right and the assertion is wrong. Coverage 50.9%, store-level only (no HTTP handler tests). `gofmt -l` flags `store.go`.
- **API (port 18411 proxy and 18412):** health OK through the same-origin proxy. Rejected with no side effects: duplicate mixed-case lines over stock (422), qty −1 / 1.5 / "2" / huge (400), unknown SKU, empty cart, bad payment (400), cash short or missing tender (422), garbage body (400), unknown sale (404), unknown route/method (404). Sales stayed at 5 throughout. Search `?q=dairy` is correct.
- **Desktop 1440×900:** `/` focuses search, Tab moves to Add, and Enter adds. All controls have a visible 3px focus ring. Typing qty 50 is clamped to stock (2) with no message. Tendering $5 shows "Short by $5.27" and disables Charge. Tab to Charge then Enter makes **cash sale S-00006**: the receipt opens with focus on Done, and Esc closes it. Stock refreshes after the sale (Sourdough 2→1). No console errors.
- **Mobile 390×844:** no horizontal scroll. Honey add, +, Card, then Charge makes **card sale S-00007**. The receipt dialog fits the viewport. Two authorized sales used (S-00006, S-00007).
- Running stack ports: `127.0.0.1:18411/18412`, which comes from the evaluation override.

## Supplied evidence (not re-derived)
`compose-build.log` (build and both containers healthy), `go-test.log` (shows the same FAIL), `go-vet.log` (empty/clean), `api.json` (proxy on reassigned port, rejections, cash/card sales S-00001/2), `browser.json` plus 4 screenshots.

## Concrete defects
1. **Shipped test suite fails** (`store_test.go:144-155`): the 3+3 vs stock 6 assertion is wrong. The README's `go test ./...` happy path is red.
2. **Not loopback-bound** (`docker-compose.yml`): ports are `"${POS_API_PORT:-18102}:8080"`, which binds 0.0.0.0, but the brief asks for loopback ports. Generic image tags `pos-api`/`pos-web` can collide.
3. **Persist failure leaves inconsistent state** (`store.go` Checkout): stock and sale are committed in memory before `saveUnlocked`. On error the client gets a 500, but the in-memory sale stays and is written on the next save.
4. **No `package-lock.json`.** The frontend uses `npm install` with caret ranges, so builds are not reproducible. `depends_on` ignores the api healthcheck.
5. **Mobile cart is buried:** it sits below all 14 cards (~2150px down) with no sticky total or jump link. Qty −/+/✕ targets are 30×30, below 44px.
6. **Receipt dialog has no focus trap:** Tab from Done escapes to `<body>` and the page behind. The cash receipt shows change twice ("$9.73 back" and a "Change $9.73" row).
7. Minor issues:
   - Qty clamp to stock is silent.
   - The checkout error banner is not cleared on cart edits.
   - Search requests have no stale-response guard.
   - Routes also match without the `/api` prefix (`/health` returns 200).
   - Dev `vite.config.js` proxies to 18102 while `go run` defaults to :8080.

## Verdict
Strong, idiomatic and well-documented POS. The backend is correctly authoritative: it aggregates duplicates, uses integer cents and atomic JSON writes, and data persists in a volume. The UI is calm and readable with good keyboard affordances. The main deductions are the failing shipped test, the non-loopback compose binding, and mobile cart reachability.
