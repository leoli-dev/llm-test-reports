# Review: POS candidate D ("Marigold Market")

- **Reviewer model:** Claude Opus 5.5 (`claude-opus-5-5`), running as an Orca worker in the Claude Agent SDK
- **Date:** 2026-11-26
- **Candidate reviewed:** `pos-splash-27b-rerun/review/pos-D` (frozen)
- **Brief:** `prompts/pos.txt`
- **Diagnostic copy:** web http://127.0.0.1:18401/, API http://127.0.0.1:18402/
- **Browser:** Thorium 156.0.8078.28 (headless, driven by Playwright with `executablePath` set to Thorium)
- **Transactions I made:** two mock sales. `S-000006` was a card sale on desktop and `S-000007` was a cash sale on a 390 px mobile viewport. Every other probe was either a rejected request or used a network-intercepted fake response, so no other sale was recorded.
- **What I left alone:** the original source, the diagnostic source and the running stack. All tests ran in disposable copies in my scratchpad.

I did not open benchmark timings, prior model results, Codex scores, `evidence/report-*.md`, or `evidence/eval`.

## Headline

**As submitted, the product does not build.** In `backend/internal/store/store.go`, the `Store` struct has exported fields `Products` and `Sales`, and also methods named `Products()` and `Sales()`. Go rejects that, so `go build`, `go test` and the Docker api stage all fail. `docker compose up --build` therefore never starts.

With only the methods renamed (the diagnostic copy), the app looks polished and most of the validation works. The money is wrong, though:

- `TaxPerMille = 750` means a **75%** tax, while the README, the UI labels and the receipt all say 7.5%.
- The frontend estimates totals at 7.5%, so the total shown at checkout does not match what the server charges.

## Scores

### Code, as submitted (0–2 each)

| Dimension | Score | Rationale |
|---|---|---|
| Build / brief fit | **0** | The Go stage fails to compile, so `docker compose up --build` fails and nothing runs. Compose publishes `"${POS_API_PORT:-18102}:8080"` and `"${POS_WEB_PORT:-18101}:80"` without `127.0.0.1`, so both bind to all interfaces. The brief requires loopback, and the README claims "loopback only". Fixed `container_name: pos-api/pos-web` will collide with other stacks. On the plus side, the overall shape fits the brief: Go plus Vue 3, one Compose file, an nginx same-origin `/api` proxy, a named volume, and configurable port variables. |
| Core behavior | **0** | Nothing runs as delivered. Even after the rename fix, every sale over-charges by 67.5 percentage points: 899¢ comes out as 674¢ tax and 1573¢ total. The UI quotes one total and the server charges another. |
| Edge cases | **1** | Server-side validation is good. It rejects zero, negative and fractional quantities (400), more than 10 000 per line or merged duplicates (400), unknown SKUs (400), unknown payment types (400), short cash (400), and insufficient stock (409, with stock left unchanged). The weak spots:<br>• If `Save()` fails after stock has been decremented and the sale appended in memory, the client gets a 400 but memory keeps the change. Repro: memory shows stock 39 and 1 sale while the file still has 40.<br>• `Categories()` reads `s.Products` without the mutex, which `go test -race` flags.<br>• A card sale stores whatever `tendered` the client sends.<br>• No request body size limit. |
| Maintainability | **1** | The layering is clean: `store` / `api` / `main`, integer cents, typed errors mapped to HTTP status codes, small Vue components, and a readable README. Against that:<br>• The field/method name collision is a basic mistake that a single compile would have caught.<br>• The tax rate is duplicated between client and server (`TAX_RATE = 0.075` against `TaxPerMille = 750`) and the two disagree.<br>• `lower` and `contains` are hand-rolled instead of using `strings`.<br>• The checkout request JSON example in the README is malformed: it closes with `]` instead of `}`. |
| Tests / reproducibility | **0** | `go test ./...` fails to compile. After the rename fix, 1 of 12 tests still fails: `TestProductSearchAndCategory` expects `q=coffee` to match only names or SKUs, but the handler also matches categories. The tax tests recompute the expected value from the same `TaxPerMille` constant, so they cannot catch the 75% bug. The reset, test and port-change instructions are documented but cannot be followed as written. |
| **Code total** | **2 / 10** | |

### UI, as submitted (0–2 each)

The submitted Compose stack never reaches a served page because the api image build aborts `docker compose up --build`. As a delivered product, the UI scores **0** on every dimension, for a total of **0 / 10**.

### UI, diagnostic judgment (rename-only patch plus loopback/network override)

| Dimension | Score | Rationale |
|---|---|---|
| Visual coherence | **2** | Consistent warm-neutral palette with a green accent, a clean card grid, category chips, a sticky cart panel on desktop, and well-shaped modals. The receipt has a convincing thermal-receipt style. The desktop and mobile screenshots look deliberate rather than templated. |
| Readability | **2** | Large prices, SKUs in monospace, amber low-stock highlighting, and a clear cart total hierarchy. Nits: the receipt number wraps (`Receipt #S-` / `000007`) beside the timestamp in the 400 px receipt, and the mobile header clock wraps onto two lines. |
| Interaction feedback | **1** | Good: in-cart badges on cards, stock-limit toasts, an inline server error in the checkout modal, a "Processing…" busy label, live change and "Short by" for cash, and stock refreshed after a sale. Problems:<br>• Every displayed total is an estimate that disagrees with the server.<br>• The cash error appears in raw cents ("tendered 1234 is less than total 2009").<br>• The **Print** button throws `TypeError: Cannot read properties of undefined (reading 'print')`, because Vue templates have no `window` global. Nothing happens and no error is shown.<br>• A stale "Cart cleared" toast lingers over later modals. |
| Keyboard / mobile use | **1** | Good: search is focused on load, `/` focuses search, arrows plus `Enter` add from search or grid, `+`/`-` adjust, `F` opens checkout, `Esc` closes, there is a visible 3 px focus ring, and a shortcut bar. Problems:<br>• Dialogs do not move focus inside (focus stays on `BODY`) and do not trap it: Tab leaves the receipt dialog after two stops.<br>• Focus is lost to `BODY` after **New sale**.<br>• **Global shortcuts still fire behind the open checkout modal.** `+` raises a quantity and `C` clears the whole cart, leaving the dialog open at "0 items · total $0.00".<br>• Product cards are `div`s with a roving tabindex and no role.<br>• On mobile (390×844) the cart, total and Checkout button sit at y≈3187 px in a 3662 px page, below all 20 products, with no sticky summary or cart link.<br>• Chips are about 28 px tall, small for touch.<br>• No horizontal overflow. |
| POS workflow finish | **0** | A card sale does produce a readable receipt and decrements stock. However, the money path breaks the core POS contract:<br>• The cart and checkout show $12.34, the server charges $20.09, and the receipt labels $8.61 tax as "Tax (7.5%)".<br>• The default cash flow pre-fills the *exact* (client) total, which the server rejects every time.<br>• Printing the receipt is broken. |
| **Diagnostic UI total** | **6 / 10** | |

## Reproduced findings

These are first-hand from this review. Artifacts are in `evidence/review/claude-artifacts/`.

1. **Original build fails.** Running `go build ./...` on a disposable copy of `pos-D/backend` gives `field and method with the same name Products` / `Sales`, plus `cannot assign to s.Products …`. See `orig-go-build.log`. This matches `review/evidence/compose-original-build.log` at Dockerfile line 16.
2. **Compose is not loopback-bound.** `docker compose config` on a disposable copy of the original shows `published: "18102"` and `"18101"` with no `host_ip`.
3. **Tax is 75%, not 7.5%.**
   - A store probe test gives subtotal 899, tax 674, total 1573; 7.5% would be 67.
   - Live sale `S-000006`: subtotal 1148, tax 861, total 2009.
   - Live sale `S-000007`: subtotal 1098, tax 824, total 1922.
   - Existing ledger entries S-000001 to S-000005 show the same ratio.
4. **Client and server totals differ, so exact cash is rejected.**
   - Desktop cart: House Blend + Croissant shows Total $12.34. The Cash option auto-fills 12.34 and shows "Change due $0.00".
   - Clicking **Take cash** returns 400 `tendered 1234 is less than total 2009`. Screenshot: `d3-exact-cash-rejected.png`.
   - On mobile the quick-tender buttons offered $11.80 / $15.00 / $20.00 against a real total of $19.22. Only $20.00 would have worked.
5. **Receipt misreports tax.** "Tax (7.5%) $8.61" on a $11.48 subtotal. See `probe-log.json` and `m4-receipt.png`.
6. **Print button is broken.** With `window.print` stubbed, clicking **Print** calls it 0 times and logs `TypeError: Cannot read properties of undefined (reading 'print')`.
7. **Shortcuts leak behind the checkout modal.**
   - With checkout open and focus on the Card radio, `+` changes the modal summary from "3 items · total $8.03" to "4 items · total $10.71".
   - `C` then clears the cart to "0 items · total $0.00", the dialog stays open and Charge is disabled.
   - Screenshot: `d2-shortcut-leak.png`.
8. **Dialog focus is not managed.** Focus is on `BODY` when checkout or the receipt opens. Tab leaves the receipt dialog to the search box and chips. Focus is on `BODY` after **New sale**.
9. **Mobile cart is far below the products.** At 390×844 the cart starts at y≈3187 px of a 3662 px page, and there is no sticky checkout affordance (`m1-register-full.png`, `m2-cart.png`). A typed quantity of 99 on Sourdough is clamped to 12 with an "Only 12 in stock" toast, which is correct.
10. **Server validation works on the live diagnostic API.**

    | Request | Result |
    |---|---|
    | qty 1.5 | 400 (JSON decode) |
    | qty −2 | 400 |
    | unknown SKU | 400 |
    | cash tendered 100¢ | 400 |
    | payment `bitcoin` | 400 |
    | HH-703 ×999 | 409, stock still 6 |
    | malformed JSON | 400 |
    | `/api/sales/S-999999` | 404 |

    There were no external requests and no page errors other than the Print `TypeError` and the expected 400 log.
11. **The diagnostic test suite fails one test.** `TestProductSearchAndCategory` fails because the handler matches on category; see `diag-go-test.log`. The other 11 pass, including `TestPersistenceAcrossRestart`.
12. **Persistence error path leaves memory out of sync with disk.** I made the data directory read-only, then ran a checkout. It returned an error, but memory showed stock 39 and sales 1 while disk kept 40 and 0.
13. **Data race.** `go test -race` flags `Categories()` reading `s.Products` while `Checkout` writes it. Under 20 concurrent buys of HH-703 (seed stock 6), stock ended at 0 with exactly 6 sales, so checkout itself serializes correctly.

Probe sources: `probe.cjs`, `probe2.cjs` (network-intercepted receipt render, no sale recorded) and `probe_test.go`.

**Note:** in screenshots taken right after the receipt appears, `d4-card-receipt.png` and the prior `review/evidence/desktop-cash-receipt.png`, the receipt modal is invisible. That is only its 150 ms `pop` fade-in: after waiting, `d5-receipt-mocked-network.png` shows it rendered with opacity 1. It is not a defect.

## Evidence-only findings

These come from `review/evidence` and I did not re-run them.

- **Original Docker Compose build log.** The api-builder fails at Dockerfile line 16 while the web stage builds. I reproduced the same compiler errors locally with Go 1.26, but did not re-run Docker.
- **Persistence across a container restart** (`api.json`: two sales and stock 38 survive an api restart). I did not restart the running stack, to leave it intact. The in-process `TestPersistenceAcrossRestart` passes in my run, and the code writes atomically with temp file plus rename to `/data/pos.json` on the named volume.
- **Earlier evidence runs saw the same total mismatches.** `browser.json` desktop expected $19.33 and got $31.47; mobile expected $2.68 and got $4.36. Both are consistent with finding 3.
- **Port changes were not tested live.** The same-origin proxy (`/api` → `api:8080` in nginx, relative `fetch('/api…')`) should be port-independent by inspection.

## Diagnostic vs. original

The diagnostic copy differs from the original only in the patch in `review/evidence/diagnostic.patch`:

- **Original:** `Products()` / `Sales()`.
- **Diagnostic:** `ListProducts()` / `ListSales()`, plus the call sites, plus a Compose override that binds to 127.0.0.1 on 18401/18402 with an isolated network.

Every runtime observation above comes from that diagnostic copy and would not exist for a user running the submission as delivered. The tax bug, UI totals mismatch, Print bug, shortcut leak and focus issues are all in the unmodified frontend and store logic, so they would carry over to any minimally fixed build.
