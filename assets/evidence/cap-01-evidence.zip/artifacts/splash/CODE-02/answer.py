def minPath(grid, k):
    """
    Given a grid with N rows and N columns (N >= 2) and a positive integer k,
    each cell of the grid contains a value. Every integer in the range [1, N * N]
    inclusive appears exactly once on the cells of the grid.

    You have to find the minimum path of length k in the grid. You can start
    from any cell, and in each step you can move to any of the neighbor cells,
    in other words, you can go to cells which share an edge with you current
    cell.
    Please note that a path of length k means visiting exactly k cells (not
    necessarily distinct).
    You CANNOT go off the grid.
    A path A (of length k) is considered less than a path B (of length k) if
    after making the ordered lists of the values on the cells that A and B go
    through (let's call them lst_A and lst_B), lst_A is lexicographically less
    than lst_B, in other words, there exist an integer index i (1 <= i <= k)
    such that lst_A[i] < lst_B[i] and for any j (1 <= j < i) we have
    lst_A[j] = lst_B[j].
    It is guaranteed that the answer is unique.
    Return an ordered list of the values on the cells that the minimum path go
    through.

    Examples:

        Input: grid = [ [1,2,3], [4,5,6], [7,8,9]], k = 3
        Output: [1, 2, 1]

        Input: grid = [ [5,9,3], [4,1,6], [7,8,2]], k = 1
        Output: [1]
    """
    n = len(grid)

    # Locate the cell holding value 1 (the lexicographically best start).
    start_r = start_c = 0
    for r in range(n):
        for c in range(n):
            if grid[r][c] == 1:
                start_r, start_c = r, c
                break
        if grid[start_r][start_c] == 1:
            break

    dirs = ((1, 0), (-1, 0), (0, 1), (0, -1))
    r, c = start_r, start_c
    path = [grid[r][c]]

    # Greedy: at every step the next cell must be a (distinct-valued)
    # neighbor. Since N >= 2 every cell has at least one neighbor, any
    # neighbor can always be extended into a full path of length k, so the
    # lexicographically smallest achievable next value is simply the
    # smallest-valued neighbor.
    for _ in range(k - 1):
        best = None
        best_r = best_c = None
        for dr, dc in dirs:
            nr, nc = r + dr, c + dc
            if 0 <= nr < n and 0 <= nc < n:
                v = grid[nr][nc]
                if best is None or v < best:
                    best, best_r, best_c = v, nr, nc
        path.append(best)
        r, c = best_r, best_c

    return path
