"""Solution for minPath: find the lexicographically minimum path of length k.

Since every value 1..N*N appears exactly once, the minimum path must start
at the cell containing 1 (the unique smallest starting value). Once the
prefix of a path is fixed, its current position is determined (values are
unique), so each next value can only be a value of a neighboring cell.
Therefore a greedy choice of the smallest-valued neighbor at every step
yields the lexicographically smallest path, and revisits are allowed by
the problem statement.
"""


def minPath(grid, k):
    """
    Given a grid with N rows and N columns (N >= 2) and a positive integer k,
    each cell of the grid contains a value. Every integer in the range
    [1, N * N] inclusive appears exactly once on the cells of the grid.

    You have to find the minimum path of length k in the grid. You can start
    from any cell, and in each step you can move to any of the neighbor cells,
    in other words, you can go to cells which share an edge with you current
    cell.
    Please note that a path of length k means visiting exactly k cells (not
    necessarily distinct).
    You CANNOT go off the grid.
    A path A (of length k) is considered less than a path B (of length k) if
    after making the ordered lists of the values on the cells that A and B go
    through (let's call them lst_A and lst_B), lst_A is lexicographically less
    than lst_B, in other words, there exist an integer index i (1 <= i <= k)
    such that lst_A[i] < lst_B[i] and for any j (1 <= j < i) we have
    lst_A[j] = lst_B[j].
    It is guaranteed that the answer is unique.
    Return an ordered list of the values on the cells that the minimum path
    go through.

    Examples:

        Input: grid = [ [1,2,3], [4,5,6], [7,8,9]], k = 3
        Output: [1, 2, 1]

        Input: grid = [ [5,9,3], [4,1,6], [7,8,2]], k = 1
        Output: [1]
    """
    n = len(grid)

    # Locate the cell holding the value 1 (unique smallest possible start).
    row = col = -1
    for i in range(n):
        for j in range(n):
            if grid[i][j] == 1:
                row, col = i, j
                break
        if row != -1:
            break

    result = [1]
    if k == 1:
        return result

    # Greedily move to the smallest-valued neighbor at each step.
    for _ in range(k - 1):
        best_r = best_c = -1
        best_val = None
        for dr, dc in ((-1, 0), (1, 0), (0, -1), (0, 1)):
            nr, nc = row + dr, col + dc
            if 0 <= nr < n and 0 <= nc < n:
                val = grid[nr][nc]
                if best_val is None or val < best_val:
                    best_val = val
                    best_r, best_c = nr, nc
        result.append(best_val)
        row, col = best_r, best_c

    return result
