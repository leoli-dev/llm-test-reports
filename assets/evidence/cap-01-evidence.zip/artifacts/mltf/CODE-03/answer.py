def order_by_points(nums):
    """
    Write a function which sorts the given list of integers
    in ascending order according to the sum of their digits.
    Note: if there are several items with similar sum of their digits,
    order them based on their index in original list.

    For example:
    >>> order_by_points([1, 11, -1, -11, -12]) == [-1, -11, 1, -12, 11]
    >>> order_by_points([]) == []
    """
    def digit_sum(n):
        return sum(int(ch) for ch in str(abs(n)))

    # sorted() is stable, so items with equal digit sums
    # keep their original relative (index) order.
    return sorted(nums, key=digit_sum)
