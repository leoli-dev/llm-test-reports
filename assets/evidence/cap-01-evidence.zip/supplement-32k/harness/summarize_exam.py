"""Read completed first-attempt sessions. Never invoke inference or repair outputs."""
from pathlib import Path
import json,hashlib,statistics,sys,subprocess
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'grading'));from evaluate import score_text
EXAM=json.loads((ROOT/'exam.json').read_text());byid={t['id']:t for t in EXAM['tasks']}
def summarize():
 records=[]
 for d in sorted((ROOT/'.local/runs').iterdir()):
  if not d.is_dir() or not (d/'complete.json').exists():continue
  launch=json.loads((d/'launch.json').read_text());task=byid[launch['task']];r=json.loads((d/'result.json').read_text()) if (d/'result.json').exists() else {};backend=launch['backend'];case={'case':d.name,'backend':backend,'task':task['id'],'domain':task['domain'],'title':task['title'],'pi_wall_seconds':r.get('pi_wall_seconds'),'timeout':r.get('timeout'),'assistant_stops':r.get('assistant_stops',[]),'request_errors':r.get('request_errors',[]),'artifacts':r.get('output_files',[]),'operator_intervention':r.get('operator_intervention'),'timing_incomplete':r.get('timing_incomplete',False),'pi_cleanup_after_agent_settled':r.get('pi_cleanup_after_agent_settled',False),'error':json.loads((d/'run-error.json').read_text()) if (d/'run-error.json').exists() else None}
  reqs=[json.loads(p.read_text()) for p in sorted(d.glob('request-*-result.json'))];case['requests']=[{k:q.get(k) for k in ['input_tokens_preflight','token_ids_sha256','formatted_prompt_sha256','preflight_seconds','upstream_wall_seconds','first_model_event_seconds','first_content_seconds','usage','finish_reason','errors']} for q in reqs];case['initial_token_hash']=reqs[0].get('token_ids_sha256') if reqs else None;case['usage_incomplete']=any(q.get('upstream_started_unix_seconds') and not q.get('usage') for q in reqs);case['timing_incomplete']=case['timing_incomplete'] or any(q.get('upstream_started_unix_seconds') and 'upstream_wall_seconds' not in q for q in reqs);case['total_reasoning_tokens']=sum(q.get('usage',{}).get('completion_tokens_details',{}).get('reasoning_tokens',0) for q in reqs);case['total_completion_tokens']=sum(q.get('usage',{}).get('completion_tokens',0) for q in reqs);case['upstream_total_seconds']=sum(q.get('upstream_wall_seconds',0) for q in reqs);case['initial_input_tokens']=reqs[0].get('input_tokens_preflight') if reqs else None
  scorefile=d/'score.json'
  if not scorefile.exists() and not task['artifact']:
   score=score_text(task['id'],r.get('final_text',''));scorefile.write_text(json.dumps(score,indent=2)+'\n')
  case['scoring']=json.loads(scorefile.read_text()) if scorefile.exists() else {'score':None,'pending':'artifact execution or visual rubric'};records.append(case)
 pairs=[]
 for task in EXAM['tasks']:
  a=[r for r in records if r['task']==task['id']]
  if len(a)==2:pairs.append({'task':task['id'],'same_initial_token_ids':bool(a[0]['initial_token_hash']) and a[0]['initial_token_hash']==a[1]['initial_token_hash'],'input_counts':[r['initial_input_tokens'] for r in a]})
 groups={}
 for b in ['mltf','splash']:
  group={}
  for domain in EXAM['domains']:
   rs=[r for r in records if r['backend']==b and r['domain']==domain];scores=[r['scoring']['score'] for r in rs if r['scoring'].get('score') is not None];planned=sum(t['domain']==domain for t in EXAM['tasks']);group[domain]={'planned':planned,'recorded':len(rs),'scored':len(scores),'mean':statistics.mean(scores) if len(scores)==planned else None}
  values=[x['mean'] for x in group.values() if x['mean'] is not None];groups[b]={'domains':group,'overall':statistics.mean(values) if len(values)==2 else None}
 result={'planned_sessions':8,'recorded_sessions':len(records),'records':records,'paired_prompt_audit':pairs,'groups':groups};(ROOT/'.local/summary.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');return result
if __name__=='__main__':
 r=summarize();print(json.dumps({'recorded':r['recorded_sessions'],'results':[{k:x[k] for k in ['case','domain','pi_wall_seconds','initial_input_tokens','total_completion_tokens','scoring']} for x in r['records']],'paired_audit':r['paired_prompt_audit']},ensure_ascii=False))
