"""Audit first-attempt provenance without invoking models or changing outputs."""
from pathlib import Path
import hashlib,json,subprocess
ROOT=Path(__file__).resolve().parents[1]
def sha(b):return hashlib.sha256(b).hexdigest()
def main():
 exam=json.loads((ROOT/'exam.json').read_text());assert (ROOT/'.local/generation-complete.json').exists()
 frozen=[]
 for name in ['exam.json','grading/evaluate.py',*[t['prompt'] for t in exam['tasks']],*['grading/'+t['id']+'.json' for t in exam['tasks']]]:
  original=subprocess.check_output(['git','show','2aaf3f6:supplement-32k/'+name],cwd=ROOT);actual=(ROOT/name).read_bytes();assert original==actual,name;frozen.append({'path':name,'sha256':sha(actual)})
 cases=[];resources=[];cross_phase=[]
 for case in sorted((ROOT/'.local/runs').iterdir()):
  launch=json.loads((case/'launch.json').read_text());task=next(t for t in exam['tasks'] if t['id']==launch['task']);events=[json.loads(x) for x in (case/'pi-events.jsonl').read_text().splitlines()];start=next(e for e in events if e['type']=='session_start');assert start['model']['contextWindow']==131072 and start['model']['maxTokens']==32768 and start['thinkingLevel']=='medium'
  status=json.loads((case/'status-before.json').read_text());assert status['maximum_context_tokens']==131072
  req=[]
  for path in sorted(case.glob('request-*-payload.json')):
   p=json.loads(path.read_text());assert (p['temperature'],p['top_p'],p['top_k'],p['reasoning_effort'],p['max_tokens'])==(1,.95,20,'medium',32768)
   result=json.loads(path.with_name(path.name.replace('-payload','-result')).read_text());n=result['input_tokens_preflight'];assert n+32768<=131072
   req.append({'index':result['index'],'input_tokens':n,'input_plus_reserved_output':n+32768,'errors':result['errors'],'stream_done':result.get('stream_done',False)})
  delivered=[]
  for name in json.loads((case/'result.json').read_text()).get('output_files',[]):
   p=ROOT/'artifacts'/launch['backend']/launch['task']/name;assert p.is_file(),p
   writes=[e for e in events if e['type']=='tool_call' and e.get('name')=='write' and e.get('allowed') and (e['input'].get('path')==name or e['input'].get('path','').endswith('/'+name))]
   assert writes,'File lacks same-session write provenance: '+str(p)
   content=writes[-1]['input']['content'].encode();assert p.read_bytes()==content,'Artifact/write mismatch: '+str(p)
   delivered.append({'path':name,'sha256':sha(content),'matches_same_session_write':True})
  samples=[json.loads(line) for line in (case/'resources.jsonl').read_text().splitlines()];active=[x for x in samples if x.get('phase')=='inference'];number=lambda key:[x[key] for x in active if isinstance(x.get(key),(int,float))]
  resources.append({'case':case.name,'inference_samples':len(active),'engine_allocator_peak_bytes':max(number('engine_allocation_peak_bytes'),default=None),'native_process_footprint_peak_bytes':max(number('process_physical_footprint_bytes'),default=None),'frontend_footprint_peak_bytes':max(number('frontend_physical_footprint_bytes'),default=None),'global_gpu_memory_peak_bytes':max(number('gpu_in_use_system_memory_bytes'),default=None),'native_cpu_percent_mean':sum(number('process_cpu_percent'))/len(number('process_cpu_percent')) if number('process_cpu_percent') else None,'global_gpu_util_percent_mean':sum(number('gpu_device_utilization_percent'))/len(number('gpu_device_utilization_percent')) if number('gpu_device_utilization_percent') else None,'global_pressure_states':sorted({x.get('memory_pressure_name','unknown') for x in active}),'global_swap_first_bytes':next((x.get('swap_used_bytes') for x in samples if x.get('swap_used_bytes') is not None),None),'global_swap_last_bytes':next((x.get('swap_used_bytes') for x in reversed(samples) if x.get('swap_used_bytes') is not None),None)})
  primary=next(p for p in (ROOT.parent/'.local/runs').iterdir() if p.name.endswith('-'+launch['backend']+'-'+launch['task']));old=json.loads((primary/'request-00-result.json').read_text());new=json.loads((case/'request-00-result.json').read_text());cross_phase.append({'backend':launch['backend'],'task':launch['task'],'primary_input_tokens':old['input_tokens_preflight'],'supplement_input_tokens':new['input_tokens_preflight'],'same_initial_token_ids':old['token_ids_sha256']==new['token_ids_sha256'],'known_difference':'Pi injects this phase workspace path in <cwd>, adding seven input tokens. Frozen task and neutral system files are unchanged.'})
  cases.append({'case':case.name,'actual_context_tokens':status['maximum_context_tokens'],'native_build_id':status.get('identity',{}).get('cache',{}).get('build_id'),'loaded_layout_sha256':status.get('identity',{}).get('cache',{}).get('loaded_model_layout_sha256'),'target_model_sha256':status.get('identity',{}).get('kv',{}).get('target_model_sha256'),'kv_format':status.get('identity',{}).get('kv',{}).get('format'),'requests':req,'delivered_files':delivered,'initial_cache_tokens':json.loads(next(iter(sorted(case.glob('request-*-result.json')))).read_text()).get('usage',{}).get('prompt_tokens_details',{}).get('cached_tokens')})
 assert len(cases)==8
 result={'freeze_commit':'2aaf3f6','frozen_files':frozen,'cases':cases,'cross_phase_initial_input_comparison':cross_phase,'resource_summary':resources,'resource_scope_note':'Counters overlap on unified memory and must not be added. GPU/pressure/swap are system-wide, background apps were not controlled. First/last swap describe observation, not test-attributable allocation.','all_artifacts_match_same_session_write':True,'all_requests_match_fixed_settings':True,'all_requests_fit_131072_without_truncation':True};(ROOT/'.local/execution-audit.json').write_text(json.dumps(result,indent=2)+'\n');print('Audited 8 supplementary sessions, frozen packet, every request and delivered source.')
if __name__=='__main__':main()
