"""Evaluate preserved output files only after all inference has stopped."""
from pathlib import Path
import ast,hashlib,json,os,shutil,subprocess,sys,time,signal,xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'.local/evaluation';OUT.mkdir(exist_ok=True)
BLENDER=Path('/Applications/Blender.app/Contents/MacOS/Blender');BEXEC=Path('$HOME/.agents/skills/blender-exec/scripts/blender-exec')
def write(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
def run(cmd,work,log,timeout,env=None):
 with log.open('wb') as f:
  proc=subprocess.Popen(cmd,cwd=work,stdout=f,stderr=subprocess.STDOUT,env=env,start_new_session=True)
  try:return {'returncode':proc.wait(timeout=timeout),'timeout':False}
  except subprocess.TimeoutExpired:
   try:os.killpg(proc.pid,signal.SIGTERM)
   except ProcessLookupError:pass
   try:proc.wait(timeout=5)
   except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.wait(timeout=5)
   return {'returncode':proc.returncode,'timeout':True}

def profile(work):
 # Retain normal macOS runtime access, deny network, private home reads and
 # all filesystem writes except this evaluation workspace and /dev/null.
 paths=[str(BEXEC.parent.parent),str(ROOT/'grading'),str(ROOT/'harness/scene_summary.py'),str(work)]
 return '(version 1)(allow default)(deny network*)(deny file-read* (subpath "$HOME"))(allow file-read* '+''.join('(subpath '+json.dumps(p)+')' for p in paths)+')(deny file-write*)(allow file-write* (subpath '+json.dumps(str(work))+') (literal "/dev/null"))'

def main():
 assert (ROOT/'.local/generation-complete.json').exists(),'Wait for inference completion; never render concurrently'
 exam=json.loads((ROOT/'exam.json').read_text());tasks={t['id']:t for t in exam['tasks']}
 for case in sorted((ROOT/'.local/runs').iterdir()):
  launch=json.loads((case/'launch.json').read_text());t=tasks[launch['task']]
  if not t['artifact']:continue
  b=launch['backend'];src=ROOT/'artifacts'/b/t['id'];work=OUT/(b+'-'+t['id']);work.mkdir(exist_ok=False);source=src/t['artifact'];result={'task':t['id'],'source':str(source),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest() if source.exists() else None,'errors':[]}
  if not source.exists():write(case/'score.json',{'task':t['id'],'score':0,'artifact_gate_failed':True,'error':'Required artifact missing'});continue
  try:
   if t['id'].startswith('CODE'):
    shutil.copyfile(source,work/'answer.py');cmd=['/opt/homebrew/bin/python3','-I',str(ROOT/'grading/evaluate.py'),'--python-child',t['id'],str(work/'answer.py')];r=run(['/usr/bin/sandbox-exec','-p',profile(work),*cmd],work,work/'execution.log',30,{'PATH':'/opt/homebrew/bin:/usr/bin:/bin','HOME':str(work),'TMPDIR':str(work),'PYTHONNOUSERSITE':'1'})
    lines=(work/'execution.log').read_text().splitlines();score=json.loads(lines[-1]) if lines and lines[-1].startswith('{') else {'score':0,'error':'Grader execution failed','execution':r};write(case/'score.json',score);result.update(execution=r,scoring=score)
   elif t['id'].startswith('SVG'):
    svg=ET.fromstring(source.read_text());assert svg.tag.split('}')[-1]=='svg'
    for e in svg.iter():
     assert e.tag.split('}')[-1] not in ['script','image','foreignObject'],'Non-vector or scripted/external element'
     for k,v in e.attrib.items():
      if k.split('}')[-1] in ['href','src']:assert v.startswith('#'),'External resource'
    r=run(['node',str(ROOT/'harness/render_svg.mjs'),str(source),str(src/'render.png')],work,work/'execution.log',60);assert r['returncode']==0 and (src/'render.png').exists(),'SVG render failed';result['render']=r;result['pending_visual_rubric']=True
   else:
    code=source.read_text();tree=ast.parse(code)
    for n in ast.walk(tree):
     if isinstance(n,(ast.Import,ast.ImportFrom)):
      names=[a.name for a in n.names] if isinstance(n,ast.Import) else [n.module or ''];assert all(x.split('.')[0] in (set(sys.stdlib_module_names)|{'bpy','mathutils'}) for x in names),'Unexpected scene import'
    shutil.copyfile(source,work/'scene.py');(work/'tmp').mkdir();(work/'home').mkdir();env={'PATH':'/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin','HOME':str(work/'home'),'TMPDIR':str(work/'tmp'),'BLENDER_BIN':str(BLENDER),'BLENDER_EXEC_TIMEOUT':'900','PYTHONNOUSERSITE':'1'}
    r=run(['/usr/bin/sandbox-exec','-p',profile(work),str(BEXEC),'code',str(work/'scene.py'),'--bg'],work,work/'execution.log',930,env);result['execution']=r
    for name in ['final.blend','render.png']:
     if (work/name).exists():shutil.copyfile(work/name,src/name)
    assert r['returncode']==0 and (src/'final.blend').is_file() and (src/'render.png').is_file(),'Missing/failed Blender project or render'
    r2=run(['/usr/bin/sandbox-exec','-p',profile(work),str(BLENDER),'--background','--factory-startup','--disable-autoexec',str(work/'final.blend'),'--python',str(ROOT/'harness/scene_summary.py')],work,work/'inspection.log',90,env);assert r2['returncode']==0 and (work/'scene-summary.json').exists(),'Project inspection failed';shutil.copyfile(work/'scene-summary.json',src/'scene-summary.json');result['inspection']=r2;result['pending_visual_rubric']=True
  except Exception as e:
   result['errors'].append(repr(e));write(case/'score.json',{'task':t['id'],'score':0,'artifact_gate_failed':True,'error':repr(e)})
  assert hashlib.sha256(source.read_bytes()).hexdigest()==result['source_sha256'],'Submitted source modified'
  write(src/'evaluation.json',result);print(json.dumps({'case':case.name,'errors':result['errors'],'visual_pending':result.get('pending_visual_rubric',False)}),flush=True)
if __name__=='__main__':main()
