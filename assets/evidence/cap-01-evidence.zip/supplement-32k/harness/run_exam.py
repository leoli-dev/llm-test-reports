"""Run actual Pi CLI, fresh native servers, frozen prompts; no scoring feedback."""
from pathlib import Path
import copy,hashlib,http.server,json,os,re,shutil,signal,socket,struct,subprocess,sys,threading,time,urllib.request
ROOT=Path(__file__).resolve().parents[1];LOCAL=Path('$LOCAL_LLMS_ROOT');PRIVATE=ROOT/'.local';RUNS=PRIVATE/'runs';RUNS.mkdir(exist_ok=True)
sys.path.insert(0,str(LOCAL/'splash/records/benchmarks/2026-10-21-perf06-replay'));from resource_collector import ResourceCollector
EXAM=json.loads((ROOT/'exam.json').read_text());GLOBAL=json.loads(Path('$HOME/.pi/agent/models.json').read_text());WORK=PRIVATE/'work'
MODEL={'mltf':'local/Qwen3.8-27B-MLTF-q8c','splash':'mlx-community/Qwen3.8-27B-8bit'}
KEY={b:GLOBAL['providers'][b]['apiKey'] for b in MODEL}
ORDER=[(b,t) for i,t in enumerate(EXAM['tasks']) for b in (['mltf','splash'] if i%2==0 else ['splash','mltf'])]
def dump(p,v):
 tmp=p.with_suffix(p.suffix+'.tmp');tmp.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n');tmp.replace(p)
def api(base,path,b,payload=None,timeout=15):
 q=urllib.request.Request(base+path,data=None if payload is None else json.dumps(payload).encode(),headers={'Authorization':'Bearer '+KEY[b],'Content-Type':'application/json'})
 with urllib.request.urlopen(q,timeout=timeout) as r:return json.load(r)
def stop_group(p):
 if p is None:return
 try:os.killpg(p.pid,signal.SIGTERM)
 except ProcessLookupError:pass
 try:p.wait(timeout=20)
 except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=5)
def free(port):
 with socket.socket() as s:s.settimeout(.5);return s.connect_ex(('127.0.0.1',port))!=0
class Proxy(http.server.ThreadingHTTPServer):daemon_threads=True;allow_reuse_address=True
class Handler(http.server.BaseHTTPRequestHandler):
 def log_message(self,*args):pass
 def do_POST(self):
  svc=self.server;directory=svc.directory;idx=svc.count;svc.count+=1;tag=f'request-{idx:02d}';raw=self.rfile.read(int(self.headers['Content-Length']));payload=json.loads(raw);start=time.monotonic();record={'received_unix_seconds':time.time(),'errors':[],'index':idx};dump(directory/(tag+'-payload.json'),payload)
  try:
   assert self.path=='/v1/chat/completions',self.path
   assert payload.get('model')==MODEL[svc.backend]
   assert payload.get('temperature')==1 and payload.get('top_p')==.95 and payload.get('top_k')==20,payload.keys()
   assert payload.get('reasoning_effort')=='medium' and payload.get('max_tokens')==32768
   formatted=api(svc.base,'/apply-template',svc.backend,{**payload,'add_generation_prompt':True},180)['prompt']
   ids=api(svc.base,'/tokenize',svc.backend,{'content':formatted,'add_special':False},180)['tokens'];count=len(ids)
   assert count+32768<=131072,f'Input {count}+32768 exceeds 128K; no truncation allowed'
   record.update(formatted_prompt_sha256=hashlib.sha256(formatted.encode()).hexdigest(),token_ids_sha256=hashlib.sha256(b''.join(struct.pack('<I',n) for n in ids)).hexdigest(),input_tokens_preflight=count,preflight_seconds=time.monotonic()-start)
   svc.phase['phase']='inference';q=urllib.request.Request(svc.base+self.path,data=raw,headers={'Authorization':'Bearer '+KEY[svc.backend],'Content-Type':'application/json'});forward=time.monotonic();record['upstream_started_unix_seconds']=time.time();parts=[];first=None
   with urllib.request.urlopen(q,timeout=1800) as upstream,(directory/(tag+'-sse.jsonl')).open('w') as evidence:
    self.send_response(upstream.status);self.send_header('Content-Type','text/event-stream');self.send_header('Connection','close');self.end_headers()
    for line in upstream:
     now=time.monotonic();self.wfile.write(line);self.wfile.flush()
     if line.startswith(b'data:'):
      data=line[5:].strip()
      if data==b'[DONE]':record['stream_done']=True;continue
      if not data:continue
      chunk=json.loads(data);entry={'unix_seconds':time.time(),'relative_seconds':now-forward,'chunk':chunk};evidence.write(json.dumps(entry,ensure_ascii=False)+'\n');evidence.flush()
      for c in chunk.get('choices') or []:
       d=c.get('delta') or {};text=d.get('content') or '';reason=d.get('reasoning_content') or ''
       if (text or reason or d.get('tool_calls')) and 'first_model_event_seconds' not in record:record['first_model_event_seconds']=now-forward
       if text:
        if first is None:first=now;record['first_content_seconds']=now-forward
        record['last_content_seconds']=now-forward;parts.append(text)
       if c.get('finish_reason') is not None:record['finish_reason']=c['finish_reason']
      if chunk.get('usage'):record['usage']=chunk['usage']
      if chunk.get('timings'):record['timings']=chunk['timings']
      if chunk.get('metrics'):record['metrics']=chunk['metrics']
   record['upstream_wall_seconds']=time.monotonic()-forward;record['content']=''.join(parts);record['status_after']=api(svc.base,'/status',svc.backend,timeout=5)
  except Exception as e:
   record['errors'].append(repr(e))
   try:self.send_error(502,str(e))
   except Exception:pass
  finally:record['finished_unix_seconds']=time.time();dump(directory/(tag+'-result.json'),record);svc.phase['phase']='between_requests'
def sample(proc,b,base,directory,phase,done):
 c=ResourceCollector(proc.pid,'mltf',status_callback=lambda:api(base,'/status',b,timeout=2));critical=0
 with (directory/'resources.jsonl').open('w') as f:
  while not done.is_set():
   tick=time.monotonic();r=c.collect(stage='exam',phase=phase['phase']);r['backend']=b;f.write(json.dumps(r)+'\n');f.flush();critical=critical+1 if r.get('memory_pressure_name')=='critical' else 0
   if critical>=15 or (r.get('process_physical_footprint_bytes') or 0)>115*2**30:
    dump(directory/'resource-abort.json',{'reason':'critical15 or footprint>115GiB'});stop_group(proc);return
   done.wait(max(.05,1-(time.monotonic()-tick)))
def one(index,b,task):
 id=f'{index:02d}-{b}-{task["id"]}';d=RUNS/id
 if (d/'complete.json').exists():print(json.dumps({'case':id,'skip':'already recorded; no resampling'}),flush=True);return
 d.mkdir(exist_ok=False);port=8083 if b=='mltf' else 8084;base=f'http://127.0.0.1:{port}';assert free(port) and free(8096),'Refusing to replace existing service'
 if WORK.exists():shutil.rmtree(WORK)
 WORK.mkdir();agent=d/'agent-config';agent.mkdir(mode=0o700)
 selected=copy.deepcopy(GLOBAL['providers'][b]);selected['baseUrl']='http://127.0.0.1:8096/v1';selected['models']=[x for x in selected['models'] if x['id']==MODEL[b]];selected['models'][0]['maxTokens']=32768;dump(agent/'models.json',{'providers':{b:selected}});(agent/'models.json').chmod(0o600)
 dump(agent/'settings.json',{'defaultProvider':b,'defaultModel':MODEL[b],'defaultThinkingLevel':'medium','packages':[],'extensions':[],'skills':[],'prompts':[],'compaction':{'enabled':False},'cacheWarming':'off','retry':{'enabled':False,'provider':{'maxRetries':0}},'quietStartup':True,'images':{'autoResize':False}})
 env=dict(os.environ,TZ='America/Toronto',SPLASH_API_KEY=KEY[b],HF_HUB_OFFLINE='1',MLTF_NO_UPDATE_CHECK='1',HF_HUB_CACHE=str(LOCAL/'models/splash/huggingface/hub'))
 if b=='splash':
  env['PYTHONPATH']=str(LOCAL/'splash/source');prepared=(LOCAL/'splash/records/benchmarks/2026-10-21-perf06-replay/prepared-model-path.txt').read_text().strip()
  cmd=[str(LOCAL/'splash/source/.venv/bin/python'),'-P','-m','server.server',prepared,'--model',MODEL[b],'--binary',str(LOCAL/'splash/source/build/splash'),'--host','127.0.0.1','--port',str(port),'--default-reasoning-effort','medium','--kv-format','int8','--state-format','fp32','--max-memory','96G','--max-context','128K','--max-cache-disk','0','--idle-release','off','--no-webui']
 else:
  env['MLTF_DATA_ROOT']=str(d/'runtime-data');cmd=[str(LOCAL/'mltf/.venv/bin/mltf'),'serve','--model',MODEL[b],'--model-path',str(LOCAL/'models/Qwen3.8-27B-MLTF-q8c/prepared-q8c'),'--host','127.0.0.1','--port',str(port),'--default-reasoning-effort','medium','--kv-format','int8','--max-memory','96G','--max-context','128K','--max-concurrent-requests','1','--no-webui','--no-update-check']
 logfile=(d/'server.log').open('w');proc=subprocess.Popen(cmd,cwd=LOCAL,env=env,stdout=logfile,stderr=subprocess.STDOUT,start_new_session=True);phase={'phase':'startup'};done=threading.Event();sampler=threading.Thread(target=sample,args=(proc,b,base,d,phase,done),daemon=True);sampler.start();proxy=None;pi=None;started=time.time();dump(d/'launch.json',{'backend':b,'task':task['id'],'pid':proc.pid,'command':cmd,'started_unix_seconds':started,'prompt_sha256':task['prompt_sha256']});print(json.dumps({'case':id,'state':'starting'}),flush=True)
 try:
  deadline=time.monotonic()+900
  while time.monotonic()<deadline:
   if proc.poll() is not None:raise RuntimeError('Native server exited during startup')
   try:
    status=api(base,'/status',b,timeout=2)
    if status.get('ready') is True:break
   except Exception:pass
   time.sleep(1)
  else:raise RuntimeError('Readiness deadline')
  assert status['maximum_context_tokens']==131072 and status['metal']['healthy'];dump(d/'status-before.json',status)
  proxy=Proxy(('127.0.0.1',8096),Handler);proxy.directory=d;proxy.backend=b;proxy.base=base;proxy.count=0;proxy.phase=phase;threading.Thread(target=proxy.serve_forever,daemon=True).start()
  penv=dict(os.environ,PI_CODING_AGENT_DIR=str(agent),PI_OFFLINE='1',PI_TELEMETRY='0',EXAM_WORK=str(WORK),EXAM_EVENTS=str(d/'pi-events.jsonl'),EXAM_MAX_TURNS=str(task['max_turns']))
  pcmd=['pi','--offline','--print','--mode','json','--provider',b,'--model',MODEL[b],'--thinking','medium','--no-session','--no-context-files','--no-extensions','--no-mcp','--no-skills','--no-prompt-templates','--no-themes','--no-approve','--system-prompt',(ROOT/'harness/system.txt').read_text(),'--extension',str(ROOT/'harness/guard.ts')]
  pcmd+=['--tools',','.join(task['tools'])] if task['tools'] else ['--no-tools']
  phase['phase']='pi_session';t0=time.monotonic();print(json.dumps({'case':id,'state':'pi_started'}),flush=True)
  with (ROOT/task['prompt']).open('rb') as inp,(d/'pi-output.jsonl').open('wb') as out,(d/'pi-stderr.log').open('wb') as err:
   pi=subprocess.Popen(pcmd,cwd=WORK,env=penv,stdin=inp,stdout=out,stderr=err,start_new_session=True)
   deadline=time.monotonic()+task['wall_timeout_seconds'];timeout=False;forced_cleanup=False;settled=None
   while pi.poll() is None:
    if time.monotonic()>=deadline:timeout=True;stop_group(pi);break
    output=d/'pi-output.jsonl'
    if output.exists():
     with output.open('rb') as f:f.seek(max(0,output.stat().st_size-24000));tail=f.read()
     if re.search(br'"type"\s*:\s*"agent_settled"',tail):
      if settled is None:settled=time.monotonic()
      elif time.monotonic()-settled>3:forced_cleanup=True;stop_group(pi);break
    time.sleep(.25)
   rc=pi.returncode
  msgs=[];malformed=0
  for line in (d/'pi-output.jsonl').read_text().splitlines():
   try:e=json.loads(line)
   except Exception:malformed+=1;continue
   if e.get('type')=='message_end' and e.get('message',{}).get('role')=='assistant':msgs.append(e['message'])
  text=[''.join(c.get('text','') for c in m.get('content',[]) if c.get('type')=='text') for m in msgs];(d/'final.txt').write_text(text[-1] if text else '')
  dest=ROOT/'artifacts'/b/task['id'];dest.mkdir(parents=True,exist_ok=True)
  for p in WORK.rglob('*'):
   if p.is_file() and not p.is_symlink():target=dest/p.relative_to(WORK);target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,target)
  requests=[json.loads(p.read_text()) for p in sorted(d.glob('request-*-result.json'))];result={'case':id,'backend':b,'task':task['id'],'pi_wall_seconds':time.monotonic()-t0,'pi_returncode':rc,'pi_cleanup_after_agent_settled':forced_cleanup,'pi_generation_settled_seconds':settled-t0 if settled is not None else None,'timeout':timeout,'malformed_lines':malformed,'assistant_stops':[m.get('stopReason') for m in msgs],'assistant_usage':[m.get('usage') for m in msgs],'requests':len(requests),'request_errors':[e for r in requests for e in r['errors']],'output_files':[str(p.relative_to(dest)) for p in dest.rglob('*') if p.is_file()],'final_text':text[-1] if text else '', 'status_after':api(base,'/status',b,timeout=10)};dump(d/'result.json',result);dump(d/'complete.json',{'recorded':True,'finished_unix_seconds':time.time()});print(json.dumps({k:result[k] for k in ['case','pi_wall_seconds','assistant_stops','requests','request_errors','output_files']}),flush=True)
 except Exception as e:dump(d/'run-error.json',{'error':repr(e),'unix_seconds':time.time()});dump(d/'complete.json',{'recorded':True,'failed':True});print(json.dumps({'case':id,'error':repr(e)}),flush=True)
 finally:
  stop_group(pi)
  if proxy:proxy.shutdown();proxy.server_close()
  done.set();sampler.join(timeout=6);stop_group(proc);logfile.close();dump(d/'exit.json',{'pid':proc.pid,'returncode':proc.returncode,'finished_unix_seconds':time.time()})
 if index==0 and not any(json.loads(p.read_text()).get('upstream_started_unix_seconds') for p in d.glob('request-*-result.json')):raise RuntimeError('First case submitted no generation; inspect Pi adapter before continuing')
def main():
 dump(PRIVATE/'run-plan.json',{'question_freeze':'primary 77eea8d; separate visual supplement protocol commit','max_tokens_per_turn':32768,'order':[{'index':i,'backend':b,'task':t['id']} for i,(b,t) in enumerate(ORDER)],'no_resampling':True})
 dump(PRIVATE/'hardware.json',{'captured_unix_seconds':time.time(),'os':subprocess.check_output(['sw_vers'],text=True),'chip':subprocess.check_output(['sysctl','-n','machdep.cpu.brand_string'],text=True).strip(),'memory_bytes':int(subprocess.check_output(['sysctl','-n','hw.memsize'],text=True)),'cpu_cores':18,'gpu_cores':40,'architecture':'arm64','power':subprocess.check_output(['pmset','-g','batt'],text=True),'pi_version':subprocess.check_output(['pi','--version'],text=True).strip()})
 for i,(b,t) in enumerate(ORDER):one(i,b,t)
 dump(PRIVATE/'generation-complete.json',{'planned':len(ORDER),'finished_unix_seconds':time.time()})
if __name__=='__main__':main()
