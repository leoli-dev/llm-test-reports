# City diorama for a new development show-stand:
# round plaza with fountain in the center, one tall glass-curtain office tower,
# four low residential blocks, a ring of trees, street lamps, paved plaza,
# green lawn, sunny noon light, slightly high bird's-eye camera.
# Blender 5.1, headless-safe, Cycles CPU, <= 32 samples.
# Outputs (relative paths): final.blend, render.png

import bpy
import math
from mathutils import Vector

# ---------------------------------------------------------------- fresh scene
bpy.ops.wm.read_factory_settings(use_empty=True)

scene = bpy.context.scene
scene.render.engine = 'CYCLES'
scene.cycles.device = 'CPU'
scene.cycles.samples = 24
scene.cycles.use_denoising = True
try:
    scene.cycles.denoiser = 'OPENIMAGEDENOISE'
except Exception:
    pass

scene.render.resolution_x = 1280
scene.render.resolution_y = 720
scene.render.resolution_percentage = 100
scene.render.image_settings.file_format = 'PNG'
scene.render.image_settings.color_mode = 'RGB'

try:
    scene.view_settings.view_transform = 'AgX'
    scene.view_settings.look = 'AgX - Medium High Contrast'
except Exception:
    try:
        scene.view_settings.view_transform = 'Filmic'
        scene.view_settings.look = 'Medium High Contrast'
    except Exception:
        pass

# ------------------------------------------------------------------- helpers
def set_in(node, name, value):
    if name in node.inputs:
        node.inputs[name].default_value = value

def new_material(name):
    m = bpy.data.materials.new(name)
    m.use_nodes = True
    bsdf = m.node_tree.nodes.get("Principled BSDF")
    return m, bsdf

def mat_simple(name, color, rough=0.6, metal=0.0, transmission=0.0, ior=1.45,
               emit=None, emit_str=0.0):
    m, b = new_material(name)
    set_in(b, 'Base Color', color)
    set_in(b, 'Roughness', rough)
    set_in(b, 'Metallic', metal)
    set_in(b, 'IOR', ior)
    if transmission > 0.0:
        set_in(b, 'Transmission Weight', transmission)
        if 'Transmission' in b.inputs:
            b.inputs['Transmission'].default_value = transmission
    if emit is not None:
        set_in(b, 'Emission Color', emit)
        set_in(b, 'Emission Strength', emit_str)
    return m

def mat_paving(name):
    m = bpy.data.materials.new(name)
    m.use_nodes = True
    nt = m.node_tree
    b = nt.nodes.get("Principled BSDF")
    tc = nt.nodes.new('ShaderNodeTexCoord')
    brick = nt.nodes.new('ShaderNodeTexBrick')
    brick.inputs['Color1'].default_value = (0.78, 0.78, 0.76, 1.0)
    brick.inputs['Color2'].default_value = (0.70, 0.70, 0.68, 1.0)
    brick.inputs['Mortar'].default_value = (0.58, 0.58, 0.56, 1.0)
    brick.inputs['Scale'].default_value = 1.0
    brick.inputs['Mortar Size'].default_value = 0.015
    brick.inputs['Brick Width'].default_value = 1.1
    brick.inputs['Row Height'].default_value = 1.1
    nt.links.new(tc.outputs['Object'], brick.inputs['Vector'])
    nt.links.new(brick.outputs['Color'], b.inputs['Base Color'])
    set_in(b, 'Roughness', 0.55)
    return m

def smooth(obj):
    for p in obj.data.polygons:
        p.use_smooth = True

def link(obj):
    bpy.context.collection.objects.link(obj)
    return obj

def add_box(name, sx, sy, sz, loc, mat, rot_z=0.0):
    hx, hy, hz = sx * 0.5, sy * 0.5, sz * 0.5
    verts = [
        (-hx, -hy, -hz), (hx, -hy, -hz), (hx, hy, -hz), (-hx, hy, -hz),
        (-hx, -hy, hz), (hx, -hy, hz), (hx, hy, hz), (-hx, hy, hz),
    ]
    faces = [
        (0, 1, 2, 3), (7, 6, 5, 4),
        (0, 4, 5, 1), (2, 6, 7, 3),
        (1, 5, 6, 2), (0, 3, 7, 4),
        (0, 1, 5, 4),  # placeholder, replaced below
    ]
    faces = [
        (0, 1, 2, 3), (7, 6, 5, 4),
        (0, 4, 5, 1), (1, 5, 6, 2),
        (2, 6, 7, 3), (3, 7, 4, 0),
    ]
    me = bpy.data.meshes.new(name)
    me.from_pydata(verts, [], faces)
    me.update()
    me.normals_make_consistent(inside=False)
    ob = bpy.data.objects.new(name, me)
    ob.location = loc
    if rot_z:
        ob.rotation_euler[2] = rot_z
    ob.data.materials.append(mat)
    return link(ob)

def add_cyl(name, r, depth, loc, mat, segs=32):
    bpy.ops.mesh.primitive_cylinder_add(vertices=segs, radius=r, depth=depth,
                                        location=loc)
    ob = bpy.context.active_object
    ob.name = name
    ob.data.materials.append(mat)
    return ob

def add_sphere(name, r, loc, mat, scale=(1, 1, 1)):
    bpy.ops.mesh.primitive_uv_sphere_add(segments=24, ring_count=16, radius=r,
                                         location=loc)
    ob = bpy.context.active_object
    ob.name = name
    ob.scale = scale
    ob.data.materials.append(mat)
    smooth(ob)
    return ob

def add_ico(name, r, loc, mat, scale=(1, 1, 1), subdiv=2):
    bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=subdiv, radius=r,
                                          location=loc)
    ob = bpy.context.active_object
    ob.name = name
    ob.scale = scale
    ob.data.materials.append(mat)
    smooth(ob)
    return ob

def add_ring(name, r_out, r_in, y0, y1, mat, segs=28):
    verts = []
    for i in range(segs):
        a = 2.0 * math.pi * i / segs
        c, s = math.cos(a), math.sin(a)
        verts.append((r_out * c, r_out * s, y0))   # 4i   outer bottom
        verts.append((r_in * c, r_in * s, y0))     # 4i+1 inner bottom
        verts.append((r_out * c, r_out * s, y1))   # 4i+2 outer top
        verts.append((r_in * c, r_in * s, y1))     # 4i+3 inner top
    faces = []
    for i in range(segs):
        j = (i + 1) % segs
        o0, i0, o1, i1 = 4 * i, 4 * i + 1, 4 * j, 4 * j + 1
        faces.append((o0, o1, i1, i0))             # bottom annulus
        faces.append((o0 + 2, o1 + 2, i1 + 2, i0 + 2))  # top annulus
        faces.append((o0, o0 + 2, o1 + 2, o1))     # outer wall
        faces.append((i0, i1 + 2, i1, i0 + 2))     # inner wall
    me = bpy.data.meshes.new(name)
    me.from_pydata(verts, [], faces)
    me.update()
    me.normals_make_consistent(inside=False)
    ob = bpy.data.objects.new(name, me)
    ob.data.materials.append(mat)
    return link(ob)

def aim(obj, target):
    d = Vector(target) - obj.location
    obj.rotation_euler = d.to_track_quat('-Z', 'Y').to_euler()

# ---------------------------------------------------------------- materials
mat_grass   = mat_simple("Lawn", (0.045, 0.30, 0.05), rough=0.95)
mat_pave    = mat_paving("PlazaPaving")
mat_stone   = mat_simple("FountainStone", (0.55, 0.55, 0.54), rough=0.5)
mat_stone_d = mat_simple("FountainDark", (0.12, 0.13, 0.14), rough=0.4)
mat_water   = mat_simple("Water", (0.30, 0.55, 0.62), rough=0.02,
                         transmission=1.0, ior=1.33)
mat_glass   = mat_simple("CurtainGlass", (0.55, 0.70, 0.80), rough=0.03,
                         transmission=0.9, ior=1.45)
mat_frame   = mat_simple("CurtainFrame", (0.07, 0.08, 0.10), rough=0.25,
                         metal=1.0)
mat_roof    = mat_simple("RoofDark", (0.10, 0.10, 0.11), rough=0.7)
mat_win     = mat_simple("ResiWindow", (0.04, 0.08, 0.13), rough=0.08,
                         metal=0.6)
mat_trunk   = mat_simple("Trunk", (0.25, 0.16, 0.09), rough=0.9)
mat_leaf    = mat_simple("Foliage", (0.05, 0.22, 0.05), rough=0.9)
mat_leaf2   = mat_simple("Foliage2", (0.08, 0.27, 0.06), rough=0.9)
mat_bush    = mat_simple("Bush", (0.06, 0.25, 0.06), rough=0.95)
mat_pole    = mat_simple("LampPole", (0.12, 0.12, 0.13), rough=0.4, metal=0.9)
mat_bulb    = mat_simple("LampBulb", (1.0, 0.85, 0.6), rough=0.4,
                         emit=(1.0, 0.85, 0.55), emit_str=6.0)

resi_walls = [
    mat_simple("WallA", (0.85, 0.78, 0.68), rough=0.8),
    mat_simple("WallB", (0.80, 0.82, 0.85), rough=0.8),
    mat_simple("WallC", (0.82, 0.70, 0.60), rough=0.8),
    mat_simple("WallD", (0.75, 0.78, 0.72), rough=0.8),
]

# ---------------------------------------------------------------- the ground
add_box("Ground", 500, 500, 0.2, (0, 0, -0.1), mat_grass)

# Plaza disc + tree-ring path (light grey stone)
add_cyl("PlazaDisc", 6.3, 0.14, (0, 0, 0.07), mat_pave, segs=64)
add_cyl("RingPath", 9.7, 0.06, (0, 0, 0.03), mat_pave, segs=64)

# ------------------------------------------------------------------- fountain
FZ = 0.14  # plaza top
add_ring("FountainBasin", 1.95, 1.62, FZ, FZ + 0.55, mat_stone, segs=48)
add_cyl("FountainBottom", 1.62, 0.04, (0, 0, FZ + 0.10), mat_stone_d, segs=48)
add_cyl("FountainWater", 1.60, 0.06, (0, 0, FZ + 0.42), mat_water, segs=48)

pillar_top = FZ + 0.45 + 1.0
add_cyl("FountainPillar", 0.22, 1.0, (0, 0, FZ + 0.45 + 0.5), mat_stone, segs=24)
add_cyl("FountainNozzle", 0.10, 0.18, (0, 0, pillar_top + 0.09), mat_frame, segs=16)

# water jets + droplets
for i in range(8):
    a = math.radians(22.5 + 45.0 * i)
    ca, sa = math.cos(a), math.sin(a)
    jet_dir = Vector((ca * 0.42, sa * 0.42, 0.90)).normalized()
    jet_len = 1.05
    jet = add_cyl("Jet%d" % i, 0.035, jet_len,
                  (ca * 0.25, sa * 0.25, pillar_top + jet_len * 0.45),
                  mat_water, segs=10)
    jet.rotation_euler = jet_dir.to_track_quat('Z', 'Y').to_euler()
    for t, dr in ((0.45, 0.055), (0.75, 0.065), (1.05, 0.05)):
        add_sphere("Drop%d_%d" % (i, t), dr,
                   (ca * (0.35 + 0.62 * t), sa * (0.35 + 0.62 * t),
                    pillar_top + 0.55 * t - 0.55 * t * t),
                   mat_water)

# ------------------------------------------------------------- office tower
OC = Vector((13.0, 5.0))
OW, OD, OH = 8.0, 6.0, 15.8
add_box("OfficePodium", OW + 0.5, OD + 0.5, 0.30,
        (OC.x, OC.y, 0.15), mat_stone)
add_box("OfficeGlass", OW, OD, OH,
        (OC.x, OC.y, 0.30 + OH / 2.0), mat_glass)
# horizontal spandrel bands (curtain-wall floors)
for k in range(12):
    z = 0.30 + 1.3 * (k + 1)
    if z < 0.30 + OH - 0.05:
        add_box("MullionH%d" % k, OW + 0.12, OD + 0.12, 0.10,
                (OC.x, OC.y, z), mat_frame)
# vertical mullions: corners
for sx in (-1, 1):
    for sy in (-1, 1):
        add_box("MullionVc%d%d" % (sx, sy), 0.12, 0.12, OH,
                (OC.x + sx * OW / 2.0, OC.y + sy * OD / 2.0,
                 0.30 + OH / 2.0), mat_frame)
# verticals on long faces
for k in (-1, 0, 1):
    for sy in (-1, 1):
        add_box("MullionVa%d%d" % (k, sy), 0.10, 0.12, OH,
                (OC.x + 2.66 * k, OC.y + sy * (OD / 2.0 + 0.03),
                 0.30 + OH / 2.0), mat_frame)
# verticals on short faces
for k in (-1, 0, 1):
    for sx in (-1, 1):
        add_box("MullionVb%d%d" % (k, sx), 0.12, 0.10, OH,
                (OC.x + sx * (OW / 2.0 + 0.03), OC.y + 1.8 * k,
                 0.30 + OH / 2.0), mat_frame)
# roof
add_box("OfficeRoof", OW + 0.3, OD + 0.3, 0.35,
        (OC.x, OC.y, 0.30 + OH + 0.175), mat_roof)
add_box("OfficeMachine", 2.6, 1.6, 0.9,
        (OC.x - 1.5, OC.y + 0.8, 0.30 + OH + 0.35 + 0.45), mat_frame)

# -------------------------------------------------------- residential blocks
def add_house(idx, cx, cy, w, d, h, wall):
    base = 0.0
    add_box("House%d" % idx, w, d, h, (cx, cy, base + h / 2.0), wall)
    add_box("HouseRoof%d" % idx, w + 0.15, d + 0.15, 0.18,
            (cx, cy, base + h + 0.09), mat_roof)
    floors = max(3, int(h / 1.4))
    for f in range(floors):
        z = 1.15 + f * (h - 1.0) / floors
        for side in range(4):
            if side < 2:      # faces along X
                depth, span = d, w
                off = w / 2.0 + 0.03
            else:            # faces along Y
                depth, span = w, d
                off = d / 2.0 + 0.03
            cols = max(2, int(span / 1.5))
            for c in range(cols):
                t = (c + 0.5) / cols
                u = -span / 2.0 + t * span
                if side == 0:
                    p = (cx + u, cy + off, z)
                elif side == 1:
                    p = (cx + u, cy - off, z)
                elif side == 2:
                    p = (cx + off, cy + u, z)
                else:
                    p = (cx - off, cy + u, z)
                if side < 2:
                    add_box("Win%d_%d_%d" % (idx, f, c), 0.85, 0.08, 0.75,
                            p, mat_win)
                else:
                    add_box("Win%d_%d_%d" % (idx, f, c), 0.08, 0.85, 0.75,
                            p, mat_win)
    # bushes around the base
    for k, (bx, by) in enumerate(((-w / 2 - 0.7, -d / 2), (w / 2 + 0.7, d / 2),
                                  (-w / 2 - 0.7, d / 2))):
        add_ico("Bush%d_%d" % (idx, k), 0.4, (cx + bx, cy + by, 0.32),
                mat_bush, scale=(1.1, 1.1, 0.8), subdiv=2)

add_house(0, -12, 7, 6.0, 5.0, 6.0, resi_walls[0])
add_house(1, -13, -5, 5.0, 5.0, 5.0, resi_walls[1])
add_house(2, 1, -13, 6.0, 4.5, 5.0, resi_walls[2])
add_house(3, 12, -9, 5.0, 5.0, 6.0, resi_walls[3])

# -------------------------------------------------------------------- trees
for i in range(12):
    a = math.radians(15.0 + 30.0 * i)
    x, y = 8.4 * math.cos(a), 8.4 * math.sin(a)
    s = 0.9 + 0.18 * ((i * 37) % 5) / 5.0
    add_cyl("TreeTrunk%d" % i, 0.12, 1.6 * s, (x, y, 0.05 + 0.8 * s),
            mat_trunk, segs=10)
    add_ico("TreeFoliage%d" % i, 0.95 * s, (x, y, 0.05 + 2.0 * s),
            mat_leaf if i % 2 == 0 else mat_leaf2,
            scale=(1.0, 1.0, 1.15), subdiv=2)

# ------------------------------------------------------------------ streetlamps
for i in range(6):
    a = math.radians(30.0 * i)
    x, y = 9.7 * math.cos(a), 9.7 * math.sin(a)
    add_cyl("LampBase%d" % i, 0.10, 0.12, (x, y, 0.06), mat_pole, segs=12)
    add_cyl("LampPole%d" % i, 0.055, 3.4, (x, y, 0.12 + 1.7), mat_pole, segs=12)
    add_cyl("LampHead%d" % i, 0.18, 0.14, (x, y, 3.58), mat_frame, segs=16)
    add_sphere("LampBulb%d" % i, 0.11, (x, y, 3.50), mat_bulb)

# ------------------------------------------------------------------ walkways
def add_walkway(cx, cy, w, d):
    dist = math.hypot(cx, cy)
    if dist < 12:
        return
    t0 = 6.3
    t1 = dist - min(w, d) / 2.0 - 0.4
    if t1 <= t0:
        return
    length = t1 - t0
    mid = (t0 + t1) / 2.0
    ang = math.atan2(cy, cx)
    add_box("Walkway", 1.5, length, 0.06,
            (mid * math.cos(ang), mid * math.sin(ang), 0.03),
            mat_pave, rot_z=ang + math.pi / 2.0)

add_walkway(OC.x, OC.y, OW, OD)
for (bx, by, bw, bd) in ((-12, 7, 6.0, 5.0), (-13, -5, 5.0, 5.0),
                         (1, -13, 6.0, 4.5), (12, -9, 5.0, 5.0)):
    add_walkway(bx, by, bw, bd)

# --------------------------------------------------------------------- lights
# sunny noon sun (soft key from the sky)
sun_d = bpy.data.lights.new("Sun", 'SUN')
sun_d.energy = 3.2
sun_d.angle = math.radians(1.5)
sun_d.color = (1.0, 0.97, 0.92)
sun = bpy.data.objects.new("Sun", sun_d)
link(sun)
sun.rotation_euler = (math.radians(33), 0, math.radians(-55))

# focused key light pressing onto the central plaza & fountain
key_d = bpy.data.lights.new("PlazaKey", 'SPOT')
key_d.energy = 6500
key_d.color = (1.0, 0.95, 0.85)
key_d.spot_size = math.radians(80)
key_d.spot_blend = 0.55
key_d.shadow_soft_size = 1.2
key = bpy.data.objects.new("PlazaKey", key_d)
key.location = (0.5, 1.5, 15.0)
link(key)
aim(key, (0, 0, 0.4))

# cool fill / rim toward camera side for a premium glass sheen
fill_d = bpy.data.lights.new("Fill", 'AREA')
fill_d.energy = 900
fill_d.size = 14
fill_d.color = (0.90, 0.95, 1.0)
fill = bpy.data.objects.new("Fill", fill_d)
fill.location = (22, -16, 10)
link(fill)
aim(fill, (0, 0, 3))

# ---------------------------------------------------------------------- sky
world = bpy.data.worlds.new("Sky")
scene.world = world
world.use_nodes = True
wn = world.node_tree
wn.nodes.clear()
sky = wn.nodes.new('ShaderNodeTexSky')
try:
    sky.sky_type = 'NISHITA'
except Exception:
    pass
sky.sun_elevation = math.radians(55)
sky.sun_rotation = math.radians(-55)
sky.sun_intensity = 0.10
bg = wn.nodes.new('ShaderNodeBackground')
bg.inputs['Strength'].default_value = 0.45
out = wn.nodes.new('ShaderNodeOutputWorld')
wn.links.new(sky.outputs['Color'], bg.inputs['Color'])
wn.links.new(bg.outputs['Background'], out.inputs['Surface'])

# -------------------------------------------------------------------- camera
cam_d = bpy.data.cameras.new("Camera")
cam_d.lens = 35
cam_d.clip_start = 0.1
cam_d.clip_end = 600
cam = bpy.data.objects.new("Camera", cam_d)
cam.location = (26, -29, 24)
link(cam)
aim(cam, (0.5, 0, 2.0))
scene.camera = cam

# ------------------------------------------------------------------ outputs
bpy.ops.wm.save_as_mainfile(filepath="final.blend")

scene.render.filepath = "render.png"
bpy.ops.render.render(write_still=True)
