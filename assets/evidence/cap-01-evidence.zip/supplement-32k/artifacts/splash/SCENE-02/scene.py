# Nordic-minimalist table lamp — main product shot
# Blender 5.1 headless script. Builds scene, saves final.blend, renders render.png (Cycles CPU, 2K, <=32 samples).
import bpy
import bmesh
import math

# ---------------------------------------------------------------- reset ----
bpy.ops.wm.read_factory_settings(use_empty=True)
scene = bpy.context.scene

# ------------------------------------------------------- render settings ---
scene.render.engine = "CYCLES"
scene.cycles.device = "CPU"
scene.cycles.samples = 32
scene.cycles.use_adaptive_sampling = True
scene.cycles.use_denoising = True
scene.cycles.denoiser = "OPENIMAGEDENOISE"
scene.cycles.max_bounces = 12
scene.cycles.diffuse_bounces = 6
scene.cycles.glossy_bounces = 8
scene.cycles.transmission_bounces = 12
scene.cycles.transparent_max_bounces = 16
scene.cycles.sample_clamp_indirect = 10.0
scene.cycles.blur_glossy = 1.0
scene.render.resolution_x = 2048          # 2K long side
scene.render.resolution_y = 1536          # 4:3, leaves clean copy space
scene.render.resolution_percentage = 100
scene.render.image_settings.file_format = "PNG"
scene.render.image_settings.color_mode = "RGBA"
scene.render.film_transparent = False
scene.view_settings.view_transform = "AgX"
scene.view_settings.look = "None"
scene.view_settings.exposure = 0.4

# ----------------------------------------------------------------- world ---
world = scene.world
if world is None:
    world = bpy.data.worlds.new("World")
    scene.world = world
world.use_nodes = True
wn = world.node_tree
bg = wn.nodes.get("Background")
if bg is None:
    bg = wn.nodes.new("ShaderNodeBackground")
    out = wn.nodes.get("World Output")
    if out is None:
        out = wn.nodes.new("ShaderNodeOutputWorld")
    wn.links.new(bg.outputs["Background"], out.inputs["Surface"])
bg.inputs["Color"].default_value = (0.5, 0.5, 0.5, 1.0)
bg.inputs["Strength"].default_value = 0.03   # keep ambient nearly black, lamps do the work

# ------------------------------------------------------------- materials ---
def new_material(name):
    m = bpy.data.materials.new(name)
    m.use_nodes = True
    nt = m.node_tree
    b = nt.nodes.get("Principled BSDF")
    if b is None:
        b = nt.nodes.new("ShaderNodeBsdfPrincipled")
        out = nt.nodes.get("Material Output")
        if out is None:
            out = nt.nodes.new("ShaderNodeOutputMaterial")
        nt.links.new(b.outputs["BSDF"], out.inputs["Surface"])
    return m, nt, b

# brushed brass (base): warm gold, anisotropic, fine noise-driven roughness
m_brushed, nt, b = new_material("Brass_Brushed")
b.inputs["Base Color"].default_value = (0.96, 0.66, 0.28, 1.0)
b.inputs["Metallic"].default_value = 1.0
b.inputs["Roughness"].default_value = 0.30
b.inputs["Anisotropic"].default_value = 0.85
noise = nt.nodes.new("ShaderNodeTexNoise")
noise.inputs["Scale"].default_value = 350.0
noise.inputs["Detail"].default_value = 2.0
mr = nt.nodes.new("ShaderNodeMapRange")
mr.inputs["To Min"].default_value = 0.24
mr.inputs["To Max"].default_value = 0.36
nt.links.new(noise.outputs["Fac"], mr.inputs["Value"])
nt.links.new(mr.outputs["Result"], b.inputs["Roughness"])

# matte brass (stem)
m_matte, nt, b = new_material("Brass_Matte")
b.inputs["Base Color"].default_value = (0.80, 0.53, 0.24, 1.0)
b.inputs["Metallic"].default_value = 1.0
b.inputs["Roughness"].default_value = 0.55

# off-white linen drum shade with slight translucency (glow-through)
m_shade, nt, b = new_material("Linen_Shade")
b.inputs["Base Color"].default_value = (0.90, 0.87, 0.80, 1.0)
b.inputs["Roughness"].default_value = 0.92
b.inputs["Sheen Weight"].default_value = 0.6
wave = nt.nodes.new("ShaderNodeTexWave")
wave.inputs["Scale"].default_value = 300.0
wave.inputs["Distortion"].default_value = 1.5
wave.inputs["Detail"].default_value = 1.0
bump = nt.nodes.new("ShaderNodeBump")
bump.inputs["Strength"].default_value = 0.04
nt.links.new(wave.outputs["Fac"], bump.inputs["Height"])
nt.links.new(bump.outputs["Normal"], b.inputs["Normal"])
trans = nt.nodes.new("ShaderNodeBsdfTranslucent")
trans.inputs["Color"].default_value = (1.0, 0.85, 0.62, 1.0)
mix = nt.nodes.new("ShaderNodeMixShader")
mix.inputs["Fac"].default_value = 0.35
out = nt.nodes.get("Material Output")
nt.links.new(b.outputs["BSDF"], mix.inputs[1])
nt.links.new(trans.outputs["BSDF"], mix.inputs[2])
nt.links.new(mix.outputs["Shader"], out.inputs["Surface"])

# E27 warm globe, 2700K blackbody emission (frosted look)
m_bulb, nt, b = new_material("Bulb_Globe")
b.inputs["Base Color"].default_value = (0.92, 0.86, 0.76, 1.0)
b.inputs["Roughness"].default_value = 0.25
bb = nt.nodes.new("ShaderNodeBlackbody")
bb.inputs[0].default_value = 2700.0
nt.links.new(bb.outputs["Color"], b.inputs["Emission Color"])
b.inputs["Emission Strength"].default_value = 7.0

# E27 screw socket metal
m_socket, nt, b = new_material("Socket_Metal")
b.inputs["Base Color"].default_value = (0.62, 0.58, 0.50, 1.0)
b.inputs["Metallic"].default_value = 1.0
b.inputs["Roughness"].default_value = 0.40

# light-gray seamless backdrop
m_back, nt, b = new_material("Backdrop_LightGray")
b.inputs["Base Color"].default_value = (0.42, 0.42, 0.44, 1.0)
b.inputs["Roughness"].default_value = 1.0
b.inputs["Specular IOR Level"].default_value = 0.2

# ---------------------------------------------------------- lamp objects ---
# all dimensions in meters (mm / 1000). Lamp origin at floor, total height ~0.500 m.
lamp_col = bpy.data.collections.new("Lamp")
scene.collection.children.link(lamp_col)

def link_lamp(o):
    for c in o.users_collection:
        c.objects.unlink(o)
    lamp_col.objects.link(o)

def add_cylinder(name, r, depth, z, verts=96, material=None):
    bpy.ops.mesh.primitive_cylinder_add(vertices=verts, radius=r, depth=depth,
                                        location=(0.0, 0.0, z))
    o = bpy.context.active_object
    o.name = name
    if material is not None:
        o.data.materials.append(material)
    link_lamp(o)
    return o

def shade_smooth(obj, angle_deg=35.0):
    bpy.context.view_layer.objects.active = obj
    for o in bpy.context.selected_objects:
        o.select_set(False)
    obj.select_set(True)
    try:
        bpy.ops.object.shade_smooth_by_angle(angle=math.radians(angle_deg))
    except Exception:
        bpy.ops.object.shade_smooth()
    for o in bpy.context.selected_objects:
        o.select_set(False)

# base: 180 mm dia, 40 mm tall, brushed brass
base = add_cylinder("Base_BrushedBrass", 0.090, 0.040, 0.020, 128, m_brushed)
bev = base.modifiers.new("Bevel", "BEVEL")
bev.width = 0.0025
bev.segments = 2
bev.limit_method = "ANGLE"
shade_smooth(base)

# stem: 16 mm dia, 350 mm tall, coaxial through base center, matte brass
stem = add_cylinder("Stem_MatteBrass", 0.008, 0.350, 0.040 + 0.175, 48, m_matte)
shade_smooth(stem)

# drum shade: 280 mm bottom rim, 180 mm top rim, 220 mm tall, ~3 mm walls, z 0.280 -> 0.500
bpy.ops.mesh.primitive_cone_add(vertices=128, radius1=0.140, radius2=0.090,
                                depth=0.220, location=(0.0, 0.0, 0.390))
shade = bpy.context.active_object
shade.name = "Shade_Linen"
shade.data.materials.append(m_shade)
sol = shade.modifiers.new("Solidify", "SOLIDIFY")
sol.thickness = 0.003
sol.offset = -1.0
sol.use_rim = True
link_lamp(shade)
shade_smooth(shade)

# E27 bulb: socket + neck + frosted globe
socket = add_cylinder("Bulb_Socket", 0.0135, 0.022, 0.390 + 0.011, 48, m_socket)
shade_smooth(socket)
neck = add_cylinder("Bulb_Neck", 0.0095, 0.008, 0.416, 32, m_socket)
shade_smooth(neck)
bpy.ops.mesh.primitive_uv_sphere_add(segments=48, ring_count=24,
                                     radius=0.032, location=(0.0, 0.0, 0.452))
globe = bpy.context.active_object
globe.name = "Bulb_Globe"
globe.data.materials.append(m_bulb)
link_lamp(globe)
shade_smooth(globe, 60.0)

# ----------------------------------------------------------------- aim -----
aim = bpy.data.objects.new("Aim_Product", None)
aim.location = (-0.05, 0.0, 0.26)   # slightly left of lamp -> copy space on the left
scene.collection.objects.link(aim)

def track_to(obj):
    c = obj.constraints.new("TRACK_TO")
    c.target = aim
    c.track_axis = "TRACK_NEGATIVE_Z"
    c.up_axis = "UP_Y"

# ------------------------------------------------------------ 3-point light
def add_area(name, loc, size, power, color, size_y=None):
    ld = bpy.data.lights.new(name, "AREA")
    ld.shape = "SQUARE"
    ld.size = size
    if size_y is not None:
        ld.shape = "RECTANGLE"
        ld.size_y = size_y
    ld.energy = power
    ld.color = color
    o = bpy.data.objects.new(name, ld)
    scene.collection.objects.link(o)
    o.location = loc
    track_to(o)
    return o

# key ~45 deg to the side, soft and high
add_area("Light_Key", (1.35, -1.35, 1.15), 1.2, 120.0, (1.0, 0.97, 0.92))
# fill: opposite side, bigger and dimmer
add_area("Light_Fill", (-1.60, -1.10, 0.75), 2.0, 35.0, (0.95, 0.97, 1.0))
# rim: back/above, picks out brass and shade edge
add_area("Light_Rim", (-0.50, 1.55, 1.50), 0.5, 50.0, (1.0, 0.95, 0.88))

# practical bulb light (soft warm point at the globe)
pl = bpy.data.lights.new("BulbLight", "POINT")
pl.energy = 15.0
pl.color = (1.0, 0.62, 0.32)
pl.shadow_soft_size = 0.02
po = bpy.data.objects.new("BulbLight", pl)
scene.collection.objects.link(po)
po.location = (0.0, 0.0, 0.452)

# ------------------------------------------------------- backdrop (cyc) ----
profile = [(-3.6, 0.0), (1.0, 0.0)]
for i in range(1, 25):
    t = (i / 24.0) * (math.pi / 2.0)
    profile.append((1.0 + math.sin(t), 1.0 - math.cos(t)))
profile.append((2.0, 3.6))

nx = 48
verts = []
for (y, z) in profile:
    for j in range(nx + 1):
        x = -3.6 + 7.2 * j / nx
        verts.append((x, y, z))
faces = []
for i in range(len(profile) - 1):
    for j in range(nx):
        a = i * (nx + 1) + j
        faces.append((a, a + 1, a + nx + 2, a + nx + 1))

mesh = bpy.data.meshes.new("Backdrop")
mesh.from_pydata(verts, [], faces)
backdrop = bpy.data.objects.new("Backdrop", mesh)
scene.collection.objects.link(backdrop)
backdrop.data.materials.append(m_back)
bm = bmesh.new()
bm.from_mesh(mesh)
bmesh.ops.recalc_face_normals(bm, faces=bm.faces, direction=(0.0, 0.0, 1.0))
bm.to_mesh(mesh)
bm.free()
shade_smooth(backdrop, 40.0)

# --------------------------------------------------------------- camera ----
cam_data = bpy.data.cameras.new("Camera_Main")
cam_data.lens = 65.0
cam_data.sensor_width = 36.0
cam_data.dof.use_dof = True
cam_data.dof.focus_object = aim
cam_data.dof.aperture_fstop = 5.6
cam = bpy.data.objects.new("Camera_Main", cam_data)
scene.collection.objects.link(cam)
cam.location = (1.32, -1.88, 0.50)   # three-quarter front, slightly above
track_to(cam)
scene.camera = cam

# --------------------------------------------------------- save & render ---
scene.render.filepath = "render.png"
bpy.ops.wm.save_as_mainfile(filepath="final.blend")
bpy.ops.render.render(write_still=True)
