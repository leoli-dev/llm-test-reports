# Nordic minimalist table lamp - clean product shot
# Builds an editable Blender scene, saves final.blend and renders render.png (Cycles CPU, 2K).

import bpy
import bmesh
import math
from mathutils import Vector

# ---------------------------------------------------------------------------
# Scene reset (factory startup)
# ---------------------------------------------------------------------------
scene = bpy.context.scene

bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete(use_global=False)
for block in (bpy.data.meshes, bpy.data.materials, bpy.data.lights,
              bpy.data.cameras):
    for item in list(block):
        if item.users == 0:
            block.remove(item)

scene.unit_settings.system = 'METRIC'
scene.unit_settings.length_unit = 'MILLIMETERS'
scene.unit_settings.scale_length = 1.0

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def new_obj(name, mesh):
    obj = bpy.data.objects.new(name, mesh)
    scene.collection.objects.link(obj)
    return obj

def smooth(obj):
    bpy.ops.object.select_all(action='DESELECT')
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj
    bpy.ops.object.shade_smooth()
    try:
        bpy.ops.object.shade_auto_smooth(angle=math.radians(35))
    except Exception:
        pass

def look_at(obj, target):
    direction = Vector(target) - obj.location
    obj.rotation_euler = direction.to_track_quat('-Z', 'Y').to_euler()

def make_principled(name, color, metallic=0.0, roughness=0.5, aniso=0.0):
    mat = bpy.data.materials.new(name)
    mat.use_nodes = True
    bsdf = mat.node_tree.nodes.get('Principled BSDF')
    bsdf.inputs['Base Color'].default_value = (*color, 1.0)
    bsdf.inputs['Metallic'].default_value = metallic
    bsdf.inputs['Roughness'].default_value = roughness
    if aniso > 0.0:
        try:
            bsdf.inputs['Anisotropic'].default_value = aniso
        except Exception:
            pass
    return mat

# ---------------------------------------------------------------------------
# Materials
# ---------------------------------------------------------------------------
brass_brushed = make_principled("BrushedBrass", (0.82, 0.58, 0.24),
                                metallic=1.0, roughness=0.28, aniso=0.7)
brass_matte = make_principled("MatteBrass", (0.72, 0.50, 0.20),
                              metallic=1.0, roughness=0.55)
backdrop_mat = make_principled("BackdropGray", (0.70, 0.71, 0.72),
                               metallic=0.0, roughness=0.9)
socket_mat = make_principled("SocketWhite", (0.88, 0.87, 0.85),
                             metallic=0.0, roughness=0.4)

# Linen shade: mostly diffuse off-white + slight translucency so the bulb
# glows softly through the walls.
linen = bpy.data.materials.new("LinenShade")
linen.use_nodes = True
nt = linen.node_tree
nt.nodes.clear()
out = nt.nodes.new('ShaderNodeOutputMaterial')
mix = nt.nodes.new('ShaderNodeMixShader')
p = nt.nodes.new('ShaderNodeBsdfPrincipled')
p.inputs['Base Color'].default_value = (0.84, 0.81, 0.75, 1.0)
p.inputs['Roughness'].default_value = 0.95
t = nt.nodes.new('ShaderNodeBsdfTranslucent')
t.inputs['Color'].default_value = (0.92, 0.87, 0.78, 1.0)
mix.inputs['Fac'].default_value = 0.35
nt.links.new(p.outputs['BSDF'], mix.inputs[1])
nt.links.new(t.outputs['BSDF'], mix.inputs[2])
nt.links.new(mix.outputs['Result'], out.inputs['Surface'])

# Warm bulb, blackbody emission ~2700 K
bulb_mat = bpy.data.materials.new("Bulb2700K")
bulb_mat.use_nodes = True
bnt = bulb_mat.node_tree
bnt.nodes.clear()
bout = bnt.nodes.new('ShaderNodeOutputMaterial')
bem = bnt.nodes.new('ShaderNodeEmission')
bem.inputs['Strength'].default_value = 22.0
bbb = bnt.nodes.new('ShaderNodeBlackbody')
bbb.inputs['Temperature'].default_value = 2700.0
bnt.links.new(bbb.outputs['Color'], bem.inputs['Color'])
bnt.links.new(bem.outputs['Emission'], bout.inputs['Surface'])

# ---------------------------------------------------------------------------
# Seamless curved backdrop (cyclorama)
# ---------------------------------------------------------------------------
profile = [(-1.8, 0.0), (0.7, 0.0)]
cx, cz, r = 0.7, 0.5, 0.5
for i in range(1, 13):
    ang = math.radians(90.0 * i / 12)
    profile.append((cx + r * math.sin(ang), cz - r * math.cos(ang)))
profile.append((1.2, 2.8))

bm = bmesh.new()
y0, y1 = -2.0, 2.0
v0 = [bm.verts.new((x, y0, z)) for x, z in profile]
v1 = [bm.verts.new((x, y1, z)) for x, z in profile]
for i in range(len(profile) - 1):
    bm.faces.new((v0[i], v0[i + 1], v1[i + 1], v1[i]))
bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
bd_mesh = bpy.data.meshes.new("backdrop")
bm.to_mesh(bd_mesh)
bm.free()
backdrop = new_obj("Backdrop", bd_mesh)
backdrop.data.materials.append(backdrop_mat)
smooth(backdrop)

# ---------------------------------------------------------------------------
# Lamp geometry (units are meters; 180 mm = 0.18 m)
#   Base  : cylinder d=180mm, h=40mm, z 0.000-0.040
#   Stem  : cylinder d=16mm, h=350mm, z 0.000-0.350 (through the base)
#   Shade : frustum d_bot=280mm, d_top=180mm, h=220mm, z 0.280-0.500
#   Total height ~500 mm
# ---------------------------------------------------------------------------
bpy.ops.mesh.primitive_cylinder_add(vertices=128, radius=0.090,
                                    depth=0.040, location=(0, 0, 0.020))
base = bpy.context.active_object
base.name = "LampBase"
base.data.materials.append(brass_brushed)
smooth(base)

bpy.ops.mesh.primitive_cylinder_add(vertices=64, radius=0.008,
                                    depth=0.350, location=(0, 0, 0.175))
stem = bpy.context.active_object
stem.name = "LampStem"
stem.data.materials.append(brass_matte)
smooth(stem)

bpy.ops.mesh.primitive_cone_add(vertices=96, radius1=0.140, radius2=0.090,
                                depth=0.220, end_fill_type='NOTHING',
                                location=(0, 0, 0.390))
shade = bpy.context.active_object
shade.name = "LampShade"
sol = shade.modifiers.new("Walls", 'SOLIDIFY')
sol.thickness = 0.003
sol.offset = 0.0
bpy.ops.object.modifier_apply(modifier="Walls")
shade.data.materials.append(linen)
smooth(shade)

bpy.ops.mesh.primitive_cylinder_add(vertices=48, radius=0.014,
                                    depth=0.016, location=(0, 0, 0.358))
socket = bpy.context.active_object
socket.name = "BulbSocket"
socket.data.materials.append(socket_mat)
smooth(socket)

bpy.ops.mesh.primitive_uv_sphere_add(segments=48, ring_count=24,
                                     radius=0.026, location=(0, 0, 0.392))
bulb = bpy.context.active_object
bulb.name = "Bulb"
bulb.scale = (1.0, 1.0, 1.06)
bulb.data.materials.append(bulb_mat)
smooth(bulb)

# ---------------------------------------------------------------------------
# Lighting: soft three-point, key ~45 deg to the side
# ---------------------------------------------------------------------------
def area_light(name, loc, target, power, size, color=(1.0, 1.0, 1.0)):
    data = bpy.data.lights.new(name, 'AREA')
    data.energy = power
    data.size = size
    data.color = color
    obj = bpy.data.objects.new(name, data)
    scene.collection.objects.link(obj)
    obj.location = loc
    look_at(obj, target)
    return obj

area_light("KeyLight", (0.75, -0.75, 0.90), (0, 0, 0.30),
           80.0, 0.50, (1.0, 0.98, 0.95))
area_light("FillLight", (-0.85, -0.55, 0.55), (0, 0, 0.28),
           25.0, 0.80, (0.98, 0.99, 1.0))
area_light("RimLight", (-0.15, 0.90, 1.05), (0, 0, 0.40),
           50.0, 0.30, (1.0, 1.0, 1.0))

# Stable warm light source inside the shade (in addition to the emissive bulb)
pl_data = bpy.data.lights.new("BulbLight", 'POINT')
pl_data.energy = 10.0
pl_data.color = (1.0, 0.62, 0.33)
pl_data.shadow_soft_size = 0.03
pl = bpy.data.objects.new("BulbLight", pl_data)
scene.collection.objects.link(pl)
pl.location = (0, 0, 0.392)

# World: quiet neutral ambient so the backdrop stays clean
world = bpy.data.worlds.new("World")
scene.world = world
world.use_nodes = True
bg = world.node_tree.nodes.get('Background')
bg.inputs['Color'].default_value = (0.45, 0.46, 0.48, 1.0)
bg.inputs['Strength'].default_value = 0.15

# ---------------------------------------------------------------------------
# Camera: three-quarter front view, slightly above the lamp
# ---------------------------------------------------------------------------
cam_data = bpy.data.cameras.new("Camera")
cam_data.lens = 50.0
cam_data.clip_start = 0.01
cam_data.clip_end = 50.0
cam = bpy.data.objects.new("Camera", cam_data)
scene.collection.objects.link(cam)
cam.location = (0.50, -0.85, 0.58)
look_at(cam, (0.0, 0.0, 0.265))
scene.camera = cam

# ---------------------------------------------------------------------------
# Render settings: Cycles CPU, 2K (2048 px long side), <= 32 samples
# ---------------------------------------------------------------------------
scene.render.engine = 'CYCLES'
scene.cycles.device = 'CPU'
scene.cycles.samples = 32
scene.cycles.use_denoising = True
try:
    scene.cycles.denoiser = 'OPENIMAGEDENOISE'
except Exception:
    pass
scene.cycles.max_bounces = 8
scene.cycles.transmission_bounces = 8

scene.render.resolution_x = 1280
scene.render.resolution_y = 2048
scene.render.resolution_percentage = 100
scene.render.image_settings.file_format = 'PNG'
scene.render.film_transparent = False

try:
    scene.view_settings.view_transform = 'AgX'
except Exception:
    pass
scene.view_settings.look = 'None'
scene.view_settings.exposure = 0.0

# ---------------------------------------------------------------------------
# Save scene and render
# ---------------------------------------------------------------------------
bpy.ops.wm.save_as_mainfile(filepath='final.blend')

scene.render.filepath = 'render.png'
bpy.ops.render.render(write_still=True)
