# Qwen3.8-27B local capability examination

Prepared 2026-10-21 before changing Pi model configuration or submitting inference. This is an 18-task, eight-domain curated examination, not an official full-benchmark leaderboard run.

## Fixed protocol

- Local M5 Max, 128 GiB. MLTF 0.1.2 packed q8c and Splash 1.4.0 MLX affine8 derive from the same target revision. No GGUF is used or downloaded.
- Pi 1.3.0, thinking medium, temperature 1, top_p .95, top_k 20, contextWindow 131072, max output 8192 per model turn. Exact actual payloads are logged without auth headers. No global Pi default switch.
- One fresh inference process and new Pi session per task and backend; serial workload. Alternate pair order: MLTF→Splash for even task indices, Splash→MLTF for odd. All 36 planned sessions remain in the denominator, including missing artifacts, errors, natural EOS, length truncation and timeout. No replacement samples or model-output repair.
- Same neutral system prompt, same question bytes and fixed workspace path. Closed tasks have no tools; file tasks have confined read/write only, up to three turns, no external evaluation feedback. Hidden answers/tests and rubrics remain outside the model's tool-accessible workspace. This measures first-attempt Pi sessions, not unrestricted coding-agent performance.
- 128K is the configured capacity. Two synthetic retrieval questions intentionally carry long inputs; exact tokenizer and API counts are reported rather than claiming every prompt fills 128K. No truncation/compaction.
- 96 GiB engine cap, INT8 KV, reasoning medium; Splash FP32 recurrent state, SSD prefix cache disabled, native default ANE. Readiness/calibration excluded from request timing; filesystem caches not purged. Test engines stop before running generated code, SVG rendering or Blender, to avoid mixing grading GPU work with inference.
- Background applications are not closed without authorization. Capture system CPU/GPU, pressure/swap and thermal observations. No format-only causal or statistical equivalence claim from this small stochastic sample.

## Questions and scores fixed before inference

`exam.json` is the question manifest; each task has a complete prompt and SHA256. Source datasets/revisions and adaptations are explicit per task. Mathematical questions are paraphrased without changing values. HumanEval uses original tests plus seeded oracle checks; the primary task score is 100 only if every check passes. This is not HumanEval+.

For exact questions the score is binary 0/100. Retrieval scores the fraction of five correct requested values; instruction following scores the fraction of its specified strict checks. SVG scores require a parseable self-contained render and use the frozen binary checklist with equal weights. Blender uses the source task's importance-weighted binary criteria, inspected against delivered render and scene metadata; no official holistic or multi-agent judging component. Visual judgments are recorded criterion by criterion with evidence and remain distinguishable from programmatic tests. Rendering/execution failures and missing required files are preserved, not repaired.

Each domain score is the arithmetic mean of its task scores. Overall score is the mean of eight domain scores, giving equal weight to each domain despite unequal task counts. Report raw task scores and delivery/performance separately. A score is a curated local result, not the named benchmarks' official score. Public benchmarks may be in training data; contamination was not measured. MMLU-Pro questions are explicitly validation examples.

## Sources

- [MATH-500](https://huggingface.co/datasets/HuggingFaceH4/MATH-500/tree/6e4ed1a2a79af7d8630a6b768ec859cb5af4d3be)
- [HumanEval](https://github.com/openai/human-eval/tree/b9453e8f1865df0a0057a1383767caa400acfbcf), MIT
- [BIG-Bench Hard](https://github.com/suzgunmirac/BIG-Bench-Hard/tree/9ee07bd481feebf959a6b59d61ea57bdcf30964d), MIT
- [MMLU-Pro](https://huggingface.co/datasets/TIGER-Lab/MMLU-Pro/tree/b189ec765aa7ed75c8acfea42df31fdae71f97be), HF dataset card declares MIT; the separate GitHub repository LICENSE is Apache-2.0
- [IFEval](https://github.com/google-research/google-research/tree/master/instruction_following_eval), Apache-2.0; exact captured commit in sources
- [SVGBench](https://github.com/johnbean393/SVGBench/tree/55c1cde8bf03b63d385c931e95bd7f728cde8fde), ideas/checklist adapted into rewritten local briefs; original unlicensed full question collection excluded from public evidence
- [BlenderWorld](https://huggingface.co/datasets/Qwen/BlenderWorld/tree/e67837a78e2d963447bc1b147db42f46bc6ef07f), MIT, bw_0115 and bw_0150; local Blender 5.1.2 instead of official 4.2.10 and CPU/max32 samples
- [RULER](https://github.com/NVIDIA/RULER), inspiration for deterministic synthetic multi-key retrieval, not the official generator or official score

The public archive excludes authentication, private Pi configs, full personal sessions and original unlicensed source datasets. Model-produced code and files are preserved unchanged, with evaluation evidence and publication transformations recorded.

Execution limits fixed before any artifact submission: Python functional grading 30 s; static SVG render 60 s; unchanged Blender script 900 s (wrapper 930 s), scene inspection 90 s. The evaluator terminates its own process group on timeout. These limits apply equally to both backends.

## Dated operator/runner correction during generation

The runner initially waited for the Pi process after it emitted `agent_settled`. During investigation of the Splash CODE-03 shutdown delay, an operator interruption raced with progression into MLTF CODE-03. MLTF had already fully written answer.py and was producing its post-write response when interrupted. The delivered file is verified byte-for-byte against its recorded write-tool payload and is functionally graded as delivered; session completion and timing are explicitly marked interrupted. Splash CODE-03 delivered no file and retains its length-limit failure. A transient recovery copy assigned to the wrong artifact folder was identified against the tool logs and corrected before any grading. The incident and artifact hash checks are retained. No primary case was resubmitted to replace a result and no replacement generation was selected.

Future Pi process cleanup uses the current child's own `agent_settled` event, with a three-second grace period. This changes housekeeping only; prompts, task/score definitions and generation settings remain unchanged. Upstream request timing, rather than an interrupted/reconstructed Pi wall time, is the primary timing evidence. The later summary text for MLTF CODE-03 is incomplete; no claim that its whole session succeeded is made.

## User-requested 32K-output visual supplement

After the primary visual tasks all hit their 8,192-token budget without delivery, the user explicitly requested a separate 32,768-token visual supplement. See supplement-32k/README.md and packet freeze 2aaf3f6, protocol 66908c6 / 3a3eb3a. This is eight additional fresh sessions on the same four questions, not replacement samples inside the primary examination. Primary scores and failures remain unchanged. Both Pi model entries are raised to 32K output only after primary inference ends; context remains 128K and the global default model is preserved. Each phase is scored separately.

The runtime collector snapshot used by both phases is included as harness/resource_collector.py. Public evidence generalizes workstation paths; those symbolic paths must be adapted for a new machine. It is a provenance/evaluation archive, not a turnkey model installer. The local original scripts and generated artifacts remain unchanged.

All primary and supplemental inference completed before evaluation. Final strict primary scores are MLTF 70.83 and Splash 66.67 (eight equally weighted domains). Separate 32K visual scores: 2D MLTF 50.00 / Splash 94.44; 3D 0 / 0. Six visual source files were delivered, three SVGs rendered successfully, and no 3D script produced a valid project/render. See supplemental dated executor diagnosis and the report for unmodified-code API failures, strict bmesh import rejection, and the Sun-rays underspecification sensitivity.
