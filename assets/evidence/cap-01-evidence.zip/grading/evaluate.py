"""Frozen deterministic graders; visual binary rubrics evaluated separately."""
from pathlib import Path
import ast,copy,json,random,re,sys
from fractions import Fraction
ROOT=Path(__file__).resolve().parents[1]
def final(s):
 m=re.findall(r'FINAL\s*:\s*(.+)',s,re.I);return m[-1].strip() if m else s.strip()
def number(s):
 s=s.replace('\\\\','\\');s=re.sub(r'\\boxed\{([^{}]+)\}',r'\1',s);s=re.sub(r'\\d?frac\{(-?\d+)\}\{(-?\d+)\}',r'\1/\2',s);return Fraction(s.strip().strip('$ .'))
def score_text(task,text):
 g=json.loads((ROOT/'grading'/(task+'.json')).read_text());k=g['kind'];details={}
 if k=='numeric':
  try:parts=[number(final(text))==number(g['answer'])]
  except Exception:parts=[False]
  details={'expected':g['answer'],'extracted':final(text)}
 elif k=='choice':
  m=re.fullmatch(r'\(?([A-J])\)?[.\s]*',final(text));a=m.group(1) if m else None;e=re.sub('[^A-Z]','',g['answer']);parts=[a==e];details={'expected':e,'extracted':a}
 elif k=='retrieval':
  try:a=json.loads(text.strip())
  except Exception:a={}
  parts=[isinstance(a,dict) and a.get(k)==v for k,v in g['answer'].items()];details={'expected':g['answer'],'actual':a,'key_passes':dict(zip(g['answer'],parts))}
 elif k=='instruction':
  if task=='FOLLOW-01':
   letters=[c for c in text if c.isalpha() and c.isascii()];paras=[p for p in re.split(r'\n\s*\n',text.strip()) if p.strip()];parts=[bool(letters) and all(c.isupper() for c in letters),len(paras)==2 and all(re.match(rf'PARAGRAPH\s+{i+1}\b',p.strip()) for i,p in enumerate(paras))];details={'paragraph_count':len(paras)}
  else:
   try:parts=[isinstance(json.loads(text.strip()),(dict,list))]
   except Exception:parts=[False]
 else:raise ValueError(k)
 return {'task':task,'score':100*sum(parts)/len(parts),'checks_passed':sum(parts),'checks_total':len(parts),'all_passed':all(parts),'details':details}
def score_python(task,path):
 g=json.loads((ROOT/'grading'/(task+'.json')).read_text());source=g['source_record'];tree=ast.parse(Path(path).read_text());forbidden={'open','exec','eval','compile','__import__','globals','locals','getattr','setattr','breakpoint','input'};allowed={'math','collections','itertools','functools','heapq','typing','re','string','random','statistics','fractions','decimal','bisect','operator','sys'}
 for n in ast.walk(tree):
  if isinstance(n,ast.Import):assert all(x.name.split('.')[0] in allowed for x in n.names),'Disallowed import'
  if isinstance(n,ast.ImportFrom):assert (n.module or '').split('.')[0] in allowed,'Disallowed import'
  if isinstance(n,ast.Call) and isinstance(n.func,ast.Name):assert n.func.id not in forbidden,'Disallowed call'
  if isinstance(n,ast.Attribute):assert not n.attr.startswith('__'),'Disallowed introspection'
 ns={};exec(compile(tree,'answer.py','exec'),ns);candidate=ns[source['entry_point']];ref={};exec(source['prompt']+source['canonical_solution'],ref);oracle=ref[source['entry_point']];base={};exec(source['test'],base);baseok=True;err=None
 try:base['check'](candidate)
 except Exception as e:baseok=False;err=repr(e)
 rng=random.Random(20261021)
 if task=='CODE-01':cases=[(n,) for n in [2,3,4,6,12,97,100,999,1009,1024,99991]]+[(rng.randint(2,100000),) for _ in range(200)]
 elif task=='CODE-02':
  cases=[]
  for _ in range(120):
   n=rng.choice([2,3,4]);a=list(range(1,n*n+1));rng.shuffle(a);cases.append(([a[i*n:(i+1)*n] for i in range(n)],rng.randint(1,12)))
 else:cases=[([],),([0,0,-1,1,10,-10,99,-99],)]+[([rng.randint(-9999,9999) for _ in range(rng.randint(0,50))],) for _ in range(200)]
 checks=[]
 for args in cases:
  try:checks.append(candidate(*copy.deepcopy(args))==oracle(*copy.deepcopy(args)))
  except Exception:checks.append(False)
 ok=baseok and all(checks);return {'task':task,'score':100 if ok else 0,'base_tests_passed':baseok,'base_error':err,'augmented_passed':sum(checks),'augmented_total':len(checks),'functional_success':ok,'partial_test_fraction':(sum(checks)+baseok)/(len(checks)+1)}
if __name__=='__main__':
 try:r=score_python(sys.argv[2],sys.argv[3]) if sys.argv[1]=='--python-child' else score_text(sys.argv[1],Path(sys.argv[2]).read_text())
 except Exception as e:r={'score':0,'error':repr(e),'functional_success':False}
 print(json.dumps(r))
