# 本机能力试卷：18题／8领域

[English](QUESTION_BOOK.md) | [简体中文](QUESTION_BOOK_CN.md)

试卷与评分于调用模型前冻结：77eea8d。以下prompt保留实际测试语言；标准答案和隐藏测试位于grading，不提供给被测模型。

## MATH-01 · Algebra / polynomial interpolation

数学 · [Source](https://huggingface.co/datasets/HuggingFaceH4/MATH-500/blob/6e4ed1a2a79af7d8630a6b768ec859cb5af4d3be/test.jsonl#test/intermediate_algebra/1197.json)

完整实际输入：[MATH-01/prompt.txt](tasks/MATH-01/prompt.txt)

```text
A degree-five polynomial p satisfies p(n)=n/(n^2-1) at every integer n from 2 through 7. Determine p(8).
Give a concise justification and end with FINAL: <exact number or fraction>.
```

适配说明：Source mathematical facts paraphrased; values and reference answers unchanged. Final-answer marker added.

## MATH-02 · Number theory / sums of proper divisors

数学 · [Source](https://huggingface.co/datasets/HuggingFaceH4/MATH-500/blob/6e4ed1a2a79af7d8630a6b768ec859cb5af4d3be/test.jsonl#test/number_theory/737.json)

完整实际输入：[MATH-02/prompt.txt](tasks/MATH-02/prompt.txt)

```text
Define s(m) as the sum of the positive divisors of m that are strictly smaller than m. Evaluate s(s(284)).
Give a concise justification and end with FINAL: <exact number or fraction>.
```

适配说明：Source mathematical facts paraphrased; values and reference answers unchanged. Final-answer marker added.

## MATH-03 · Geometry / parallelogram

数学 · [Source](https://huggingface.co/datasets/HuggingFaceH4/MATH-500/blob/6e4ed1a2a79af7d8630a6b768ec859cb5af4d3be/test.jsonl#test/geometry/627.json)

完整实际输入：[MATH-03/prompt.txt](tasks/MATH-03/prompt.txt)

```text
A parallelogram has three vertices (5,3), (6,8) and (7,4). Its fourth vertex is (x,y), with x greater than 7. Find x+y.
Give a concise justification and end with FINAL: <exact number or fraction>.
```

适配说明：Source mathematical facts paraphrased; values and reference answers unchanged. Final-answer marker added.

## CODE-01 · HumanEval/24 / largest_divisor

编程 · [Source](https://github.com/openai/human-eval/blob/b9453e8f1865df0a0057a1383767caa400acfbcf/data/HumanEval.jsonl.gz)

完整实际输入：[CODE-01/prompt.txt](tasks/CODE-01/prompt.txt)

```text
Implement the following Python function. Write a complete importable answer.py containing the function and any standard-library imports. Do not include tests or a CLI. Use the write tool; the evaluator runs your file after this session.



def largest_divisor(n: int) -> int:
    """ For a given number n, find the largest number that divides n evenly, smaller than n
    >>> largest_divisor(15)
    5
    """
```

适配说明：None; original question with a local answer-delivery wrapper.

## CODE-02 · HumanEval/129 / minPath

编程 · [Source](https://github.com/openai/human-eval/blob/b9453e8f1865df0a0057a1383767caa400acfbcf/data/HumanEval.jsonl.gz)

完整实际输入：[CODE-02/prompt.txt](tasks/CODE-02/prompt.txt)

```text
Implement the following Python function. Write a complete importable answer.py containing the function and any standard-library imports. Do not include tests or a CLI. Use the write tool; the evaluator runs your file after this session.


def minPath(grid, k):
    """
    Given a grid with N rows and N columns (N >= 2) and a positive integer k, 
    each cell of the grid contains a value. Every integer in the range [1, N * N]
    inclusive appears exactly once on the cells of the grid.

    You have to find the minimum path of length k in the grid. You can start
    from any cell, and in each step you can move to any of the neighbor cells,
    in other words, you can go to cells which share an edge with you current
    cell.
    Please note that a path of length k means visiting exactly k cells (not
    necessarily distinct).
    You CANNOT go off the grid.
    A path A (of length k) is considered less than a path B (of length k) if
    after making the ordered lists of the values on the cells that A and B go
    through (let's call them lst_A and lst_B), lst_A is lexicographically less
    than lst_B, in other words, there exist an integer index i (1 <= i <= k)
    such that lst_A[i] < lst_B[i] and for any j (1 <= j < i) we have
    lst_A[j] = lst_B[j].
    It is guaranteed that the answer is unique.
    Return an ordered list of the values on the cells that the minimum path go through.

    Examples:

        Input: grid = [ [1,2,3], [4,5,6], [7,8,9]], k = 3
        Output: [1, 2, 1]

        Input: grid = [ [5,9,3], [4,1,6], [7,8,2]], k = 1
        Output: [1]
    """
```

适配说明：None; original question with a local answer-delivery wrapper.

## CODE-03 · HumanEval/145 / order_by_points

编程 · [Source](https://github.com/openai/human-eval/blob/b9453e8f1865df0a0057a1383767caa400acfbcf/data/HumanEval.jsonl.gz)

完整实际输入：[CODE-03/prompt.txt](tasks/CODE-03/prompt.txt)

```text
Implement the following Python function. Write a complete importable answer.py containing the function and any standard-library imports. Do not include tests or a CLI. Use the write tool; the evaluator runs your file after this session.


def order_by_points(nums):
    """
    Write a function which sorts the given list of integers
    in ascending order according to the sum of their digits.
    Note: if there are several items with similar sum of their digits,
    order them based on their index in original list.

    For example:
    >>> order_by_points([1, 11, -1, -11, -12]) == [-1, -11, 1, -12, 11]
    >>> order_by_points([]) == []
    """
```

适配说明：None; original question with a local answer-delivery wrapper.

## SVG-01 · Solar-system diagram

2D SVG作图 · [Source](https://github.com/johnbean393/SVGBench/blob/55c1cde8bf03b63d385c931e95bd7f728cde8fde/questions/questions.json)

完整实际输入：[SVG-01/prompt.txt](tasks/SVG-01/prompt.txt)

```text
Create image.svg: a self-contained 1600×1000 SVG science diagram. Use a dark star field and a luminous central Sun. Depict the eight planets in distance order, each on its own elliptical orbit, with Jupiter the largest planet and the terrestrial planets noticeably smaller. Include labels and subtle leaders for the Sun and every planet. Make Earth identifiable by land, clouds and a Moon; Mars by rusty color and an icy cap; Jupiter by bands and its red storm; Saturn by rings. Shade planets consistently using sunlight from the center. Add an asteroid band between Mars and Jupiter and one comet whose tail extends away from the Sun. Keep labels legible and separate. Do not embed raster images or external resources. Write the complete SVG with the write tool.
```

适配说明：Locally rewritten brief inspired by source task and requirements; requirements made explicit, output dimensions fixed. Not an official SVGBench score. Source has no stated repository license; original full dataset is not included in public evidence.

## SVG-02 · Grandfather clock at 3:00

2D SVG作图 · [Source](https://github.com/johnbean393/SVGBench/blob/55c1cde8bf03b63d385c931e95bd7f728cde8fde/questions/questions.json)

完整实际输入：[SVG-02/prompt.txt](tasks/SVG-02/prompt.txt)

```text
Create image.svg: a self-contained 1000×1200 SVG illustration of a standing mahogany longcase clock beside a window in a room. Give its case a finial, clock hood, tall glass-fronted trunk and base, with visible timber grain. The Roman-numeral dial must read exactly 3:00: minute hand vertical toward XII, hour hand toward III. Through the glass show a brass pendulum at the right endpoint of its swing and three brass weights on chains, with the right weight raised relative to the other two. Window sunlight should produce a long floor shadow in a physically consistent direction. Use highlights and shadows to distinguish polished metal, glass and wood. No external resources or embedded bitmap. Write the complete SVG with the write tool.
```

适配说明：Locally rewritten brief inspired by source task and requirements; requirements made explicit, output dimensions fixed. Not an official SVGBench score. Source has no stated repository license; original full dataset is not included in public evidence.

## SCENE-01 · 城市广场与喷泉沙盘

3D场景 · [Source](https://huggingface.co/datasets/Qwen/BlenderWorld/tree/e67837a78e2d963447bc1b147db42f46bc6ef07f/bw_0115)

完整实际输入：[SCENE-01/prompt.txt](tasks/SCENE-01/prompt.txt)

```text
我在给一个新楼盘做展台方案，下周得拿中心广场的城市沙盘效果图去给业主过。正中间是带喷泉的圆形小广场，旁边立一栋亮闪闪的玻璃幕墙办公楼，再配三四栋矮点的住宅楼，广场四周种一圈树、点几盏路灯，其它陈设按常规城市沙盘补齐。地面铺浅灰色石板、草地弄绿点，打晴天中午的阳光，用稍微俯下来的鸟瞰角度出一张清楚的图。重点是灯光压在中间广场和喷泉上让它最抢眼，整体高级点就行，渲染图给我，工程也留着。

Local delivery contract: use the write tool to create scene.py, a complete Blender 5.1 Python script. The evaluator will execute it once, unchanged, in a fresh factory-startup headless Blender after your session. It must build an editable scene, save final.blend and render render.png in the current working directory, using relative output paths. Use only bpy, math, mathutils and Python standard-library modules; no downloaded assets, external programs or network. Use Cycles CPU and at most 32 render samples, retaining the requested camera/composition and resolution (2048-pixel long side when the brief says 2K; otherwise 1280×720). Do not run the script yourself or provide only prose. You have up to three model turns to write the script; no evaluation feedback will be provided.
```

适配说明：Original MIT task brief and weighted binary rubric; local script-delivery, Blender 5.1.2 and max32-sample CPU render replace official 4.2.10 multi-agent evaluation. No official holistic judge component; report rubric score only.

## SCENE-02 · Nordic brass table lamp

3D场景 · [Source](https://huggingface.co/datasets/Qwen/BlenderWorld/tree/e67837a78e2d963447bc1b147db42f46bc6ef07f/bw_0150)

完整实际输入：[SCENE-02/prompt.txt](tasks/SCENE-02/prompt.txt)

```text
I run a little home-goods shop and want a clean main product shot of a Nordic-minimalist table lamp for a listing — needs to look tidy, put the product front and center, and leave a bit of room for copy. Three parts: a cylindrical base, 180mm across and 40mm tall, in brushed brass; a stem 16mm in diameter and 350mm tall running straight through the center of the base, in matte brass; and a drum shade on top — 280mm bottom rim, 180mm top rim, 220mm tall, roughly 3mm walls — in off-white linen with a slight translucency so light glows through. Pop an E27 warm bulb inside, emission material around 2700K, whole lamp about 500mm tall. Set it on a light-gray seamless backdrop, soft three-point lighting with the key about 45° to the side, camera at a three-quarter front view slightly above the lamp, Cycles at 2K. Main thing: the proportions and scale need to feel believable, and the brass highlights and warm shade glow should read clearly without the background stealing focus. Keep the background and color palette keep it clean. Send me the render and keep the .blend too.

Local delivery contract: use the write tool to create scene.py, a complete Blender 5.1 Python script. The evaluator will execute it once, unchanged, in a fresh factory-startup headless Blender after your session. It must build an editable scene, save final.blend and render render.png in the current working directory, using relative output paths. Use only bpy, math, mathutils and Python standard-library modules; no downloaded assets, external programs or network. Use Cycles CPU and at most 32 render samples, retaining the requested camera/composition and resolution (2048-pixel long side when the brief says 2K; otherwise 1280×720). Do not run the script yourself or provide only prose. You have up to three model turns to write the script; no evaluation feedback will be provided.
```

适配说明：Original MIT task brief and weighted binary rubric; local script-delivery, Blender 5.1.2 and max32-sample CPU render replace official 4.2.10 multi-agent evaluation. No official holistic judge component; report rubric score only.

## LOGIC-01 · Five-object deduction

逻辑推理 · [Source](https://github.com/suzgunmirac/BIG-Bench-Hard/blob/9ee07bd481feebf959a6b59d61ea57bdcf30964d/bbh/logical_deduction_five_objects.json)

完整实际输入：[LOGIC-01/prompt.txt](tasks/LOGIC-01/prompt.txt)

```text
The following paragraphs each describe a set of five objects arranged in a fixed order. The statements are logically consistent within each paragraph. On a branch, there are five birds: a quail, an owl, a raven, a falcon, and a robin. The owl is the leftmost. The robin is to the left of the raven. The quail is the rightmost. The raven is the third from the left.
Options:
(A) The quail is the rightmost
(B) The owl is the rightmost
(C) The raven is the rightmost
(D) The falcon is the rightmost
(E) The robin is the rightmost
End with FINAL: <option letter>.
```

适配说明：None; original question with a local answer-delivery wrapper.

## LOGIC-02 · Calendar reasoning

逻辑推理 · [Source](https://github.com/suzgunmirac/BIG-Bench-Hard/blob/9ee07bd481feebf959a6b59d61ea57bdcf30964d/bbh/date_understanding.json)

完整实际输入：[LOGIC-02/prompt.txt](tasks/LOGIC-02/prompt.txt)

```text
Today is Christmas Eve of 1937. What is the date tomorrow in MM/DD/YYYY?
Options:
(A) 12/11/1937
(B) 12/25/1937
(C) 01/04/1938
(D) 12/04/1937
(E) 12/25/2006
(F) 07/25/1937
End with FINAL: <option letter>.
```

适配说明：None; original question with a local answer-delivery wrapper.

## SCIENCE-01 · physics / MMLU-Pro validation 10

科学知识 · [Source](https://huggingface.co/datasets/TIGER-Lab/MMLU-Pro/tree/b189ec765aa7ed75c8acfea42df31fdae71f97be)

完整实际输入：[SCIENCE-01/prompt.txt](tasks/SCIENCE-01/prompt.txt)

```text
Say the pupil of your eye has a diameter of 5 mm and you have a telescope with an aperture of 50 cm. How much more light can the telescope gather than your eye?
A. 1000 times more
B. 50 times more
C. 5000 times more
D. 500 times more
E. 10000 times more
F. 20000 times more
G. 2000 times more
H. 100 times more
I. 10 times more
J. N/A
End with FINAL: <option letter>.
```

适配说明：First physics item and second biology item from released validation subset; 10 options and answer retained. API snapshot SHA frozen; not full/test-split MMLU-Pro accuracy.

## SCIENCE-02 · biology / MMLU-Pro validation 21

科学知识 · [Source](https://huggingface.co/datasets/TIGER-Lab/MMLU-Pro/tree/b189ec765aa7ed75c8acfea42df31fdae71f97be)

完整实际输入：[SCIENCE-02/prompt.txt](tasks/SCIENCE-02/prompt.txt)

```text
In a given population, 1 out of every 400 people has a cancer caused by a completely recessive allele, b. Assuming the population is in Hardy-Weinberg equilibrium, which of the following is the expected proportion of individuals who carry the b allele but are not expected to develop the cancer?
A. 19/400
B. 1/400
C. 40/400
D. 38/400
E. 2/400
F. 1/200
G. 20/400
H. 50/400
I. N/A
J. N/A
End with FINAL: <option letter>.
```

适配说明：First physics item and second biology item from released validation subset; 10 options and answer retained. API snapshot SHA frozen; not full/test-split MMLU-Pro accuracy.

## FOLLOW-01 · IFEval 1021

指令遵循 · [Source](https://github.com/google-research/google-research/tree/3bbd8fbea969c2ebee2bcce61711b5cd32b5ec32/instruction_following_eval)

完整实际输入：[FOLLOW-01/prompt.txt](tasks/FOLLOW-01/prompt.txt)

```text
Write a 2 paragraph critique of the following sentence in all capital letters, no lowercase letters allowed: "If the law is bad, you should not follow it". Label each paragraph with PARAGRAPH X.
```

适配说明：Original prompt. Local deterministic strict checks for selected instructions; not official aggregate IFEval implementation.

## FOLLOW-02 · IFEval 1075

指令遵循 · [Source](https://github.com/google-research/google-research/tree/3bbd8fbea969c2ebee2bcce61711b5cd32b5ec32/instruction_following_eval)

完整实际输入：[FOLLOW-02/prompt.txt](tasks/FOLLOW-02/prompt.txt)

```text
Can you help me make an advertisement for a new product? It's a diaper that's designed to be more comfortable for babies and I want the entire output in JSON format.
```

适配说明：Original prompt. Local deterministic strict checks for selected instructions; not official aggregate IFEval implementation.

## LONG-01 · Multi-key retrieval / ~64K input

长上下文 · [Source](https://github.com/NVIDIA/RULER/tree/c3f5e3b4f87f97e048793bb510a3a6b19a46bf3a)

完整实际输入：[LONG-01/prompt.txt](tasks/LONG-01/prompt.txt)

合成日志中的五键检索；完整冻结日志见上面的输入文件。原始token数分别为65,409及119,212；actual Pi格式化计数另记。

适配说明：Original deterministic synthetic multi-key task inspired by RULER; not generated by official RULER scripts or an official RULER score. Actual formatted token counts will be audited before inference and reported; filenames indicate approximate intended size.

## LONG-02 · Multi-key retrieval / ~120K input

长上下文 · [Source](https://github.com/NVIDIA/RULER/tree/c3f5e3b4f87f97e048793bb510a3a6b19a46bf3a)

完整实际输入：[LONG-02/prompt.txt](tasks/LONG-02/prompt.txt)

合成日志中的五键检索；完整冻结日志见上面的输入文件。原始token数分别为65,409及119,212；actual Pi格式化计数另记。

适配说明：Original deterministic synthetic multi-key task inspired by RULER; not generated by official RULER scripts or an official RULER score. Actual formatted token counts will be audited before inference and reported; filenames indicate approximate intended size.
