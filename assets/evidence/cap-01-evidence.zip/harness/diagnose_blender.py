"""Retry unchanged Blender sources with transparent logging; no model repairs.

City retry corrects executor observability. Lamp attempts separately relax only
the import gate to allow Blender's native bmesh; strict lamp scores stay zero.
"""
from pathlib import Path
import hashlib,importlib.util,json,shutil,sys
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'supplement-32k'
spec=importlib.util.spec_from_file_location('executor',BASE/'harness/evaluate_artifacts.py');executor=importlib.util.module_from_spec(spec);spec.loader.exec_module(executor)
WIPE="import bpy\nfor o in list(bpy.data.objects): bpy.data.objects.remove(o, do_unlink=True)\nfor collection in (bpy.data.meshes,bpy.data.materials,bpy.data.lights,bpy.data.cameras,bpy.data.curves,bpy.data.images):\n for item in list(collection):\n  if item.users==0: collection.remove(item)\nprint('Factory startup wiped; object count:',len(bpy.data.objects))"
def save(path,value):path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
def main():
 assert (BASE/'.local/generation-complete.json').exists()
 for backend,task in [('splash','SCENE-01'),('splash','SCENE-02'),('mltf','SCENE-02')]:
  source=BASE/'artifacts'/backend/task/'scene.py';digest=hashlib.sha256(source.read_bytes()).hexdigest();case=next(p for p in (BASE/'.local/runs').iterdir() if p.name.endswith('-'+backend+'-'+task));original=BASE/'artifacts'/backend/task
  if (original/'evaluation.json').exists():shutil.copyfile(original/'evaluation.json',original/'evaluation-attempt1.json')
  shutil.copyfile(case/'score.json',case/'score-attempt1.json')
  diagnostic=task=='SCENE-02';dest=(BASE/'artifacts-diagnostics'/backend/task) if diagnostic else original;dest.mkdir(parents=True,exist_ok=True)
  work=BASE/'.local/evaluation'/(backend+'-'+task+'-direct-unchanged');work.mkdir(exist_ok=False);(work/'home').mkdir();(work/'tmp').mkdir();shutil.copyfile(source,work/'scene.py')
  env={'PATH':'/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin','HOME':str(work/'home'),'TMPDIR':str(work/'tmp'),'BLENDER_USER_RESOURCES':str(work/'home/blender'),'BLENDER_USER_CONFIG':str(work/'home/config'),'BLENDER_USER_SCRIPTS':str(work/'home/scripts'),'BLENDER_USER_EXTENSIONS':str(work/'home/extensions'),'PYTHONNOUSERSITE':'1'}
  cmd=['/usr/bin/sandbox-exec','-p',executor.profile(work),str(executor.BLENDER),'--background','--factory-startup','--python-exit-code','1','--python-expr',WIPE,'--python',str(work/'scene.py')]
  result=executor.run(cmd,work,work/'execution.log',930,env);receipt={'task':task,'backend':backend,'unchanged_source_sha256':digest,'execution':result,'diagnostic_only_bmesh_allowed':diagnostic,'executor_change':'Direct factory-startup Blender with identical empty-scene wipe, python-exit-code=1, full stdout/stderr and user paths isolated. No source change.','errors':[]}
  for name in ['final.blend','render.png']:
   if (work/name).exists():shutil.copyfile(work/name,dest/name)
  success=result['returncode']==0 and (dest/'final.blend').is_file() and (dest/'render.png').is_file()
  if success:
   r=executor.run(['/usr/bin/sandbox-exec','-p',executor.profile(work),str(executor.BLENDER),'--background','--factory-startup','--disable-autoexec','--python-exit-code','1',str(work/'final.blend'),'--python',str(BASE/'harness/scene_summary.py')],work,work/'inspection.log',90,env)
   success=r['returncode']==0 and (work/'scene-summary.json').is_file();receipt['inspection']=r
   if success:shutil.copyfile(work/'scene-summary.json',dest/'scene-summary.json')
  if success:
   receipt['pending_visual_rubric']=True
   if not diagnostic:(case/'score.json').unlink()
  else:
   tail='\n'.join((work/'execution.log').read_text().splitlines()[-16:]);receipt['errors'].append(tail)
   if not diagnostic:save(case/'score.json',{'task':task,'score':0,'artifact_gate_failed':True,'error':'Unchanged Blender source failed in transparent executor','execution_log_tail':tail})
  assert hashlib.sha256(source.read_bytes()).hexdigest()==digest
  save(dest/'evaluation.json',receipt);print(json.dumps({'task':task,'backend':backend,'diagnostic_only':diagnostic,'rendered':success,'execution':result,'error_tail':receipt['errors']},ensure_ascii=False),flush=True)
if __name__=='__main__':main()
