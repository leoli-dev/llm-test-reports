"""Start the authorized visual supplement only after primary inference stops."""
from pathlib import Path
import json,os,shutil,socket,subprocess,time
ROOT=Path(__file__).resolve().parents[1];SUP=ROOT/'supplement-32k';PRIVATE=SUP/'.local'
def main():
 while not (ROOT/'.local/generation-complete.json').is_file():time.sleep(5)
 for port in [8083,8084,8096]:
  with socket.socket() as sock:
   sock.settimeout(.5);assert sock.connect_ex(('127.0.0.1',port))!=0,'Refusing to replace a service on '+str(port)
 models=Path('$HOME/.pi/agent/models.json');settings=Path('$HOME/.pi/agent/settings.json');before=settings.read_bytes();backup=PRIVATE/'config-backups';backup.mkdir(mode=0o700);shutil.copyfile(models,backup/'models-before-32k.json');(backup/'models-before-32k.json').chmod(0o600)
 data=json.loads(models.read_text());changes=[]
 for provider,ident in [('mltf','local/Qwen3.8-27B-MLTF-q8c'),('splash','mlx-community/Qwen3.8-27B-8bit')]:
  model=next(x for x in data['providers'][provider]['models'] if x['id']==ident);assert model['contextWindow']==131072;changes.append({'provider':provider,'id':ident,'previous_maxTokens':model['maxTokens'],'maxTokens':32768,'contextWindow':131072});model['maxTokens']=32768
 temp=models.with_suffix('.json.cap-01.tmp');temp.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n');temp.chmod(models.stat().st_mode&0o777);temp.replace(models);assert settings.read_bytes()==before
 (SUP/'harness/pi-configuration-change.json').write_text(json.dumps({'primary_phase_already_complete':True,'changes':changes,'global_settings_bytes_unchanged':True,'auth_values_not_published':True},indent=2)+'\n')
 subprocess.run(['node',str(SUP/'harness/verify_pi.mjs')],check=True,cwd=SUP)
 result=subprocess.run(['pi','--list-models'],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,check=True);lines=result.stdout.splitlines();(SUP/'harness/pi-model-list.txt').write_text('\n'.join(x for i,x in enumerate(lines) if i==0 or x.startswith('mltf ') or x.startswith('splash '))+'\n')
 print('Primary stopped; both Pi entries now 128K context / 32K output. Starting 8 supplemental sessions.',flush=True)
 with (PRIVATE/'runner.log').open('w') as output:
  result=subprocess.run(['$LOCAL_LLMS_ROOT/splash/source/.venv/bin/python',str(SUP/'harness/run_exam.py')],cwd=SUP,stdout=output,stderr=subprocess.STDOUT)
 return result.returncode
if __name__=='__main__':raise SystemExit(main())
