"""Read submitted .blend without changing authored scene or render settings."""
import bpy,json,math
from mathutils import Vector
from pathlib import Path
scene=bpy.context.scene;objects=[];depsgraph=bpy.context.evaluated_depsgraph_get()
for o in scene.objects:
 row={'name':o.name,'type':o.type,'location':list(o.location),'dimensions':list(o.dimensions),'rotation_euler':list(o.rotation_euler),'materials':[m.name if m else None for m in getattr(o.data,'materials',[])]}
 row['matrix_world']=[list(r) for r in o.matrix_world]
 if o.type=='MESH':
  evaluated=o.evaluated_get(depsgraph)
  modifiers=[]
  for mod in o.modifiers:
   values={'name':mod.name,'type':mod.type,'show_render':mod.show_render}
   for key in ['thickness','offset','width','segments','levels','render_levels','solidify_mode']:
    if hasattr(mod,key):values[key]=getattr(mod,key)
   modifiers.append(values)
  row.update(vertices=len(o.data.vertices),polygons=len(o.data.polygons),world_bounds=[list(o.matrix_world@Vector(c)) for c in o.bound_box],evaluated_dimensions=list(evaluated.dimensions),evaluated_world_bounds=[list(evaluated.matrix_world@Vector(c)) for c in evaluated.bound_box],modifiers=modifiers)
 if o.type=='LIGHT':row['light']={'type':o.data.type,'energy':o.data.energy,'color':list(o.data.color),'size':getattr(o.data,'size',None)}
 objects.append(row)
materials=[]
for m in bpy.data.materials:
 nodes=[]
 if m.node_tree:
  for n in m.node_tree.nodes:
   vals={}
   for socket in n.inputs:
    if not socket.is_linked and hasattr(socket,'default_value'):
     v=socket.default_value
     try:v=list(v)
     except TypeError:pass
     if isinstance(v,(int,float,str,list,bool)):vals[socket.name]=v
   record={'type':n.type,'name':n.name,'unlinked_inputs':vals}
   for key in ['operation','blend_type','distribution','data_type']:
    if hasattr(n,key):record[key]=getattr(n,key)
   if hasattr(n,'color_ramp'):record['color_ramp']=[{'position':e.position,'color':list(e.color)} for e in n.color_ramp.elements]
   nodes.append(record)
 links=[{'from_node':l.from_node.name,'from_socket':l.from_socket.name,'to_node':l.to_node.name,'to_socket':l.to_socket.name} for l in m.node_tree.links] if m.node_tree else []
 materials.append({'name':m.name,'diffuse_color':list(m.diffuse_color),'nodes':nodes,'links':links})
data={'blender_version':bpy.app.version_string,'scene':{'render_engine':scene.render.engine,'resolution':[scene.render.resolution_x,scene.render.resolution_y,scene.render.resolution_percentage],'cycles_samples':scene.cycles.samples,'cycles_device':scene.cycles.device,'camera':scene.camera.name if scene.camera else None,'unit_system':scene.unit_settings.system,'scale_length':scene.unit_settings.scale_length},'objects':objects,'materials':materials}
Path('scene-summary.json').write_text(json.dumps(data,indent=2)+'\n')
