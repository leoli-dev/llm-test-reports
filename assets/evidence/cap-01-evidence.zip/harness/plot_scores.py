from pathlib import Path
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
ROOT=Path(__file__).resolve().parents[1];S=json.loads((ROOT/'.local/summary.json').read_text());assert all(S['groups'][b]['overall'] is not None for b in ['mltf','splash']);OUT=ROOT/'figures';OUT.mkdir(exist_ok=True)
domains=['mathematics','programming','2d_svg','3d_scene','logical_reasoning','scientific_knowledge','instruction_following','long_context'];names=['Mathematics (3)','Programming (3)','2D SVG (2)','3D scene (2)','Logic (2)','Science (2)','Instructions (2)','Long context (2)'];colors=['#a95f3d','#346d92']
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False})
fig,ax=plt.subplots(figsize=(12,5.2));x=np.arange(8)
for i,b in enumerate(['mltf','splash']):
 vals=[S['groups'][b]['domains'][d]['mean'] for d in domains];bars=ax.bar(x+(i-.5)*.36,vals,.36,label=b.upper() if b=='mltf' else 'Splash',color=colors[i]);ax.bar_label(bars,labels=[f'{v:.1f}' for v in vals],padding=3,fontsize=9)
ax.set_xticks(x,names,rotation=20,ha='right');ax.set_ylim(0,115);ax.set_ylabel('Score (0–100)');fig.legend(frameon=False,loc='upper center',bbox_to_anchor=(.5,.91),ncol=2);ax.grid(axis='y',alpha=.2);ax.set_axisbelow(True);fig.suptitle('Pi / Qwen3.8-27B 8-bit: 8K-output primary capability examination',fontsize=15,weight='bold');fig.text(.08,.015,'18 tasks, one session each; budget-limited missing artifacts score 0. One MLTF post-write session was externally interrupted; see report.',fontsize=8);fig.tight_layout(rect=[0,.07,1,.94]);fig.savefig(OUT/'cap-01-domains.png',dpi=160);plt.close(fig)
tasks=json.loads((ROOT/'exam.json').read_text())['tasks'];matrix=[[next(r['scoring']['score'] for r in S['records'] if r['backend']==b and r['task']==t['id']) for t in tasks] for b in ['mltf','splash']]
fig,ax=plt.subplots(figsize=(15,3.5));im=ax.imshow(matrix,cmap='YlGnBu',vmin=0,vmax=100,aspect='auto')
for i in range(2):
 for j in range(18):ax.text(j,i,f'{matrix[i][j]:.0f}',ha='center',va='center',color='white' if matrix[i][j]>=70 else '#182333',fontsize=9)
ax.set_yticks([0,1],['MLTF','Splash']);ax.set_xticks(range(18),[t['id'] for t in tasks],rotation=45,ha='right');ax.set_title('Per-task scores; failures retained, no replacement generation',pad=12);fig.colorbar(im,ax=ax,label='Score');fig.tight_layout();fig.savefig(OUT/'cap-01-tasks.png',dpi=160);plt.close(fig)
