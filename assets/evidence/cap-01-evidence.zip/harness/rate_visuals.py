"""Validate and calculate explicit visual-rubric ratings, never generate ratings."""
from pathlib import Path
import hashlib,json,random
ROOT=Path(__file__).resolve().parents[1]
def prepare():
 tasks=[t for t in json.loads((ROOT/'exam.json').read_text())['tasks'] if t['domain'] in ['2d_svg','3d_scene']];items=[(b,t) for t in tasks for b in ['mltf','splash']];random.Random(20261021).shuffle(items);mapping=[]
 for i,(backend,t) in enumerate(items):
  gold=json.loads((ROOT/'grading'/(t['id']+'.json')).read_text());criteria=gold['criteria'];mapping.append({'blind_label':f'V{i+1:02d}','backend':backend,'task':t['id'],'criteria':[{k:c.get(k) for k in ['id','criterion','weight','importance_weight','pass_condition','fail_condition','evidence_type'] if k in c} for c in criteria]})
 (ROOT/'.local/visual-mapping.json').write_text(json.dumps(mapping,ensure_ascii=False,indent=2)+'\n');return mapping

def apply():
 translations=json.loads((ROOT/'harness/visual-criterion-translations.json').read_text());ratings=json.loads((ROOT/'.local/visual-ratings.json').read_text());mapping=json.loads((ROOT/'.local/visual-mapping.json').read_text())
 for item in mapping:
  backend,task=item['backend'],item['task'];case=next(p for p in (ROOT/'.local/runs').iterdir() if p.name.endswith('-'+backend+'-'+task));evaluation=ROOT/'artifacts'/backend/task/'evaluation.json'
  if (case/'score.json').exists() and json.loads((case/'score.json').read_text()).get('artifact_gate_failed'):continue
  review=ratings[item['blind_label']];given={c['id']:c for c in review['criteria']};assert set(given)=={c['id'] for c in item['criteria']}
  total=got=0;rows=[]
  for c in item['criteria']:
   r=given[c['id']];assert type(r['passed']) is bool and len(r['evidence'])>=12
   weight=c.get('importance_weight',c.get('weight',1));total+=weight;got+=weight*r['passed'];rows.append({**c,**r,'criterion_cn':translations[task][c['id']],'applied_weight':weight})
  score={'task':task,'score':100*got/total,'judge':'Codex supervising assistant, criterion-level visual/scene inspection; not independent or an official benchmark judge','presentation':'Anonymized V-labels; supervisor can access mapping, so not fully blind','blind_label':item['blind_label'],'passed_weight':got,'total_weight':total,'criteria':rows,'notes':review.get('notes',''),'notes_cn':review.get('notes_cn','')};(case/'score.json').write_text(json.dumps(score,ensure_ascii=False,indent=2)+'\n')
if __name__=='__main__':
 import sys
 print(json.dumps(prepare(),ensure_ascii=False) if sys.argv[1]=='prepare' else apply())
