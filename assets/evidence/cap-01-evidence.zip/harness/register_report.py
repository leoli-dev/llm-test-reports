"""Register the finished report pair through the archive's supported registrar."""
from pathlib import Path
import json,subprocess
ROOT=Path(__file__).resolve().parents[1];ARCHIVE=Path('$CODE_ROOT/llm-test-reports')
def main():
 primary=json.loads((ROOT/'.local/summary.json').read_text());supplement=json.loads((ROOT/'supplement-32k/.local/summary.json').read_text())
 assert primary['recorded_sessions']==36 and supplement['recorded_sessions']==8
 score=lambda b:primary['groups'][b]['overall']
 assert all(score(b) is not None for b in ['mltf','splash'])
 visual=lambda b,d:supplement['groups'][b]['domains'][d]['mean']
 assert all(visual(b,d) is not None for b in ['mltf','splash'] for d in ['2d_svg','3d_scene'])
 options={
 'id':'CAP-01','title':'Pi capability exam: Qwen3.8-27B 8-bit on MLTF / Splash',
 'title-cn':'Pi能力考试：Qwen3.8-27B 8bit 在MLTF / Splash上的表现',
 'date':'2026-10-21','model':'Qwen3.8-27B 8-bit (MLTF q8c / MLX affine8)',
 'engine':'MLTF,Splash','scope':'local','category':'Local engine performance and quality','category-cn':'本机引擎性能与质量',
 'file':'reports/originals/2026-10-21-pi-qwen38-27b-mltf-splash-capabilities.md',
 'hardware':'MacBook Pro / Apple M5 Max / 18 CPU / 40 GPU / 128 GiB',
 'test-os':'macOS 27.0.1 (26A434), arm64; captured at test time',
 'test-os-cn':'macOS 27.0.1 (26A434)，arm64；实验时采集',
 'summary':f'Frozen 18-question, eight-domain primary examination through actual Pi CLI, same 128K context/medium/sampling and 8K per-turn output: MLTF {score("mltf"):.2f}, Splash {score("splash"):.2f}. Separate 32K-output visual supplement: 2D {visual("mltf","2d_svg"):.2f} / {visual("splash","2d_svg"):.2f}, 3D {visual("mltf","3d_scene"):.2f} / {visual("splash","3d_scene"):.2f} (MLTF / Splash). All 44 sessions retained; functional tests, renders, criterion judgments and evidence included. Curated local adaptation, not official full-benchmark scores.',
 'summary-cn':f'冻结18题、8领域，经实际Pi CLI主测，同128K上下文/medium/采样及每轮8K输出：MLTF {score("mltf"):.2f}、Splash {score("splash"):.2f}。另列32K输出视觉补充：2D {visual("mltf","2d_svg"):.2f} / {visual("splash","2d_svg"):.2f}、3D {visual("mltf","3d_scene"):.2f} / {visual("splash","3d_scene"):.2f}（MLTF / Splash）。保留全部44会话，包含功能测试、渲染、逐项判分与证据；是本地选题适配，不是官方完整benchmark分数。',
 'caveat':'One MLTF post-write session was externally interrupted; its verified delivered file is graded, with incomplete timing disclosed. One stochastic session per engine/task/budget; visual judgments are by the supervising assistant. Pi injects different workspace metadata across budget phases; only within-phase pairs have matching initial input. Missing/truncated artifacts remain in the denominator.',
 'caveat-cn':'一次MLTF会话在写文件后被外部误中断，已核对的交付文件照常评分，计时不完整单列。每引擎/题目/预算仅一次随机会话，视觉由监督助手判分。Pi在不同预算阶段注入不同工作目录元数据，仅同阶段两端首输入一致；缺失/截断产物均保留在分母。'}
 args=['node','scripts/add-report.mjs']
 for key,value in options.items():args.extend(['--'+key,value])
 subprocess.run(args,cwd=ARCHIVE,check=True)
if __name__=='__main__':main()
