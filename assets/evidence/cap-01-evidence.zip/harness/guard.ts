import fs from 'node:fs';
import path from 'node:path';
export default function(pi:any){
 const root=fs.realpathSync(process.env.EXAM_WORK!),logfile=process.env.EXAM_EVENTS!,max=Number(process.env.EXAM_MAX_TURNS||1);
 const log=(o:any)=>fs.appendFileSync(logfile,JSON.stringify({unix_seconds:Date.now()/1000,...o})+'\n');
 pi.on('session_start',(_:any,c:any)=>log({type:'session_start',model:{provider:c.model?.provider,id:c.model?.id,contextWindow:c.model?.contextWindow,maxTokens:c.model?.maxTokens,samplingParams:c.model?.samplingParams},thinkingLevel:c.thinkingLevel,tools:pi.getActiveTools()}));
 pi.on('turn_start',(e:any,c:any)=>{log({type:'turn_start',turnIndex:e.turnIndex});if(e.turnIndex>=max){log({type:'turn_limit',max});c.abort();}});
 pi.on('before_provider_request',(e:any)=>{const p=e.payload||{};log({type:'payload',model:p.model,temperature:p.temperature,top_p:p.top_p,top_k:p.top_k,reasoning_effort:p.reasoning_effort,max_tokens:p.max_tokens,tools:(p.tools||[]).map((x:any)=>x.function?.name||x.name)});});
 pi.on('tool_call',(e:any)=>{
  const input=e.input||{};let ok=['read','write'].includes(e.toolName)&&typeof input.path==='string';
  if(ok){const resolved=path.resolve(root,input.path);let ancestor=resolved;while(!fs.existsSync(ancestor)&&path.dirname(ancestor)!==ancestor)ancestor=path.dirname(ancestor);const real=fs.realpathSync(ancestor);ok=(resolved===root||resolved.startsWith(root+path.sep))&&(real===root||real.startsWith(root+path.sep));}
  if(e.toolName==='write'&&Buffer.byteLength(input.content||'')>2*1024*1024)ok=false;
  log({type:'tool_call',name:e.toolName,input,allowed:ok});if(!ok)return {block:true,reason:'Exam file tools are confined to the current workspace.'};
 });
 pi.on('tool_result',(e:any)=>log({type:'tool_result',name:e.toolName,isError:e.isError,content:e.content}));
 pi.on('message_end',(e:any)=>{if(e.message?.role==='assistant')log({type:'assistant_end',stopReason:e.message.stopReason,usage:e.message.usage,errorMessage:e.message.errorMessage});});
}
