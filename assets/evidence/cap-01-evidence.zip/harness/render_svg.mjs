import {chromium} from '$CODE_ROOT/llm-test-2026-10-20-game-tank-battle/game/node_modules/playwright/index.mjs';
import fs from 'node:fs/promises';
const [source,target]=process.argv.slice(2),svg=await fs.readFile(source,'utf8');
const browser=await chromium.launch({headless:true,executablePath:'/Applications/Chromium.app/Contents/MacOS/Chromium'});
try{const ctx=await browser.newContext({javaScriptEnabled:false,viewport:{width:1800,height:1400},deviceScaleFactor:1});await ctx.route('**/*',r=>r.abort());const page=await ctx.newPage();await page.setContent('<html><body style="margin:0">'+svg+'</body></html>');const box=await page.locator('svg').boundingBox();if(!box||box.width<1||box.height<1||box.width>4096||box.height>4096)throw new Error('Invalid canvas');await page.locator('svg').screenshot({path:target,animations:'disabled'});console.log(JSON.stringify({browser:'Chromium',javascript:false,network:false,box}));}finally{await browser.close();}
