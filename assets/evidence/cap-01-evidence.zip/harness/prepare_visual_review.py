"""Make byte-identical V-labeled review copies after execution, without repairs."""
from pathlib import Path
import hashlib,json,shutil
ROOT=Path(__file__).resolve().parents[1]
def main():
 for base in [ROOT,ROOT/'supplement-32k']:
  assert (base/'.local/generation-complete.json').exists()
  review=base/'.local/visual-review';review.mkdir(exist_ok=False);mapping=json.loads((base/'.local/visual-mapping.json').read_text());tasks={t['id']:t for t in json.loads((base/'exam.json').read_text())['tasks']};manifest=[]
  for item in mapping:
   label,task,backend=item['blind_label'],item['task'],item['backend'];case=next(p for p in (base/'.local/runs').iterdir() if p.name.endswith('-'+backend+'-'+task));score=case/'score.json';failed=score.exists() and json.loads(score.read_text()).get('artifact_gate_failed',False)
   if failed:manifest.append({'label':label,'task':task,'skip':'Delivery/execution gate failed; no subjective rating'});continue
   output=review/label;output.mkdir();origin=base/'artifacts'/backend/task
   for name in ['render.png',tasks[task]['artifact'],'scene-summary.json']:
    source=origin/name
    if source.exists():
     target=output/name;shutil.copyfile(source,target);assert target.read_bytes()==source.read_bytes()
   assert (output/'render.png').exists()
   (output/'criteria.json').write_text(json.dumps({k:item[k] for k in ['blind_label','task','criteria']},ensure_ascii=False,indent=2)+'\n');manifest.append({'label':label,'task':task,'render_sha256':hashlib.sha256((output/'render.png').read_bytes()).hexdigest(),'files':[p.name for p in output.iterdir()]})
  (review/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n');print(base.name,json.dumps(manifest,ensure_ascii=False))
if __name__=='__main__':main()
