"""Curated publication export; never export private Pi configs or model caches."""
from pathlib import Path
import hashlib,json,zipfile,subprocess,re
ROOT=Path(__file__).resolve().parents[1];TARGET=Path('$CODE_ROOT/llm-test-reports/assets/evidence/cap-01-evidence.zip')
def sha(b):return hashlib.sha256(b).hexdigest()
def main():
 assert (ROOT/'.local/execution-audit.json').exists()
 assert (ROOT/'supplement-32k/.local/execution-audit.json').exists()
 paths=[ROOT/p for p in ['exam.json','README.md','QUESTION_BOOK.md','QUESTION_BOOK_CN.md']]
 for d in ['tasks','grading','harness','figures']:
  paths.extend(p for p in (ROOT/d).rglob('*') if p.is_file() and '__pycache__' not in p.parts)
 # Selected source pins/licenses only; no unlicensed original SVG/MATH collection.
 paths.extend(p for p in (ROOT/'sources').iterdir() if p.is_file() and (p.name.endswith('-commit.json') or p.name.endswith('-license.txt') or p.name in ['source-manifest.json','math500-hf.json','mmlu-hf.json','blenderworld-github.json']))
 for p in (ROOT/'artifacts').rglob('*'):
  if p.is_file() and p.name!='.DS_Store':paths.append(p)
 for case in (ROOT/'.local/runs').iterdir():
  paths.extend(p for p in case.iterdir() if p.is_file() and p.suffix in ['.json','.jsonl','.txt','.log'])
 for p in (ROOT/'.local/evaluation').rglob('*'):
  if p.is_file() and (p.name.endswith('.log') or p.name=='scene-summary.json'):paths.append(p)
 for name in ['summary.json','execution-audit.json','frozen-packet-audit.json','hardware.json','run-plan.json','runner.log','generation-complete.json','visual-mapping.json','visual-ratings.json','incidents/controller-intervention.json']:
  p=ROOT/'.local'/name
  if p.is_file() and p.name!='.DS_Store':paths.append(p)
 supplement=ROOT/'supplement-32k'
 for d in ['tasks','grading','harness','artifacts','artifacts-diagnostics']:
  paths.extend(p for p in (supplement/d).rglob('*') if p.is_file() and '__pycache__' not in p.parts)
 paths.extend([supplement/'README.md',supplement/'exam.json'])
 for case in (supplement/'.local/runs').iterdir():
  paths.extend(p for p in case.iterdir() if p.is_file() and p.suffix in ['.json','.jsonl','.txt','.log'])
 for p in (supplement/'.local/evaluation').rglob('*'):
  if p.is_file() and (p.name.endswith('.log') or p.name=='scene-summary.json'):paths.append(p)
 for name in ['summary.json','execution-audit.json','hardware.json','run-plan.json','runner.log','generation-complete.json','visual-mapping.json','visual-ratings.json']:
  p=supplement/'.local'/name
  if p.is_file() and p.name!='.DS_Store':paths.append(p)
 substitutions=[(str(ROOT),'$BENCHMARK_ROOT'),('$LOCAL_LLMS_ROOT','$LOCAL_LLMS_ROOT'),('$CODE_ROOT','$CODE_ROOT'),('$HOME','$HOME')]
 config=json.loads(Path('$HOME/.pi/agent/models.json').read_text());secrets=[str(p['apiKey']).encode() for p in config['providers'].values() if isinstance(p.get('apiKey'),str) and len(p['apiKey'])>7]
 manifest=[];TARGET.parent.mkdir(exist_ok=True)
 with zipfile.ZipFile(TARGET,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for p in sorted(set(paths)):
   original=p.read_bytes();rel=str(p.relative_to(ROOT)).replace('.local/','evidence/',1);published=original;transformation='none'
   if p.suffix=='.blend':
    manifest.append({'path':rel,'original_bytes':len(original),'original_sha256':sha(original),'published':False,'reason':'Local binary project retained; may embed workstation paths. Unchanged scene.py, render and scene inspection are published.'});continue
   try:
    value=original.decode('utf8');changes=[]
    if p.name=='hardware.json':
     redacted=re.sub(r'id=\d+', 'id=REDACTED', value)
     if redacted!=value:changes.append('battery identifier redacted')
     value=redacted
    for before,after in substitutions:
     if before in value:
      value=value.replace(before,after)
      if 'private workstation paths generalized' not in changes:changes.append('private workstation paths generalized')
    published=value.encode();transformation='; '.join(changes) or 'none'
   except UnicodeDecodeError:pass
   assert b'$HOME' not in published,rel
   for key in secrets:assert key not in published,'Credential detected in '+rel
   z.writestr(rel,published);manifest.append({'path':rel,'original_bytes':len(original),'original_sha256':sha(original),'published':True,'published_bytes':len(published),'published_sha256':sha(published),'transformation':transformation})
  z.writestr('PUBLICATION.json',json.dumps({'description':'Curated task-scoped benchmark evidence, not personal Pi sessions. Raw local sources remain unchanged. Paths may be generalized in any textual evidence, including generated code; original and public hashes are both listed. Binary Blender projects are excluded if present; this run produced no valid .blend deliverable. Credentials, private configs, weights, caches and unlicensed full source collections excluded.','freeze_commit':'77eea8d','supplement_packet_commit':'2aaf3f6','local_source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'files':manifest},indent=2)+'\n')
 print(json.dumps({'files':len(manifest),'zip_bytes':TARGET.stat().st_size,'sha256':sha(TARGET.read_bytes())}))
if __name__=='__main__':main()
