import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import {ModelRuntime} from '$HOME/.local/lib/node_modules/@earendil-works/pi-coding-agent/dist/core/model-runtime.js';
process.env.PI_OFFLINE='1';globalThis.fetch=async()=>{throw new Error('Unexpected network')};
const runtime=await ModelRuntime.create({modelsPath:'$HOME/.pi/agent/models.json',refreshOnCreate:false,allowModelNetwork:false});assert.equal(runtime.getError(),undefined);
const checks=[];
for(const [provider,id] of [['mltf','local/Qwen3.8-27B-MLTF-q8c'],['splash','mlx-community/Qwen3.8-27B-8bit']]){
 const m=runtime.getModel(provider,id);assert(m);assert.equal(m.contextWindow,131072);assert.equal(m.maxTokens,8192);let body;
 const fetch=async(input,init)=>{body=JSON.parse(String(init.body));const chunks=[{id:'offline',object:'chat.completion.chunk',created:0,model:id,choices:[{index:0,delta:{role:'assistant',content:'OK'},finish_reason:null}]},{id:'offline',object:'chat.completion.chunk',created:0,model:id,choices:[{index:0,delta:{},finish_reason:'stop'}],usage:{prompt_tokens:1,completion_tokens:1,total_tokens:2}}];return new Response(chunks.map(x=>'data: '+JSON.stringify(x)+'\n\n').join('')+'data: [DONE]\n\n',{headers:{'content-type':'text/event-stream'}})};
 const r=await runtime.completeSimple(m,{messages:[{role:'user',content:'Serializer preflight only.',timestamp:0}]},{reasoning:'medium',maxTokens:8192,maxRetries:0,fetch});assert.equal(r.stopReason,'stop',r.errorMessage);
 assert.equal(body.temperature,1);assert.equal(body.top_p,.95);assert.equal(body.top_k,20);assert.equal(body.reasoning_effort,'medium');assert.equal(body.max_tokens,8192);
 checks.push({provider,id,contextWindow:m.contextWindow,maxTokens:m.maxTokens,temperature:body.temperature,top_p:body.top_p,top_k:body.top_k,reasoning_effort:body.reasoning_effort});
}
await fs.writeFile(new URL('pi-serializer-check.json',import.meta.url),JSON.stringify({passed:true,networkInferenceRequests:0,checks},null,2)+'\n');console.log(JSON.stringify({passed:true,checks}));
