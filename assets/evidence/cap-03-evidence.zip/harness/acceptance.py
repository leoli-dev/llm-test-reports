"""Independent black-box API acceptance. Does not modify candidate source."""
import concurrent.futures as futures
import copy,datetime,json,os,pathlib,socket,subprocess,sys,tempfile,threading,time,urllib.request,urllib.error,signal
ROOT=pathlib.Path(__file__).resolve().parents[1]
def require(condition,why='assertion failed'):
 if not condition:raise AssertionError(why)
class App:
 def __init__(self,candidate,folder):
  self.candidate=pathlib.Path(candidate);self.folder=pathlib.Path(folder);self.folder.mkdir(parents=True,exist_ok=True);self.db=self.folder/'workshop.sqlite';self.p=None
  with socket.socket() as sock:sock.bind(('127.0.0.1',0));self.port=sock.getsockname()[1]
  self.base=f'http://127.0.0.1:{self.port}'
 def start(self):
  self.log=(self.folder/'server.log').open('ab');self.p=subprocess.Popen([sys.executable,'app.py','--host','127.0.0.1','--port',str(self.port),'--db',str(self.db)],cwd=self.candidate,stdout=self.log,stderr=subprocess.STDOUT,start_new_session=True)
  for _ in range(100):
   if self.p.poll() is not None:raise RuntimeError('Candidate server exited: '+str(self.p.returncode))
   try:self.req('GET','/api/health',expect=200);return
   except Exception:time.sleep(.1)
  raise RuntimeError('Server not ready within10s')
 def stop(self):
  if self.p and self.p.poll() is None:
   os.killpg(self.p.pid,signal.SIGTERM)
   try:self.p.wait(timeout=3)
   except subprocess.TimeoutExpired:os.killpg(self.p.pid,signal.SIGKILL);self.p.wait()
  if hasattr(self,'log'):self.log.close()
 def req(self,method,path,body=None,expect=200):
  raw=None if body is None else json.dumps(body,ensure_ascii=False).encode();q=urllib.request.Request(self.base+path,data=raw,method=method,headers={'Content-Type':'application/json'})
  try:
   with urllib.request.urlopen(q,timeout=8) as f:status=f.status;data=f.read()
  except urllib.error.HTTPError as e:
   status=e.code;data=e.read();e.close()
  try:value=json.loads(data)
  except Exception:value={'_raw':data[:500].decode(errors='replace')}
  with (self.folder/'http.jsonl').open('a') as f:f.write(json.dumps({'at':time.time(),'method':method,'path':path,'request':body,'status':status,'response':value},ensure_ascii=False)+'\n')
  if expect is not None:require(status==expect,f'{method} {path}: expected{expect}, got{status}: {str(value)[:350]}')
  if status>=400 and expect is not None:require(isinstance(value.get('error'),dict) and value['error'].get('code') and value['error'].get('message'),'missing structured error')
  return value if expect is not None else (status,value)
 def part(self,stock=10,sku='P1'):return self.req('POST','/api/parts',{'sku':sku,'name':'螺絲','stock':stock},201)
 def order(self,title='維修',customer='陳先生'):return self.req('POST','/api/orders',{'title':title,'customer':customer},201)
 def detail(self,o):return self.req('GET','/api/orders/'+o['id'])
 def change(self,o,path,body,method='PUT',expect=200):return self.req(method,'/api/orders/'+o['id']+'/'+path,{'version':self.detail(o)['version'],**body},expect)
 def reserve(self,o,p,n,expect=200):return self.change(o,'reservations',{'items':[{'partId':p['id'],'quantity':n}]},expect=expect)
 def book(self,o,start='10:00:00',end='11:00:00',bay=1,expect=200):return self.change(o,'booking',{'bay':bay,'start':'2026-11-01T'+start+'Z','end':'2026-11-01T'+end+'Z'},expect=expect)
 def state(self,o,status,expect=200):return self.change(o,'status',{'status':status},method='POST',expect=expect)
 def exported(self):return self.req('GET','/api/export')
 def parts(self):return self.req('GET','/api/parts')
 def unchanged(self,before):require(self.exported()==before,'failed write changed export/audit')
def case(tag,a):
 if tag=='A01':require(a.req('GET','/api/health')['ok'] is True);require(a.parts()==[] and a.req('GET','/api/orders')==[])
 elif tag=='A02':
  p=a.part();require(isinstance(p['id'],str) and p['version']==1 and p['available']==10);q=a.req('PATCH','/api/parts/'+p['id'],{'version':1,'name':'新名稱','stock':8});require(q['version']==2 and q['name']=='新名稱' and q['available']==8 and q['sku']=='P1')
 elif tag=='A03':a.part();b=a.exported();a.req('POST','/api/parts',{'sku':'p1','name':'duplicate','stock':3},409);a.unchanged(b)
 elif tag=='A04':
  for stock in [-1,1.5,True,'2']:a.req('POST','/api/parts',{'sku':'X','name':'bad','stock':stock},422)
  a.req('POST','/api/parts',{'sku':' ','name':'bad','stock':0},422)
 elif tag=='A05':
  o=a.order();require(o['status']=='open' and o['version']==1 and o['notes']=='');d=a.detail(o);require(d['reservations']==[] and d['booking'] is None)
 elif tag=='A06':
  x=a.order('Pump A_100%','CHAN');a.order('other','Lee');a.state(x,'cancelled');q=a.req('GET','/api/orders?q=chan&status=cancelled');require([o['id'] for o in q]==[x['id']]);require(len(a.req('GET','/api/orders?q=%25'))==1);require(a.req('GET','/api/orders?q=%25%25')==[])
 elif tag=='A07':
  p=a.part();o=a.order();a.reserve(o,p,4);require(a.parts()[0]['available']==6);a.reserve(o,p,7);require(a.parts()[0]['available']==3);a.change(o,'reservations',{'items':[]});require(a.parts()[0]['available']==10)
 elif tag=='A08':
  p=a.part();o=a.order();a.reserve(o,p,4);b=a.exported();a.reserve(o,p,11,409);a.unchanged(b)
 elif tag=='A09':
  p=a.part();o=a.order();b=a.exported();a.change(o,'reservations',{'items':[{'partId':p['id'],'quantity':1}]*2},expect=422);a.unchanged(b)
 elif tag=='A10':
  p=a.part();o=a.order();a.reserve(o,p,7);b=a.exported();a.req('PATCH','/api/parts/'+p['id'],{'version':p['version'],'stock':6},409);a.unchanged(b)
 elif tag=='A11':
  p=a.part();o=a.order();b=a.exported()
  for n in [0,-1,1.5,True,'2']:a.reserve(o,p,n,422);a.unchanged(b)
 elif tag=='A12':
  o=a.order();a.req('PATCH','/api/orders/'+o['id'],{'version':1,'notes':'first'});b=a.exported();a.req('PATCH','/api/orders/'+o['id'],{'version':1,'notes':'stale'},409);a.unchanged(b)
 elif tag=='A13':
  o=a.order();q=a.book(o);require(q['version']==2);d=a.detail(o);require(d['booking']['bay']==1);require(a.req('GET','/api/bookings')[0]['orderId']==o['id'])
 elif tag=='A14':
  x=a.order();y=a.order();a.book(x);a.book(y,'12:00:00','13:00:00');b=a.exported();a.book(y,'10:30:00','11:30:00',expect=409);a.unchanged(b)
 elif tag=='A15':
  x=a.order();y=a.order();a.book(x);a.book(y,'11:00:00','12:00:00');require(len(a.req('GET','/api/bookings'))==2)
 elif tag=='A16':
  o=a.order();b=a.exported()
  for start,end in [('bad','bad'),('2026-02-30T10:00:00Z','2026-03-01T11:00:00Z'),('2026-11-01T11:00:00Z','2026-11-01T10:00:00Z'),('2026-11-01T10:00:00+00:00','2026-11-01T11:00:00Z')]:a.change(o,'booking',{'bay':1,'start':start,'end':end},expect=422);a.unchanged(b)
 elif tag=='A17':
  a.book(a.order(),bay=1);a.book(a.order(),bay=2);require(len(a.req('GET','/api/bookings'))==2)
 elif tag=='A18':
  o=a.order();b=a.exported()
  for bay in [0,3,True,'1']:a.book(o,bay=bay,expect=422);a.unchanged(b)
 elif tag=='A19':
  o=a.order();b=a.exported();a.state(o,'done',409);a.unchanged(b)
 elif tag=='A20':
  p=a.part();o=a.order();a.reserve(o,p,3);a.state(o,'in_progress');a.state(o,'done');q=a.parts()[0];require(q['stock']==7 and q['available']==7 and q['version']>p['version']);require(a.detail(o)['status']=='done')
 elif tag=='A21':
  p=a.part();o=a.order();a.reserve(o,p,3);a.state(o,'in_progress');a.state(o,'done');b=a.exported();a.state(o,'done',409);a.unchanged(b);a.reserve(o,p,1,409);a.unchanged(b)
 elif tag=='A22':
  p=a.part();o=a.order();a.reserve(o,p,4);a.state(o,'cancelled');require(a.parts()[0]['stock']==10 and a.parts()[0]['available']==10)
 elif tag=='A23':
  o=a.order();a.book(o);a.state(o,'cancelled');require(a.req('GET','/api/bookings')==[]);a.book(a.order());a.book(o,expect=409)
 elif tag=='A24':
  p=a.part();o=a.order();a.reserve(o,p,3);rows=a.req('GET','/api/audit');require(len(rows)==3 and all(x.get('id') and x.get('action') and x.get('entityId') and x.get('at') for x in rows));require([x['at'] for x in rows]==sorted([x['at'] for x in rows],reverse=True));b=a.exported();a.reserve(o,p,99,409);a.unchanged(b)
 elif tag=='A25':
  p=a.part();o=a.order();a.reserve(o,p,2);a.book(o);b=a.exported();a.stop();a.start();require(a.exported()==b)
 elif tag=='A26':
  e=a.exported();require(e['schemaVersion']==1 and all(isinstance(e[k],list) for k in ['parts','orders','reservations','bookings','audit']))
 elif tag=='A27':
  p=a.part();o=a.order();a.reserve(o,p,2);a.book(o);a.state(o,'in_progress');a.state(o,'done');b=a.exported();res=a.req('POST','/api/import',b);require(res['ok'] is True);c=a.exported();require(all(sorted(c[k],key=lambda x:json.dumps(x,sort_keys=True))==sorted(b[k],key=lambda x:json.dumps(x,sort_keys=True)) for k in ['parts','orders','reservations','bookings']));a.stop();a.start();require(a.parts()[0]['stock']==8)
 elif tag=='A28':
  p=a.part();o=a.order();a.reserve(o,p,2);b=a.exported();bad=[]
  for key,val in [('schemaVersion',2)]:c=copy.deepcopy(b);c[key]=val;bad.append(c)
  c=copy.deepcopy(b);c['parts'][0]['stock']=-1;bad.append(c)
  c=copy.deepcopy(b);c['reservations'][0]['partId']='missing';bad.append(c)
  c=copy.deepcopy(b);c['orders'][0]['status']='nonsense';bad.append(c)
  c=copy.deepcopy(b);c['parts'].append(copy.deepcopy(c['parts'][0]));bad.append(c)
  c=copy.deepcopy(b);c['reservations'][0]['quantity']=99;bad.append(c)
  for c in bad:a.req('POST','/api/import',c,422);a.unchanged(b)
 elif tag=='A29':
  p=a.part(5);orders=[a.order(),a.order()];bar=threading.Barrier(2)
  def submit(o):bar.wait();return a.req('PUT','/api/orders/'+o['id']+'/reservations',{'version':1,'items':[{'partId':p['id'],'quantity':4}]},None)[0]
  with futures.ThreadPoolExecutor(2) as ex:codes=list(ex.map(submit,orders))
  require(sorted(codes)==[200,409],str(codes));require(a.parts()[0]['available']==1)
 elif tag=='A30':
  a.order();require(a.req('GET','/api/orders?q=%27%20OR%201%3D1--')==[])
  for path in ['/app.py','/workshop.sqlite','/%2e%2e/app.py']:
   try:
    with urllib.request.urlopen(a.base+path,timeout=3) as f:body=f.read()
   except urllib.error.HTTPError:continue
   require(not body.startswith(b'SQLite format 3') and body!=(a.candidate/'app.py').read_bytes(),'private/source file exposed')
 else:raise ValueError(tag)
def main():
 candidate=pathlib.Path(sys.argv[1]).resolve();dest=pathlib.Path(sys.argv[2]).resolve();dest.mkdir(parents=True,exist_ok=True);results=[]
 for n in range(1,31):
  tag=f'A{n:02d}';folder=dest/tag;a=App(candidate,folder);start=time.monotonic();row={'id':tag,'passed':False}
  try:a.start();case(tag,a);row['passed']=True
  except Exception as e:row['error']=repr(e)
  finally:a.stop();row['wall_s']=time.monotonic()-start;results.append(row);(dest/'results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n');print(json.dumps(row,ensure_ascii=False),flush=True)
 print(json.dumps({'passed':sum(x['passed'] for x in results),'total':len(results)}))
if __name__=='__main__':main()
