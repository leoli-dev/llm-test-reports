"""Positive/negative controls for HTTP capture/assertions; not a reference app."""
import http.server,json,pathlib,tempfile,threading,unittest
from acceptance import App,require
class Handler(http.server.BaseHTTPRequestHandler):
 def log_message(self,*args):pass
 def do_GET(self):
  status,value=(200,{'ok':True}) if self.path=='/good' else ((422,{'error':{'code':'invalid','message':'known invalid'}}) if self.path=='/reject' else (409,{'wrong':'shape'}))
  self.send_response(status);self.send_header('Content-Type','application/json');self.end_headers();self.wfile.write(json.dumps(value).encode())
class Controls(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.tmp=tempfile.TemporaryDirectory();cls.server=http.server.ThreadingHTTPServer(('127.0.0.1',0),Handler);threading.Thread(target=cls.server.serve_forever,daemon=True).start();cls.a=App('.',cls.tmp.name);cls.a.base='http://127.0.0.1:'+str(cls.server.server_port)
 @classmethod
 def tearDownClass(cls):cls.server.shutdown();cls.server.server_close();cls.tmp.cleanup()
 def test_valid(self):self.assertEqual(self.a.req('GET','/good'),{'ok':True})
 def test_known_rejection(self):self.assertEqual(self.a.req('GET','/reject',expect=422)['error']['code'],'invalid')
 def test_wrong_status_fails(self):
  with self.assertRaises(AssertionError):self.a.req('GET','/good',expect=422)
 def test_wrong_error_shape_fails(self):
  with self.assertRaises(AssertionError):self.a.req('GET','/wrong',expect=409)
 def test_condition_positive_negative(self):
  require(True)
  with self.assertRaises(AssertionError):require(False,'negative control')
if __name__=='__main__':unittest.main(verbosity=2)
