"""Switch only the two authorized managed services after Strata source freezes."""
from pathlib import Path
import datetime,json,subprocess,time,urllib.request
E=Path(__file__).resolve().parents[1];L=Path('/Users/benchmark/local_llms');PY=str(L/'strata/runtime/terminal/0.1.51/python/bin/python3')
def stamp():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def step(name,cmd,timeout=600):
 start=time.monotonic();at=stamp()
 with (E/'raw'/(name+'.log')).open('wb') as f:r=subprocess.run(cmd,cwd=E,stdout=f,stderr=subprocess.STDOUT,timeout=timeout)
 row={'name':name,'at':at,'wall_s':time.monotonic()-start,'exit':r.returncode};steps.append(row);dump(E/'raw/service-switches.json',steps);print(json.dumps(row),flush=True);r.check_returncode()
def main():
 while not (E/'raw/strata/formal/source-snapshot.json').exists():time.sleep(2)
 step('strata-stop-for-splash',[str(L/'strata/stop.sh')])
 step('splash-start',[str(L/'splash/start.sh')])
 step('splash-smoke-driver',[PY,'-u','harness/runner.py','splash','smoke'],360)
 r=E/'raw/splash/smoke';events=[json.loads(x) for x in (r/'pi-events.jsonl').read_text().splitlines()];messages=[v['message'] for v in events if v.get('type')=='message_end' and v.get('message',{}).get('role')=='assistant'];text=''.join(x.get('text','') for x in messages[-1].get('content',[]) if x.get('type')=='text') if messages else '';probe=r/'smoke-project/probe.txt';checks={'file_write':probe.exists() and probe.read_text().strip()=='391','tool_readback':any(v.get('type')=='tool_execution_end' and v.get('toolName')=='bash' and not v.get('isError') for v in events),'json_math':False}
 try:checks['json_math']=json.loads(text)=={'ok':True,'product':391}
 except Exception:pass
 checks['passed']=sum(checks.values());dump(r/'checks.json',checks);print(json.dumps({'splash_smoke':checks}),flush=True)
 if not checks['file_write'] or not checks['tool_readback']:raise RuntimeError('Splash tool-chain smoke failed; preserve trace before proceeding')
 step('splash-formal-driver',[PY,'-u','harness/runner.py','splash','formal'],3700)
 step('splash-stop-after-run',[str(L/'splash/stop.sh')])
 summaries=[json.loads((E/f'raw/{x}/formal/summary.json').read_text()) for x in ['strata','splash']]
 if not any(x['reason']=='resource_abort' for x in summaries):step('strata-restore',[str(L/'strata/start.sh')])
 dump(E/'raw/pair-complete.json',{'at':stamp(),'both_source_snapshots':all((E/f'raw/{x}/formal/source-snapshot.json').exists() for x in ['strata','splash']),'strata_restored':not any(x['reason']=='resource_abort' for x in summaries),'summaries':[{k:v for k,v in x.items() if k!='backend_after'} for x in summaries]})
steps=[]
if __name__=='__main__':main()
