"""After both development snapshots finish, validate byte-preserving source copies."""
from pathlib import Path
import hashlib,json,subprocess,tarfile,time,io,sys
E=Path(__file__).resolve().parents[1];ROOT=E.parent
def main():
 while not (E/'raw/pair-complete.json').exists():time.sleep(2)
 assert all((E/f'raw/{x}/formal/source-snapshot.json').exists() for x in ['strata','splash'])
 for label in ['strata','splash']:
  src=ROOT/label;dest=E/'artifacts'/label;dest.mkdir(exist_ok=True);source=dest/'source';source.mkdir(exist_ok=False)
  archive=subprocess.check_output(['git','archive','HEAD'],cwd=src)
  with tarfile.open(fileobj=io.BytesIO(archive)) as t:t.extractall(source,filter='data')
  (dest/'git-log.txt').write_text(subprocess.check_output(['git','log','--date=iso-strict','--format=fuller','--stat'],cwd=src,text=True));(dest/'source.diff').write_bytes(subprocess.check_output(['git','diff',subprocess.check_output(['git','rev-list','--max-parents=0','HEAD'],cwd=src,text=True).strip(),'HEAD'],cwd=src))
  manifest=[{'path':str(p.relative_to(source)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(source.rglob('*')) if p.is_file()];(dest/'source-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
  out=E/'scoring'/label;out.mkdir(exist_ok=True)
  with (out/'api-driver.log').open('wb') as f:r=subprocess.run([sys.executable,str(E/'harness/acceptance.py'),str(source),str(out/'api')],stdout=f,stderr=subprocess.STDOUT)
  print(json.dumps({'label':label,'stage':'api_complete','driver_exit':r.returncode}),flush=True)
 for label in ['strata','splash']:
  source=E/'artifacts'/label/'source';out=E/'scoring'/label
  with (out/'browser-driver.log').open('wb') as f:r=subprocess.run(['node',str(E/'harness/browser.cjs'),str(source),str(out/'browser')],stdout=f,stderr=subprocess.STDOUT,timeout=300)
  print(json.dumps({'label':label,'stage':'browser_complete','driver_exit':r.returncode}),flush=True)
  manifest=json.loads((E/'artifacts'/label/'source-manifest.json').read_text());changed=[x['path'] for x in manifest if not (source/x['path']).exists() or hashlib.sha256((source/x['path']).read_bytes()).hexdigest()!=x['sha256']];(out/'source-integrity.json').write_text(json.dumps({'modified_tracked_sources':changed,'unchanged':not changed},indent=2)+'\n')
 (E/'scoring/automatic-acceptance-complete.json').write_text(json.dumps({'completed_at_unix':time.time(),'scope':'Automated acceptance only; manual quality and UI review still required.'},indent=2)+'\n')
if __name__=='__main__':main()
