"""Post-review diagnostics, outside the frozen30 API points. No source changes."""
import json,pathlib,sqlite3,sys
from acceptance import App
E=pathlib.Path(__file__).resolve().parents[1]
def main():
 rows=[]
 for label in ['strata','splash']:
  source=E/'artifacts'/label/'source';d=E/'scoring'/label/'diagnostics';d.mkdir(exist_ok=True)
  for name in ['audit-failure','schema-bool','schema-float']:
   app=App(source,d/name);row={'label':label,'id':name}
   try:
    app.start()
    if name=='audit-failure':
     with sqlite3.connect(app.db) as conn:conn.execute("CREATE TRIGGER injected_failure BEFORE INSERT ON audit BEGIN SELECT RAISE(FAIL,'diagnostic audit failure'); END")
     status,value=app.req('POST','/api/parts',{'sku':'FAULT','name':'fault probe','stock':3},None);parts=app.parts();row.update(http_status=status,response=value,parts_after_failed_request=parts,rollback_preserved=len(parts)==0)
    else:
     payload=app.exported();payload['schemaVersion']=True if name=='schema-bool' else 1.0;status,value=app.req('POST','/api/import',payload,None);row.update(http_status=status,response=value,rejected=status==422)
   except Exception as e:row['error']=repr(e)
   finally:app.stop();rows.append(row)
 (E/'scoring/diagnostics.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n');print(json.dumps(rows,ensure_ascii=False))
if __name__=='__main__':main()
