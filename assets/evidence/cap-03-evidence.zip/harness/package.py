"""Create a verified local evidence archive, excluding credentials and runtime DBs."""
from pathlib import Path
import hashlib,json,subprocess,zipfile
E=Path(__file__).resolve().parents[1];ROOT=E.parent
def main():
 assert (E/'REPORT.md').exists()
 files=[]
 for p in E.rglob('*'):
  rel=p.relative_to(E)
  if p.is_file() and not any(x in ['private','.git','__pycache__'] for x in rel.parts) and p.suffix not in ['.pyc','.sqlite','.sqlite3','.db','.zip'] and p.name not in ['evidence-manifest.json','evidence.zip.sha256'] and not any(p.name.endswith(x) for x in ['-wal','-shm']):files.append((p,'evaluation/'+str(rel)))
 for label in ['strata','splash']:
  src=ROOT/label
  for name in subprocess.check_output(['git','ls-files','-z'],cwd=src).decode().split('\0'):
   if name:files.append((src/name,label+'/'+name))
 files.append((ROOT/'README.md','README.md'));files=sorted(files,key=lambda x:x[1]);manifest=[{'path':name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p,name in files];mp=E/'evidence-manifest.json';mp.write_text(json.dumps(manifest,indent=2)+'\n');archive=E/'evidence.zip'
 with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for p,name in files:z.write(p,name)
  z.write(mp,'evaluation/evidence-manifest.json')
 with zipfile.ZipFile(archive) as z:
  assert z.testzip() is None
  for row in manifest:assert hashlib.sha256(z.read(row['path'])).hexdigest()==row['sha256']
 sha=hashlib.sha256(archive.read_bytes()).hexdigest();(E/'evidence.zip.sha256').write_text(sha+'  evidence.zip\n');print(json.dumps({'files':len(manifest)+1,'bytes':archive.stat().st_size,'sha256':sha,'verified':True}))
if __name__=='__main__':main()
