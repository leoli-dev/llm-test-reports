"""Isolated simple-request header probe, no external website is contacted."""
import json,urllib.request
from acceptance import App,ROOT
def main():
 out=[]
 for label in ['strata','splash']:
  app=App(ROOT/'artifacts'/label/'source',ROOT/'scoring'/label/'cross-origin')
  try:
   app.start();app.part();payload=app.exported();payload['parts']=[];payload['audit']=[]
   q=urllib.request.Request(app.base+'/api/import',data=json.dumps(payload).encode(),headers={'Content-Type':'text/plain','Origin':'http://untrusted.invalid'},method='POST')
   with urllib.request.urlopen(q,timeout=5) as f:status=f.status;response=json.load(f)
   out.append({'label':label,'status':status,'response':response,'remaining_parts':len(app.parts()),'note':'Isolated synthetic DB; cross-origin simple-request headers accepted, no real external site contacted.'})
  finally:app.stop()
 (ROOT/'scoring/cross-origin.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
if __name__=='__main__':main()
