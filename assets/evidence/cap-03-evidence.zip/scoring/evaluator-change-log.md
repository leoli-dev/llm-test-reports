# Evaluator changes before independent acceptance

Initial rubric, brief, API evaluator and runner committed33e236e before candidate writes. The browser driver was implemented solely from the frozen hooks/rubric during Strata API development, before viewing either UI. No candidate implementation source was consulted.

- Close urllib HTTPError handles after capture; preserve v1/v2 selftest logs.
- Compare backup business arrays without imposing an unspecified export ordering.
- Reset the UI status selector to its first/all option, without assuming its internal value is an empty string.
- Order filtering/browser targeting checks visible rows, allowing compliant DOM implementations to hide rather than remove filtered rows.
- Browser validation explicitly blocks and records non-loopback remote requests to enforce the no-CDN/offline requirement equally.

The final identical scorer is used for both after both source snapshots freeze. Any later driver adaptation or manual scoring is recorded separately; no implementation patches by the supervisor.

## Post-snapshot driver corrections (both candidates uniformly rerun)

Initial UI results preserved in scoring/*/browser. Inspection showed the brief did not require select option values to equal IDs, details to be modal, or the schedule to show a title rather than its order ID. v2 selects by value/data-part-id/SKU, uses a visible return-to-list control for full-page details, and accepts ID or title on the schedule. These are driver errors, not candidate failures. v2 also records whether conflict submission preserves date inputs, then re-enters dates to test successful rebooking; input loss receives partial credit under the frozen rubric. No candidate source is patched.

The second driver run exposed premature DOM inspection: options and schedule text were checked before asynchronous fetch/render finished, and navigation could re-enter a full-page detail after an edit. v3 explicitly waits for options/schedule content and the visible list/back control after navigation. Both v1/v2 results are retained, and both candidates receive the same v3 rerun on fresh disposable DBs. These timing assumptions are evaluator defects, not application repairs.
