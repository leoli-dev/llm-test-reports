# 復現與證據閱讀

本機環境：M5 Max128GiB／macOS27.0.1，Pi1.4.0，Python3.14.7，Node22.23.1；現有Strata/Splash安裝不重建、不重新下載權重。完整凍結規則見PLAN.md，需求見BRIEF.md。

## 只重驗交付程式碼

兩份原始碼在上層strata/、splash/；artifacts各候選source/是凍結Git archive的字節相同副本。source-manifest.json有逐檔SHA256；history.bundle包含完整Git歷史，git-log.txt和source.diff便於閱讀。不要在原結果DB/資料夾重跑，所有HTTP驗收必須使用新空目錄。

```sh
cd ~/Code/qwen3.8_tests/2026-10-25-repairdesk-comparison/evaluation
repairdesk_check_dir=$(mktemp -d /tmp/repairdesk-check.XXXXXX)
python3 harness/acceptance.py artifacts/strata/source "$repairdesk_check_dir/strata-api"
python3 harness/acceptance.py artifacts/splash/source "$repairdesk_check_dir/splash-api"
node harness/browser.cjs artifacts/strata/source "$repairdesk_check_dir/strata-browser"
node harness/browser.cjs artifacts/splash/source "$repairdesk_check_dir/splash-browser"
```

瀏覽器使用`/Applications/Chromium.app/Contents/MacOS/Chromium`，Playwright1.62.1來自本機Codex bundled runtime（harness內列出路徑）；不用Google Chrome或chrome channel。Browser結果是自動化證據，不等於最終人工裁定；review.json保存U05/U07/U09的裁定及補充流程證據。特別是Splash返回清單的真缺陷會連帶阻斷下一個driver步驟，不能重複當成鍵盤功能不會用。

模型自寫測試分別在候選目錄執行`python3 -m unittest discover -s tests -v`。Strata本次107/108，競態測試錯誤假定固定勝者，10次單項重跑6/10；Splash69/69。不要把這些不同試卷的數量當作同一分母。

附加診斷都只對測試DB運行：diagnostics.py（audit trigger故障、schema型別）、cross_origin.py（假Origin/plain-body入口）、id_xss.cjs（有效字串型別的惡意ID）、schedule_xss.cjs（另一條路徑陰性結果）、manual_ui.cjs（完整編輯/狀態、返回、鍵盤、零件更新和取消）。它們在原scoring目錄使用固定輸出位置；需要重跑時先複製整個evaluation到新的獨立實驗目錄，避免覆寫此輪證據。

## 重新做一次模型開發比較

必須另開實驗根，兩個新候選只放相同BRIEF.md和.gitignore並建立空Git基線，不能把舊實作當新樣本。複製凍結harness、phase-1…4提示及PLAN，重新捕捉環境與hash。

runner使用`/Users/benchmark/local_llms/strata/runtime/terminal/0.1.51/python/bin/python3`，含psutil與原生macOS採樣依賴。Pi隔離設定放新evaluation/private/pi-strata與pi-splash；由configs的兩份pi-model.json重建providers字典（去除頂層provider欄位），baseUrl保持記錄代理127.0.0.1:18086，apiKey是非秘密dummy。settings啟用compaction reserve32768/keepRecent16000、關閉自動retry。真正服務憑據只在代理內讀既有local_llms各data/api-key，從不寫入請求記錄。

1. 確認其他大型候選服務沒有同時載入；Strata/Splash原生與Pi均262144。保存初始服務狀態，使用現有start/status/stop管理腳本。
2. 保存需求/預算/評測器Git提交，執行scorer_selftest.py並檢查正負控制。每候選先跑`runner.py <label> smoke`，檢查寫檔、讀回與JSON結果。
3. `runner.py strata formal`正式四階段，continue_pair.py等待快照後切換Splash、做其smoke/formal、結束再恢復最初服務狀態。正式每候選最多60分鐘，輸出/工具/資源停止條件見PLAN；保留失敗，不縮題、不重抽。
4. assess.py等待pair-complete.json後，凍結來源副本，對兩邊跑相同API/browser；人工核對driver失敗及源碼，沒有向模型回饋隱藏驗收或修補程式。此輪v1/v2/v3的driver假設修正見evaluator-change-log.md。
5. analyze_run.py按候選生成運行統計；review.json是有證據的人工評分，不能用舊人工評分去評新實作。report.py只整理現有證據，package.py生成ZIP並逐檔讀回校驗。

這是一個項目、一輪實用系統比較。不可將重跑挑最好的一次當原始分數，也不能歸因為純引擎或量化差異。候選姓名未對評審隱藏；所有評測器錯誤和補充測試保留。沒有公開發布。

## 證據包

evidence.zip包括兩份交付源碼、Git bundles、需求/腳本、原始Pi RPC與session、模型請求/SSE、資源JSONL、全部驗收/診斷/截圖及報告。private/、API-key檔、模型大檔、運行DB與.git目錄不打包。evidence-manifest.json列出內容SHA256，evidence.zip.sha256驗整個壓縮檔。
