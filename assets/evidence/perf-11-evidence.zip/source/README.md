# Splash 8-bit native 256K context stress test

PERF-11. Test start: 2026-10-21, America/Toronto. Local Apple M5 Max / 128 GiB. This is a finite capacity and recovery exercise, not an official benchmark or a long-running reliability estimate.

Frozen before inference: Splash 1.4.0 source 1482f6bbc2abf12375332725302019594150b6cb, existing MLX affine8 Qwen3.8-27B checkpoint revision 815b83c0df8ffd1d1b5244cf75fd6ef14fca9ef9 and installed BF16 DFlash2, native Metal inference, INT8 KV, FP32 recurrent states, 96 GiB memory cap, 262144 total context tokens, no disk prefix cache, automatic ANE policy. No YaRN beyond the model's native window. Direct HTTP API, reasoning disabled, temperature 1 / top_p .95 / top_k 20. Pi configuration is not changed.

Sequence:

1. Fresh server, 130560 actual template-inclusive text input tokens + at most 512 output (128K budget), five-key retrieval.
2. Same server, distinct-prefix 196096 input + 512 output (192K), five-key retrieval.
3. Same server, distinct-prefix 258048 input + 4096 output (256K), first-line five-key retrieval then sustained SQL generation. At least 2048 output tokens is long-decode coverage; exactly 4096 is full-budget coverage. Early natural stop is recorded without resampling.
4. Repeat the exact step-3 request to observe warm in-memory prefix reuse, not a second cold sample.
5. Submit two simultaneous 258048-token input requests, differing only in the final request tag, with 256 output each, five-key retrieval. This is prefix-reusing admission/batch stress; do not describe it as two independent cold prefills. Retain actual native lane/concurrency/cache metrics; simultaneous clients do not prove simultaneous GPU execution.
6. Submit an actually tokenized 262145-token input with 16 output requested: expect HTTP 400 context_length_exceeded, then a short exact-answer recovery.

After every serial step and the concurrent pair, submit a small exact-answer recovery request and check ready/Metal health, configured context, native transport restart counters, memory pressure, resource errors. Inputs contain seeded synthetic records and five random key/value needles around 1%, 25%, 50%, 75%, 99% of the input. Store exact token counts and hashes before generation; verify counts again with the server tokenizer and terminal usage. No prompt truncation is permitted. The generation seed is not fixed; this is one run per step. No visual task is included.

The single test server persists through the whole sequence, so resources and cached prefixes accumulate. Unique stage prefixes are intended to avoid stage-to-stage cache hits, which must be confirmed in native results. Server startup/calibration is timed separately. Client timings distinguish first nonempty text, last text and SSE completion; native prompt/decode metrics retain their different denominators. Total sequence duration also includes CPU preparation, recovery and observation overhead.

Telemetry every two seconds: native process footprint/RSS, tree/frontend metrics, native allocated/current/peak, CPU/GPU counters, system pressure, swap, thermal state and native status. Existing swap usage is a baseline, not caused by this run. Abort the owned server for 15 consecutive critical samples (~30 seconds), native footprint >115 GiB, or swap growth >8 GiB. Per-request absolute wall deadline 3600 seconds; server request timeout also 3600 seconds. No user application or pre-existing model process is terminated. Port 8084 must be free before startup.

Raw data live under ignored .local/ with private permissions; public report/evidence must exclude authentication and generalize home/work paths. Freeze the protocol and harness before generation. Any implementation corrections and failed attempts remain dated and visible. Model files and configuration/auth are never committed. Report archive: $HOME/Code/llm-test-reports; pair EN/CN and register as PERF-11.

## Pre-inference implementation correction

Initial CPU-only preparation failed because this installed Transformers version returns a mapping from apply_chat_template(tokenize=True), and len(mapping) counted fields instead of input IDs. No inference or request packet was submitted. The helper now renders the template as text and explicitly encodes it without extra special tokens; service-side preflight independently verifies token counts and hashes before inference. The failed preparation is retained in .local/preparation-attempt1.txt.

## Observed run, 2026-10-21

Sequence completed in 1964.29 seconds (32.74 minutes), including startup and CPU preflight. Cold 256K: 258048 input +4096 output =262144, first content947.72s, total1023.74s, content53.88tok/s on repetitive SQL, five-key retrieval5/5. Exact warm repeat:258016 cached, first content0.363s, total77.89s, full4096 and5/5. Both concurrent clients processed258048 input and retrieved5/5; native sampled prefill/decode widths reached2; group30.97s, with substantial prefix sharing and asymmetric queue delay. Actual262145-input request rejectedHTTP400; six recoveries passed. Peak sampled native footprint50.99GiB; global swap unchanged6.93GiB; all977 pressure samples normal. Strict audit62/63: its only failure is four startup telemetry gaps before ready; all973 post-startup samples have no telemetry errors. Native capacity/Metal failures and transport restarts0. Test-owned server exited normally0. No generated input/output was repaired and no generation was resampled. See paired PERF-11 archive report and sanitized evidence for measurement definitions and limitations.
