from pathlib import Path
import hashlib,json,re,subprocess,zipfile
ROOT=Path(__file__).resolve().parents[1];P=ROOT/'.local';A=Path('$HOME/Code/llm-test-reports')
def sha(b):return hashlib.sha256(b).hexdigest()
def public(b):
 text=b.decode('utf-8')
 for old,new in [(str(ROOT),'$TEST_ROOT'),('$LOCAL_LLMS','$LOCAL_LLMS'),('$HOME','$HOME')]:text=text.replace(old,new)
 text=re.sub(r'(InternalBattery-\d+\s*\(id=)\d+',r'\1REDACTED',text)
 return text.encode()
def main():
 assert (P/'exit.json').exists(),'Do not package an active run'
 key=Path('$LOCAL_LLMS/splash/data/api-key').read_text().strip().encode()
 dest=A/'assets/evidence/perf-11-evidence.zip';manifest=[];files=[]
 for p in sorted(ROOT.rglob('*')):
  if not p.is_file() or '.git' in p.parts or '__pycache__' in p.parts:continue
  rel=p.relative_to(ROOT)
  if rel.parts[0]=='.local':
   if p.suffix not in ('.json','.jsonl','.log','.txt'):continue
   name='records/'+str(Path(*rel.parts[1:]))
  else:
   if p.suffix not in ('.md','.py','.json','.txt') and p.name!='.gitignore':continue
   name='source/'+str(rel)
  raw=p.read_bytes();out=public(raw);assert not key or key not in out,(name,'secret detected')
  files.append((name,out));manifest.append({'file':name,'local_bytes':len(raw),'public_bytes':len(out),'local_sha256':sha(raw),'public_sha256':sha(out),'transformed':raw!=out})
 publication={'source_commit':subprocess.check_output(['git','-C',str(ROOT),'rev-parse','HEAD'],text=True).strip(),'protocol_freeze':'e64ddb6a120886305b021197bad3859a2b1fa133','transformations':'Generalize home/runtime/test paths to symbolic variables; redact battery ID; preserve original/public byte counts and SHA256. Source paths require adaptation to reproduce. No auth headers, private model configuration, model weights, runtime caches or unrelated personal sessions included. Generated inputs/outputs are synthetic. Prior reference-model-provenance includes MLTF metadata only as historical shared-weight context; actual Splash assembly is records/installed-model-manifest.json.'}
 with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for name,b in files:z.writestr(name,b)
  z.writestr('MANIFEST.json',json.dumps(manifest,indent=2));z.writestr('PUBLICATION.json',json.dumps(publication,indent=2))
 with zipfile.ZipFile(dest) as z:
  assert z.testzip() is None
  for e in manifest:assert sha(z.read(e['file']))==e['public_sha256']
 receipt={'file':str(dest),'bytes':dest.stat().st_size,'sha256':sha(dest.read_bytes()),'manifest_files':len(manifest),'zip_integrity_pass':True,'all_public_hashes_pass':True,'auth_key_absent':True}
 (P/'publication-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
if __name__=='__main__':main()
