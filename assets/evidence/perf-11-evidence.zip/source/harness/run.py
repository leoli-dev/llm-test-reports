from pathlib import Path
import concurrent.futures,hashlib,json,os,re,signal,socket,struct,subprocess,threading,time,urllib.request,urllib.error
from resource_collector import ResourceCollector

ROOT=Path(__file__).resolve().parents[1];P=ROOT/'.local';L=Path('$LOCAL_LLMS')
BASE='http://127.0.0.1:8084';MODEL='mlx-community/Qwen3.8-27B-8bit'
KEY=(L/'splash/data/api-key').read_text().strip()
STATE={'stage':'startup','phase':'startup'};STOP=threading.Event();ABORT=threading.Event();PROC=None
def dump(p,v):
 t=p.with_suffix(p.suffix+'.tmp');t.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n');t.replace(p)
def api(path,body=None,timeout=15):
 q=urllib.request.Request(BASE+path,data=None if body is None else json.dumps(body).encode(),headers={'Authorization':'Bearer '+KEY,'Content-Type':'application/json'})
 with urllib.request.urlopen(q,timeout=timeout) as r:return json.load(r)
def status():return api('/status',timeout=3)
def log(v):print(json.dumps(v,ensure_ascii=False),flush=True)
def kill_owned():
 if PROC is None:return
 try:os.killpg(PROC.pid,signal.SIGTERM)
 except ProcessLookupError:pass
def command(args):
 r=subprocess.run(args,capture_output=True,text=True,timeout=20)
 return {'command':args,'stdout':r.stdout,'stderr':r.stderr,'returncode':r.returncode}
def sampler():
 c=ResourceCollector(PROC.pid,'mltf',status_callback=status);critical=0;baseline_swap=None
 with (P/'resources.jsonl').open('w') as f:
  while not STOP.is_set():
   t=time.monotonic();row=c.collect(**STATE);row['engine_allocation_source']='Splash memory_actual, not MLTF';f.write(json.dumps(row)+'\n');f.flush()
   critical=critical+1 if row.get('memory_pressure_name')=='critical' else 0
   swap=row.get('swap_used_bytes')
   if baseline_swap is None and swap is not None:baseline_swap=swap
   reasons=[]
   if critical>=15:reasons.append('15 consecutive critical-pressure samples')
   if (row.get('process_physical_footprint_bytes') or 0)>115*2**30:reasons.append('native footprint >115GiB')
   if baseline_swap is not None and swap is not None and swap-baseline_swap>8*2**30:reasons.append('swap growth >8GiB')
   if reasons:dump(P/'resource-abort.json',{'reasons':reasons,'sample':row});ABORT.set();kill_owned();return
   STOP.wait(max(.05,2-(time.monotonic()-t)))
def preflight(tag):
 payload=json.loads((P/(tag+'-request.json')).read_text());meta=json.loads((P/(tag+'-meta.json')).read_text())
 t=time.monotonic();prompt=api('/apply-template',{**payload,'add_generation_prompt':True},180)['prompt']
 tokens=api('/tokenize',{'content':prompt,'add_special':False},180)['tokens']
 result={'id':tag,'seconds':time.monotonic()-t,'input_tokens':len(tokens),'formatted_prompt_sha256':hashlib.sha256(prompt.encode()).hexdigest(),'input_token_ids_sha256':hashlib.sha256(b''.join(struct.pack('<I',v) for v in tokens)).hexdigest(),'matches_frozen_tokens':len(tokens)==meta['input_tokens'] and hashlib.sha256(b''.join(struct.pack('<I',v) for v in tokens)).hexdigest()==meta['input_token_ids_sha256']}
 dump(P/(tag+'-preflight.json'),result);assert result['matches_frozen_tokens'],result
 return payload,meta
def judge(text,expected):
 try:
  first=text.strip().splitlines()[0];obj=json.loads(first)
  checks={k:obj.get(k)==v for k,v in expected.items()};return {'first_line':first,'checks':checks,'passed':sum(checks.values()),'total':len(expected),'exact_object':obj==expected}
 except Exception as e:return {'passed':0,'total':len(expected),'error':repr(e),'first_line':text[:300]}
def infer(label,payload,meta=None,expected_reject=False):
 raw=json.dumps(payload,ensure_ascii=False).encode();dump(P/(label+'-submitted.json'),payload)
 result={'id':label,'started_unix_seconds':time.time(),'errors':[],'payload_sha256':hashlib.sha256(raw).hexdigest(),'requested_max_tokens':payload['max_tokens'],'expected_input_tokens':meta['input_tokens'] if meta else None}
 parts=[];times=[];start=time.monotonic();timer=threading.Timer(3600,lambda:(ABORT.set(),dump(P/(label+'-deadline.json'),{'deadline_seconds':3600}),kill_owned()));timer.daemon=True;timer.start()
 try:
  result['status_before']=status();start=time.monotonic();q=urllib.request.Request(BASE+'/v1/chat/completions',data=raw,headers={'Authorization':'Bearer '+KEY,'Content-Type':'application/json'})
  log({'id':label,'state':'started','input':meta['input_tokens'] if meta else None,'max_tokens':payload['max_tokens']})
  with urllib.request.urlopen(q,timeout=3600) as response,(P/(label+'-stream.jsonl')).open('w') as f:
   result['http_status']=response.status
   for line in response:
    if not line.startswith(b'data:'):continue
    data=line[5:].strip()
    if data==b'[DONE]':result['sse_done']=True;break
    event=json.loads(data);elapsed=time.monotonic()-start;f.write(json.dumps({'seconds':elapsed,'event':event},ensure_ascii=False)+'\n');f.flush()
    if event.get('error'):result['errors'].append(event['error'])
    text=''.join(c.get('delta',{}).get('content') or '' for c in event.get('choices',[]))
    if text:
     if not times:result['ttft_seconds']=elapsed
     times.append(elapsed);parts.append(text)
    if event.get('usage'):result['usage']=event['usage']
    if event.get('timings'):result['timings']=event['timings']
    if event.get('metrics'):result['metrics']=event['metrics']
    for c in event.get('choices',[]):
     if c.get('finish_reason') is not None:result['finish_reason']=c['finish_reason']
 except urllib.error.HTTPError as e:
  result['http_status']=e.code;result['http_error_body']=e.read().decode(errors='replace')
  if not expected_reject:result['errors'].append('HTTP '+str(e.code))
 except Exception as e:result['errors'].append(repr(e))
 finally:
  timer.cancel();result['wall_seconds']=time.monotonic()-start;result['finished_unix_seconds']=time.time();text=''.join(parts);(P/(label+'-output.txt')).write_text(text);result['output_characters']=len(text)
  result['content_chunk_count']=len(times)
  if len(times)>1:
   result['content_span_seconds']=times[-1]-times[0];result['content_tok_s']=result.get('usage',{}).get('completion_tokens',0)/result['content_span_seconds']
   gaps=sorted(b-a for a,b in zip(times,times[1:]));result['chunk_gaps']={'max':max(gaps),'p95':gaps[int((len(gaps)-1)*.95)],'over_5_seconds':sum(x>5 for x in gaps)}
  usage=result.get('usage',{})
  if meta and not expected_reject:
   result['retrieval']=judge(text,meta['expected']);result['count_verified']=usage.get('prompt_tokens')==meta['input_tokens'];result['within_context']=usage.get('total_tokens',262145)<=262144;result['long_decode_2048']=usage.get('completion_tokens',0)>=2048 if meta['long_output'] else None;result['full_output_budget']=usage.get('completion_tokens')==payload['max_tokens']
   result['mechanical_pass']=result.get('sse_done',False) and not result['errors'] and result['count_verified'] and result['within_context'] and bool(text)
  if expected_reject:result['expected_rejection']=result.get('http_status')==400 and 'context_length_exceeded' in result.get('http_error_body','')
  try:result['status_after']=status()
  except Exception as e:result['status_error']=repr(e)
  dump(P/(label+'-result.json'),result);log({'id':label,'state':'finished','wall_seconds':result['wall_seconds'],'ttft':result.get('ttft_seconds'),'usage':usage,'retrieval':result.get('retrieval'),'errors':result['errors'],'rejected':result.get('expected_rejection')})
 return result
def recovery(label):
 STATE.update(stage=label,phase='recovery')
 payload={'model':MODEL,'messages':[{'role':'user','content':'Return exactly this text, without quotes or explanation: RECOVERY_OK_42'}],'max_tokens':64,'temperature':0,'enable_thinking':False,'reasoning_effort':'none','stream':True,'stream_options':{'include_usage':True}}
 r=infer(label,payload);text=(P/(label+'-output.txt')).read_text().strip();s=r.get('status_after',{})
 r['recovery_pass']=text=='RECOVERY_OK_42' and s.get('ready') is True and s.get('metal',{}).get('healthy') is True and s.get('maximum_context_tokens')==262144 and not r['errors'];dump(P/(label+'-result.json'),r)
 return r
def main():
 global PROC
 with socket.socket() as s:assert s.connect_ex(('127.0.0.1',8084))!=0,'Port in use; no process replaced'
 hardware={'captured_unix_seconds':time.time(),'os':command(['sw_vers']),'chip':command(['sysctl','-n','machdep.cpu.brand_string']),'memory':command(['sysctl','-n','hw.memsize']),'cpu_count':command(['sysctl','-n','hw.ncpu']),'architecture':command(['uname','-m']),'power':command(['pmset','-g','batt']),'thermal_before':command(['pmset','-g','therm']),'swap_before':command(['sysctl','vm.swapusage'])};dump(P/'hardware.json',hardware)
 prepared=(L/'splash/records/benchmarks/2026-10-21-perf06-replay/prepared-model-path.txt').read_text().strip()
 cmd=[str(L/'splash/source/.venv/bin/python'),'-P','-m','server.server',prepared,'--model',MODEL,'--binary',str(L/'splash/source/build/splash'),'--host','127.0.0.1','--port','8084','--default-reasoning-effort','none','--kv-format','int8','--state-format','fp32','--max-memory','96G','--max-context','256K','--max-cache-disk','0','--idle-release','off','--request-timeout','3600','--no-webui']
 env=dict(os.environ,TZ='America/Toronto',SPLASH_API_KEY=KEY,HF_HUB_OFFLINE='1',HF_HUB_CACHE=str(L/'models/splash/huggingface/hub'),PYTHONPATH=str(L/'splash/source'))
 serverlog=(P/'server.log').open('w');started=time.monotonic();PROC=subprocess.Popen(cmd,cwd=L,env=env,stdout=serverlog,stderr=subprocess.STDOUT,start_new_session=True);dump(P/'launch.json',{'command':cmd,'pid':PROC.pid,'started_unix_seconds':time.time()});sam=threading.Thread(target=sampler,daemon=True);sam.start()
 try:
  deadline=time.monotonic()+900
  while time.monotonic()<deadline:
   if PROC.poll() is not None:raise RuntimeError('Server exited at startup')
   try:
    s=status()
    if s.get('ready'):break
   except Exception:pass
   time.sleep(1)
  else:raise RuntimeError('Readiness deadline')
  assert s['maximum_context_tokens']==262144 and s['metal']['healthy'];assert s['identity']['cache']['rope_scaling'] is None
  dump(P/'startup.json',{'seconds':time.monotonic()-started,'status':s});log({'state':'ready','startup_seconds':time.monotonic()-started,'context':s['maximum_context_tokens']})
  packets={}
  STATE.update(stage='preflight',phase='cpu_token_validation')
  for tag in ['128k','192k','256k','batchA','batchB','overflow']:packets[tag]=preflight(tag)
  for tag in ['128k','192k','256k']:
   if ABORT.is_set():raise RuntimeError('Resource/deadline abort')
   STATE.update(stage=tag,phase='generation');infer(tag,*packets[tag]);recovery(tag+'-recovery')
  STATE.update(stage='256k-repeat',phase='generation');infer('256k-repeat',*packets['256k']);recovery('256k-repeat-recovery')
  STATE.update(stage='concurrent',phase='generation');dump(P/'concurrent-before.json',status());t=time.monotonic()
  barrier=threading.Barrier(2)
  def submit(tag):barrier.wait();return infer(tag,*packets[tag])
  with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:list(pool.map(submit,['batchA','batchB']))
  dump(P/'concurrent-after.json',{'wall_seconds':time.monotonic()-t,'status':status()});recovery('concurrent-recovery')
  STATE.update(stage='overflow',phase='rejection');infer('overflow',*packets['overflow'],expected_reject=True);recovery('overflow-recovery')
  dump(P/'final-status.json',status());dump(P/'run-complete.json',{'finished_unix_seconds':time.time(),'total_seconds_including_startup_and_preflight':time.monotonic()-started,'completed_sequence':True,'thermal_after':command(['pmset','-g','therm']),'swap_after':command(['sysctl','vm.swapusage'])})
 except Exception as e:dump(P/'run-error.json',{'error':repr(e),'unix_seconds':time.time()});log({'state':'error','error':repr(e)})
 finally:
  STOP.set();sam.join(timeout=8);kill_owned()
  try:PROC.wait(timeout=30)
  except subprocess.TimeoutExpired:os.killpg(PROC.pid,signal.SIGKILL);PROC.wait(timeout=5)
  serverlog.close();dump(P/'exit.json',{'pid':PROC.pid,'returncode':PROC.returncode,'finished_unix_seconds':time.time()})
if __name__=='__main__':main()
