"""Read-only, stdlib-only macOS benchmark telemetry for MLX-VLM and MLTF.

The common process columns describe the inference engine: the VLM server PID,
or MLTF's native ``splash`` child (not its Python HTTP frontend). CPU 100% is
one logical CPU. IOAccelerator counters are global. All memory is unified and
the driver, allocator, RSS, footprint and tree sums must never be added.
"""
from __future__ import annotations

import ctypes
import importlib.util
import os
from pathlib import Path
import re
import subprocess
import time
from typing import Any, Callable

_TELEMETRY_PATH = Path(__file__).with_name('telemetry.py')
_spec = importlib.util.spec_from_file_location('_comparison_macos_telemetry', _TELEMETRY_PATH)
_telemetry = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(_telemetry)


def _process(pid: int) -> dict[str, Any]:
    row: dict[str, Any] = {'pid': pid, 'process_cpu_percent': None, 'errors': {}}
    for key in ('process_cpu_seconds', 'process_user_cpu_seconds', 'process_system_cpu_seconds',
                'process_rss_bytes', 'process_physical_footprint_bytes', 'process_wired_bytes',
                'process_pageins', 'process_start_abstime'):
        row[key] = None
    try:
        if _telemetry._timebase_status or not _telemetry._timebase.denom:
            raise RuntimeError('mach_timebase_info unavailable')
        usage = _telemetry._RUsageInfoV0()
        ctypes.set_errno(0)
        if _telemetry._libproc.proc_pid_rusage(pid, 0, ctypes.byref(usage)):
            code = ctypes.get_errno()
            raise OSError(code, os.strerror(code))
        scale = _telemetry._timebase.numer / _telemetry._timebase.denom / 1e9
        row.update(process_cpu_seconds=(usage.user_time + usage.system_time) * scale,
                   process_user_cpu_seconds=usage.user_time * scale,
                   process_system_cpu_seconds=usage.system_time * scale,
                   process_rss_bytes=int(usage.resident_size),
                   process_physical_footprint_bytes=int(usage.phys_footprint),
                   process_wired_bytes=int(usage.wired_size), process_pageins=int(usage.pageins),
                   process_start_abstime=int(usage.proc_start_abstime))
    except Exception as exc:
        row['errors']['process'] = f'{type(exc).__name__}: {exc}'
    return row


def _inventory() -> dict[int, dict[str, Any]]:
    # No command-line arguments: avoid collecting unrelated private process data.
    output = subprocess.run(['/bin/ps', '-axo', 'pid=,ppid=,pgid=,comm='], check=True,
                            text=True, capture_output=True, timeout=3).stdout
    processes = {}
    for line in output.splitlines():
        fields = line.strip().split(None, 3)
        if len(fields) == 4 and all(part.isdigit() for part in fields[:3]):
            pid, ppid, pgid = map(int, fields[:3])
            processes[pid] = {'pid': pid, 'ppid': ppid, 'pgid': pgid, 'comm': fields[3]}
    return processes


def _descendants(root_pid: int, inventory: dict[int, dict[str, Any]]) -> set[int]:
    result = {root_pid} if root_pid in inventory else set()
    while True:
        added = {pid for pid, item in inventory.items() if item['ppid'] in result} - result
        if not added:
            return result
        result.update(added)


class ResourceCollector:
    """One instance per server. ``collect(stage=..., phase=...)`` returns JSON data.

    ``status_callback`` is a zero-argument, short-timeout GET /status callback,
    called at most once a second for MLTF. It must return the decoded dict.
    Errors and native cached/stale status are retained, without retry loops.
    Sampling and writing JSONL are the caller's responsibility.
    """
    def __init__(self, root_pid: int, backend: str, status_callback: Callable[[], dict] | None = None,
                 engine_name: str = 'splash') -> None:
        if backend not in ('mlx-vlm', 'mltf'):
            raise ValueError('backend must be mlx-vlm or mltf')
        self.root_pid = int(root_pid)
        self.backend = backend
        self.status_callback = status_callback
        self.engine_name = engine_name
        self._previous: dict[tuple[int, int], tuple[float, float]] = {}
        self._system_previous: tuple[int, int, int, int] | None = None
        self._status: dict | None = None
        self._status_error: str | None = None
        self._status_time: float | None = None
        self._status_poll: float | None = None

    def collect(self, stage: str | None = None, phase: str | None = None) -> dict[str, Any]:
        started = time.monotonic()
        errors: dict[str, str] = {}
        if (self.backend == 'mltf' and self.status_callback and
                (self._status_poll is None or started - self._status_poll >= 1)):
            self._status_poll = started
            try:
                status = self.status_callback()
                if not isinstance(status, dict):
                    raise TypeError('/status callback did not return a dict')
                self._status, self._status_time, self._status_error = status, time.monotonic(), None
            except Exception as exc:
                self._status_error = f'{type(exc).__name__}: {exc}'
        if self._status_error:
            errors['native_status'] = self._status_error

        try:
            inventory = _inventory()
        except Exception as exc:
            inventory = {}
            errors['process_inventory'] = f'{type(exc).__name__}: {exc}'
        pids = _descendants(self.root_pid, inventory)
        frontend_pid: int | None = self.root_pid if self.backend == 'mltf' else None
        engine_pid: int | None = self.root_pid if self.backend == 'mlx-vlm' else None
        if self.backend == 'mltf':
            instance_pid = (self._status or {}).get('instance', {}).get('pid')
            if isinstance(instance_pid, int):
                if instance_pid in pids:
                    frontend_pid = instance_pid
                else:
                    errors['status_pid'] = f'/status frontend {instance_pid} is outside root tree {self.root_pid}'
            candidates = [pid for pid in pids if Path(inventory[pid]['comm']).name == self.engine_name]
            if len(candidates) == 1:
                engine_pid = candidates[0]
            else:
                errors['engine_pid'] = f'Expected one native {self.engine_name} descendant; found {candidates}'

        # One IORegistry/system call per sample; remaining processes use libproc.
        out = _telemetry.collect(engine_pid if engine_pid is not None else self.root_pid)
        errors.update(out.pop('errors', {}))
        roster = []
        next_previous = {}
        now = out['monotonic_seconds']
        for pid in sorted(pids):
            proc = _process(pid)
            proc.update(inventory[pid])
            identity = (pid, proc['process_start_abstime'])
            cpu = proc['process_cpu_seconds']
            prior = self._previous.get(identity)
            if cpu is not None:
                next_previous[identity] = (now, cpu)
                if prior and now > prior[0] and cpu >= prior[1]:
                    proc['process_cpu_percent'] = 100 * (cpu - prior[1]) / (now - prior[0])
            roster.append(proc)
        self._previous = next_previous
        by_pid = {row['pid']: row for row in roster}
        primary = by_pid.get(engine_pid)
        process_keys = [key for key in out if key.startswith('process_')]
        for key in process_keys:
            out[key] = primary.get(key) if primary else None
        out['process_cpu_percent'] = primary.get('process_cpu_percent') if primary else None
        out['pid'] = engine_pid
        if primary and primary['errors']:
            errors['primary_process'] = str(primary['errors'])
        if not primary:
            errors['primary_process'] = 'Native engine process unresolved or exited; common process columns are null'

        system_keys = ('system_cpu_user_ticks', 'system_cpu_system_ticks', 'system_cpu_idle_ticks', 'system_cpu_nice_ticks')
        current = tuple(out.get(key) for key in system_keys)
        out['system_cpu_percent'] = None
        if all(value is not None for value in current):
            if self._system_previous:
                deltas = [(value - prior) % 2**32 for value, prior in zip(current, self._system_previous)]
                if sum(deltas):
                    out['system_cpu_percent'] = 100 * (sum(deltas) - deltas[2]) / sum(deltas)
            self._system_previous = current

        def total(key: str) -> float | int | None:
            values = [proc.get(key) for proc in roster]
            return sum(values) if values and all(value is not None for value in values) else None

        frontend = by_pid.get(frontend_pid, {})
        out.update(backend=self.backend, root_pid=self.root_pid, frontend_pid=frontend_pid,
                   engine_pid=engine_pid, stage=stage, phase=phase, processes=roster,
                   process_scope='native_engine' if self.backend == 'mltf' else 'vlm_server',
                   process_tree_cpu_percent=total('process_cpu_percent'),
                   process_tree_rss_sum_bytes=total('process_rss_bytes'),
                   process_tree_physical_footprint_sum_bytes=total('process_physical_footprint_bytes'),
                   frontend_cpu_percent=frontend.get('process_cpu_percent'),
                   frontend_rss_bytes=frontend.get('process_rss_bytes'),
                   frontend_physical_footprint_bytes=frontend.get('process_physical_footprint_bytes'),
                   memory_overlap_note='Unified memory; tree sums can double-count shared pages. Do not add process, allocator or global GPU counters.',
                   native_status=self._status if self.backend == 'mltf' else None,
                   native_status_local_age_seconds=(time.monotonic() - self._status_time) if self._status_time else None,
                   native_status_callback_failed=bool(self._status_error),
                   engine_allocated_bytes=None, engine_allocation_peak_bytes=None,
                   memory_pressure_level=None, memory_pressure_name=None, swap_used_bytes=None)
        if self.backend == 'mltf' and self._status is not None:
            memory = self._status.get('memory_actual', {})
            out['engine_allocated_bytes'] = memory.get('current_bytes')
            out['engine_allocation_peak_bytes'] = memory.get('peak_bytes')
            out['engine_allocation_source'] = 'MLTF memory_actual: max(tracked dense+sparse resident, cached Metal allocation); peak cumulative'
            out['native_status_stale'] = self._status.get('transport', {}).get('status_stale')
            out['native_status_age_ms'] = self._status.get('transport', {}).get('status_age_ms')
        try:
            values = subprocess.run(['/usr/sbin/sysctl', '-n', 'kern.memorystatus_vm_pressure_level', 'vm.swapusage'],
                                    capture_output=True, text=True, check=True, timeout=3).stdout.splitlines()
            level = int(values[0])
            out['memory_pressure_level'] = level
            out['memory_pressure_name'] = {1: 'normal', 2: 'warn', 4: 'critical'}.get(level, f'unknown({level})')
            match = re.search(r'used\s*=\s*([\d.]+)([KMGT])', values[1])
            if not match:
                raise ValueError('Unrecognized vm.swapusage used field')
            out['swap_used_bytes'] = float(match[1]) * 1024 ** ('KMGT'.index(match[2]) + 1)
        except Exception as exc:
            errors['pressure_swap'] = f'{type(exc).__name__}: {exc}'
        out['errors'] = errors
        out['sample_duration_seconds'] = time.monotonic() - started
        return out
