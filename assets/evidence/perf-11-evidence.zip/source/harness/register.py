from pathlib import Path
import json,subprocess
ROOT=Path(__file__).resolve().parents[1];P=ROOT/'.local';A=Path('$HOME/Code/llm-test-reports')
def main():
 s=json.loads((P/'summary.json').read_text());c={r['id']:r for r in s['cases']};r=c.get('256k',{});keys=(r.get('retrieval') or {}).get('passed',0);audit=json.loads((P/'audit.json').read_text());recover=sum(bool(x['passed']) for x in s['recoveries']);ov=c.get('overflow',{}).get('expected_rejection');n=len(s['recoveries'])
 en=f"Native 262144-token window; 258048-input/4096-output cold case mechanically completed={r.get('mechanical_pass')}, keys {keys}/5, output {r.get('output')}. Includes 128K/192K tiers, exact warm repeat, two shared-prefix concurrent clients, actual oversized-input rejection={ov}, recovery {recover}/{n}; audit {audit['passed']}/{audit['total']}."
 zh=f"原生262144窗口；258048输入/4096输出上限冷请求机械完成={r.get('mechanical_pass')}、检索{keys}/5、实际输出{r.get('output')}。包含128K/192K阶梯、原样热重复、两个共享前缀并发客户端、实际超限拒绝={ov}、恢复{recover}/{n}；核查{audit['passed']}/{audit['total']}。"
 caveat='One finite text-only sequence with reasoning off, retained RAM prefixes and uncontrolled background load/thermals. Concurrent HTTP admission does not imply independent cold-prefill throughput. No new MLTF comparison, long-duration leak test or general reasoning-quality ranking.'
 caveatcn='一次有限纯文本序列，关闭思考、保留RAM前缀，后台负载/温控未控制。并发HTTP接纳不等于独立冷prefill吞吐。未新增MLTF对照，也不证明长期无泄漏或通用推理质量。'
 args=['node','scripts/add-report.mjs','--id','PERF-11','--title','Splash affine8 native 256K context stress test','--title-cn','Splash affine8原生256K上下文压力测试','--date','2026-10-21','--model','Qwen3.8-27B MLX affine8 / INT8 KV','--engine','Splash','--scope','local','--category','Local engine performance and quality','--category-cn','本地引擎性能与质量','--file','reports/originals/2026-10-21-splash-affine8-256k-stress.md','--summary',en,'--summary-cn',zh,'--caveat',caveat,'--caveat-cn',caveatcn,'--hardware','MacBook Pro / Apple M5 Max / 18 CPU / 40 GPU / 128 GiB','--test-os','macOS 27.0.1 (26A434), arm64; test-time hardware.json','--test-os-cn','macOS 27.0.1（26A434），arm64；本轮hardware.json']
 subprocess.run(args,cwd=A,check=True)
if __name__=='__main__':main()
