from pathlib import Path
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parents[1];P=ROOT/'.local';A=Path('$HOME/Code/llm-test-reports/assets/figures')
def main():
 s=json.loads((P/'summary.json').read_text());cs=[r for r in s['cases'] if r.get('ttft_seconds') is not None]
 plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False})
 fig,ax=plt.subplots(figsize=(10,4.6),layout='constrained');x=list(range(len(cs)));tt=[r['ttft_seconds'] for r in cs];rest=[r['wall_seconds']-r['ttft_seconds'] for r in cs]
 ax.bar(x,tt,label='HTTP to first nonempty text',color='#275c7a');ax.bar(x,rest,bottom=tt,label='First text to SSE completion',color='#deaa54');ax.set_xticks(x,[r['id'] for r in cs]);ax.set_ylabel('Seconds');ax.set_title('PERF-11 · Splash affine8 · native 256K server');ax.legend();ax.grid(axis='y',alpha=.15)
 for i,r in enumerate(cs):ax.text(i,r['wall_seconds'],f"{r['wall_seconds']:.1f}s",ha='center',va='bottom',fontsize=9)
 fig.savefig(A/'perf-11-latency.png',dpi=170);plt.close(fig)
 rows=[json.loads(l) for l in (P/'resources.jsonl').open()];start=rows[0]['monotonic_seconds'];xs=[(r['monotonic_seconds']-start)/60 for r in rows]
 fig,ax=plt.subplots(figsize=(11,4.8),layout='constrained')
 for key,label,color in [('process_physical_footprint_bytes','Native physical footprint','#275c7a'),('engine_allocated_bytes','Native current allocation','#deaa54'),('swap_used_bytes','Global swap (includes pre-existing use)','#9c4764')]:ax.plot(xs,[r[key]/2**30 if r.get(key) is not None else float('nan') for r in rows],label=label,color=color,linewidth=1.6)
 previous=None
 for x,r in zip(xs,rows):
  if r['stage']!=previous:
   if r['phase'] not in ['recovery','startup','cpu_token_validation']:ax.axvline(x,color='gray',alpha=.25);ax.text(x,.98,r['stage'],rotation=90,va='top',fontsize=8,transform=ax.get_xaxis_transform())
   previous=r['stage']
 ax.set_title('PERF-11 · unified-memory counters overlap; do not sum');ax.set_xlabel('Minutes since server launch');ax.set_ylabel('GiB');ax.legend(loc='lower right');ax.grid(alpha=.15);fig.savefig(A/'perf-11-memory.png',dpi=170);plt.close(fig)
if __name__=='__main__':main()
