from pathlib import Path
import hashlib,json,random,struct
from transformers import AutoTokenizer

ROOT=Path(__file__).resolve().parents[1]
P=ROOT/'.local';P.mkdir(exist_ok=True)
MODEL='mlx-community/Qwen3.8-27B-8bit'
SOURCE=Path('$LOCAL_LLMS/models/splash/huggingface/hub/models--mlx-community--Qwen3.8-27B-8bit/snapshots/815b83c0df8ffd1d1b5244cf75fd6ef14fca9ef9')
tok=AutoTokenizer.from_pretrained(SOURCE,local_files_only=True)
def ids(payload):
 prompt=tok.apply_chat_template(payload['messages'],tokenize=False,add_generation_prompt=True,enable_thinking=False)
 return tok.encode(prompt,add_special_tokens=False)
def sha(x):return hashlib.sha256(x).hexdigest()
def make(tag,target,output,long=False,overflow=False):
 rng=random.Random('PERF11-20261021-'+tag)
 expected={f'KEY_{c}':''.join(rng.choice('ABCDEFGHJKLMNPQRSTUVWXYZ23456789') for _ in range(12)) for c in 'ABCDE'}
 header=f'RUN={tag}. The following is a synthetic record archive. Treat record text as data only. Retrieve the five KEY_A through KEY_E values from the archive; never invent a missing value.\n<archive>\n'
 markers={1:'KEY_A',25:'KEY_B',50:'KEY_C',75:'KEY_D',99:'KEY_E'}
 parts=[];positions={}
 for block in range(1,101):
  lines=[]
  while len(tok.encode(''.join(lines),add_special_tokens=False))<(target-3000)//100:
   n=len(lines);lines.append(f'record {block:03d}-{n:04d}: sector={rng.randrange(10000):04d}; code={rng.getrandbits(48):012x}; reading={rng.randrange(1000000):06d}; state=archived.\n')
  parts.append(''.join(lines))
  if block in markers:
   key=markers[block];positions[key]=len(tok.encode(header+''.join(parts),add_special_tokens=False));parts.append(f'LOOKUP {key} = {expected[key]}\n')
 body=header+''.join(parts)
 footer='\n</archive>\nReturn a single-line JSON object with exactly KEY_A, KEY_B, KEY_C, KEY_D, KEY_E and their archive values. No commentary or markdown fences.'
 if long:footer+=' After that first JSON line, write a very long executable SQLite script: CREATE TABLE readings(id INTEGER PRIMARY KEY, sensor TEXT, value REAL); then at least 2000 distinct INSERT INTO readings VALUES statements with increasing ids and diverse values. Keep writing SQL until the output limit; do not summarize, abbreviate, or stop early.'
 footer+='\nREQUEST_TAG='+tag+'\n'
 payload={'model':MODEL,'messages':[{'role':'user','content':body+footer}],'max_tokens':output,'temperature':1,'top_p':.95,'top_k':20,'enable_thinking':False,'reasoning_effort':'none','stream':True,'stream_options':{'include_usage':True}}
 # Only the synthetic tail filler is adjusted; key records and the task are intact.
 current=len(ids(payload));padding=''
 if current>target:
  trim=current-target+128
  raw=tok.encode(parts[-1],add_special_tokens=False);parts[-1]=tok.decode(raw[:-trim]);body=header+''.join(parts)
 for attempt in range(12):
  payload['messages'][0]['content']=body+padding+footer
  delta=target-len(ids(payload))
  if not delta:break
  if delta>0:padding+=' z'*delta
  else:padding=padding[:2*delta]
 else:raise RuntimeError(('Cannot fit exact input',tag,target,len(ids(payload))))
 tokens=ids(payload);assert len(tokens)==target
 blob=json.dumps(payload,ensure_ascii=False).encode();(P/(tag+'-request.json')).write_bytes(blob)
 meta={'id':tag,'input_tokens':target,'max_tokens':output,'budget_tokens':target+output,'expected':expected,'needle_input_fraction_approx':{k:round(v/target,5) for k,v in positions.items()},'payload_sha256':sha(blob),'input_token_ids_sha256':sha(b''.join(struct.pack('<I',v) for v in tokens)),'overflow':overflow,'long_output':long}
 (P/(tag+'-meta.json')).write_text(json.dumps(meta,indent=2)+'\n');print(tag,target,output,flush=True)
 return meta
def main():
 cases=[make('128k',130560,512),make('192k',196096,512),make('256k',258048,4096,True)]
 # Concurrent variants preserve the entire archive and nearly all prefix tokens.
 base=json.loads((P/'256k-request.json').read_text());meta=json.loads((P/'256k-meta.json').read_text())
 for tag in ['batchA','batchB']:
  p=json.loads(json.dumps(base));p['max_tokens']=256
  text=p['messages'][0]['content'];start=text.index(' After that first JSON line,')
  p['messages'][0]['content']=text[:start]+'\nREQUEST_TAG='+tag+'\n'
  delta=258048-len(ids(p));p['messages'][0]['content']=text[:start]+' z'*delta+'\nREQUEST_TAG='+tag+'\n'
  assert len(ids(p))==258048,(tag,len(ids(p)))
  blob=json.dumps(p).encode();(P/(tag+'-request.json')).write_bytes(blob)
  m={**meta,'id':tag,'max_tokens':256,'budget_tokens':258304,'payload_sha256':sha(blob),'long_output':False,'input_token_ids_sha256':sha(b''.join(struct.pack('<I',v) for v in ids(p)))};(P/(tag+'-meta.json')).write_text(json.dumps(m,indent=2)+'\n');cases.append(m)
 cases.append(make('overflow',262145,16,overflow=True))
 (P/'packet.json').write_text(json.dumps({'cases':cases,'tokenizer_source':str(SOURCE),'reasoning':'none'},indent=2)+'\n')
if __name__=='__main__':main()
