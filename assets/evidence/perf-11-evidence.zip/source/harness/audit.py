from pathlib import Path
import hashlib,json,subprocess
ROOT=Path(__file__).resolve().parents[1];P=ROOT/'.local'
def main():
 s=json.loads((P/'summary.json').read_text());checks=[]
 def check(name,passed,detail=None):checks.append({'check':name,'passed':bool(passed),'detail':detail})
 frozen=json.loads((ROOT/'harness/packet-manifest.json').read_text());current=json.loads((P/'packet.json').read_text());check('Frozen packet manifest unchanged',frozen==current)
 for name in ['prepare.py','run.py']:
  old=subprocess.check_output(['git','-C',str(ROOT),'show','e64ddb6:harness/'+name]);check('Generation source unchanged: '+name,old==(ROOT/'harness'/name).read_bytes())
 for v in s['validation']:
  check(v['id']+' frozen payload SHA256',v['packet_hash_unchanged']);check(v['id']+' server token count and ID hash',v['server_preflight_pass'])
 cases={c['id']:c for c in s['cases']}
 for tag in ['128k','192k','256k','256k-repeat','batchA','batchB']:
  r=cases.get(tag,{});check(tag+' completed SSE/count/window',r.get('mechanical_pass'));check(tag+' 5/5 keys',(r.get('retrieval') or {}).get('exact_object'));check(tag+' ready/Metal after',r.get('healthy_after'));check(tag+' no transport restart',r.get('transport_restart_delta')==0)
 for tag in ['256k','256k-repeat']:
  r=cases.get(tag,{});check(tag+' at least2048 output',r.get('long_decode_2048'));check(tag+' full4096 output',r.get('full_output_budget'))
 for tag in ['128k','192k','256k']:check(tag+' confirmed cold prefix',(cases.get(tag,{}).get('cache') or {}).get('matched_tokens')==0)
 orig=json.loads((P/'256k-submitted.json').read_text()) if (P/'256k-submitted.json').exists() else None;repeat=json.loads((P/'256k-repeat-submitted.json').read_text()) if (P/'256k-repeat-submitted.json').exists() else None;check('256k repeat identical payload',orig is not None and orig==repeat)
 check('Actual oversized input rejected as HTTP400 context_length_exceeded',cases.get('overflow',{}).get('expected_rejection'))
 check('Six recovery probes recorded',len(s['recoveries'])==6)
 for r in s['recoveries']:check(r['id']+' exact-answer/health',r['passed'])
 check('No resource abort',s['resource_abort'] is None);check('Sequence complete',s['complete'] and s['complete'].get('completed_sequence'));check('No harness run error',s['run_error'] is None)
 check('No missing/error telemetry',not s['resources']['error_counts'],s['resources']['error_counts'])
 final=s['final_status'] or {};check('Final effective256K',final.get('maximum_context_tokens')==262144);check('No YaRN extension',(s['startup_status'] or {}).get('identity',{}).get('cache',{}).get('rope_scaling') is None)
 check('Final Metal healthy',final.get('metal',{}).get('healthy'));check('Final capacity/Metal failures0',final.get('metrics',{}).get('capacity_failures')==0 and final.get('metrics',{}).get('metal_failures')==0)
 out={'passed':sum(c['passed'] for c in checks),'total':len(checks),'checks':checks,'failed':[c for c in checks if not c['passed']]};(P/'audit.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
if __name__=='__main__':main()
