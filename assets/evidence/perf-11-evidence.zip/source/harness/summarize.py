from pathlib import Path
from collections import Counter
import hashlib,json,statistics
ROOT=Path(__file__).resolve().parents[1];P=ROOT/'.local'
def load(p):return json.loads(p.read_text()) if p.exists() else None
def stats(values):
 v=[x for x in values if isinstance(x,(int,float))]
 return {'samples':len(v),'min':min(v) if v else None,'max':max(v) if v else None,'mean':statistics.mean(v) if v else None}
def main():
 cases=[]
 for label in ['128k','192k','256k','256k-repeat','batchA','batchB','overflow']:
  r=load(P/(label+'-result.json'))
  if not r:continue
  before=r.get('status_before',{});after=r.get('status_after',{});metrics=r.get('metrics',{})
  cases.append({'id':label,'http_status':r.get('http_status'),'input':r.get('usage',{}).get('prompt_tokens'),'output':r.get('usage',{}).get('completion_tokens'),'wall_seconds':r.get('wall_seconds'),'ttft_seconds':r.get('ttft_seconds'),'content_tok_s':r.get('content_tok_s'),'cache':metrics.get('cache'),'timings':r.get('timings'),'retrieval':r.get('retrieval'),'mechanical_pass':r.get('mechanical_pass'),'long_decode_2048':r.get('long_decode_2048'),'full_output_budget':r.get('full_output_budget'),'expected_rejection':r.get('expected_rejection'),'errors':r.get('errors'),'healthy_after':after.get('ready') is True and after.get('metal',{}).get('healthy') is True,'transport_restart_delta':after.get('transport',{}).get('restarts',0)-before.get('transport',{}).get('restarts',0),'speculation':metrics.get('speculation')})
 rows=[]
 if (P/'resources.jsonl').exists():
  for line in (P/'resources.jsonl').open():
   try:rows.append(json.loads(line))
   except json.JSONDecodeError:pass
 stages={}
 for tag in dict.fromkeys(r.get('stage') for r in rows):
  subset=[r for r in rows if r.get('stage')==tag];stages[tag]={'samples':len(subset),'footprint_bytes':stats([r.get('process_physical_footprint_bytes') for r in subset]),'native_current_bytes':stats([r.get('engine_allocated_bytes') for r in subset]),'native_peak_bytes':stats([r.get('engine_allocation_peak_bytes') for r in subset]),'system_cpu_percent':stats([r.get('system_cpu_percent') for r in subset]),'engine_cpu_percent':stats([r.get('process_cpu_percent') for r in subset]),'gpu_busy_percent':stats([r.get('gpu_device_utilization_percent') for r in subset]),'pressure_counts':dict(Counter(r.get('memory_pressure_name') for r in subset)),'thermal_counts':dict(Counter((r.get('native_status') or {}).get('thermal_state') for r in subset))}
 errors=Counter(k for r in rows for k in r.get('errors',{}));swaps=[r['swap_used_bytes'] for r in rows if r.get('swap_used_bytes') is not None]
 recoveries=[]
 for p in sorted(P.glob('*-recovery-result.json')):
  r=load(p);recoveries.append({'id':r['id'],'passed':r.get('recovery_pass'),'wall_seconds':r.get('wall_seconds'),'errors':r.get('errors')})
 start=load(P/'startup.json');final=load(P/'final-status.json');packet=load(P/'packet.json')
 validations=[]
 for m in packet['cases']:
  tag=m['id'];raw=(P/(tag+'-request.json')).read_bytes();pre=load(P/(tag+'-preflight.json'))
  validations.append({'id':tag,'packet_hash_unchanged':hashlib.sha256(raw).hexdigest()==m['payload_sha256'],'server_preflight_pass':pre and pre['matches_frozen_tokens'],'requested_input_tokens':m['input_tokens'],'max_tokens':m['max_tokens'],'input_token_ids_sha256':m['input_token_ids_sha256'],'needle_input_fraction_approx':m['needle_input_fraction_approx']})
 batch_rows=[r.get('native_status') or {} for r in rows if r.get('stage')=='concurrent']
 batch_widths=[s.get('metrics',{}).get('current_decode_batch',{}).get('width',0) for s in batch_rows]
 prefill_widths=[s.get('metrics',{}).get('current_prefill_batch',{}).get('width',0) for s in batch_rows]
 summary={'cases':cases,'recoveries':recoveries,'validation':validations,'startup_seconds':start.get('seconds') if start else None,'resources':{'samples':len(rows),'stage_stats':stages,'error_counts':dict(errors),'swap_initial_bytes':swaps[0] if swaps else None,'swap_final_bytes':swaps[-1] if swaps else None,'swap_peak_bytes':max(swaps) if swaps else None,'swap_peak_growth_bytes':max(swaps)-swaps[0] if swaps else None,'native_decode_batch_width_observed_max':max(batch_widths,default=0),'native_prefill_batch_width_observed_max':max(prefill_widths,default=0),'memory_pressure':dict(Counter(r.get('memory_pressure_name') for r in rows))},'complete':load(P/'run-complete.json'),'run_error':load(P/'run-error.json'),'resource_abort':load(P/'resource-abort.json'),'startup_status':start.get('status') if start else None,'final_status':final,'concurrent':load(P/'concurrent-after.json'),'exit':load(P/'exit.json')}
 (P/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
 print(json.dumps({k:summary[k] for k in ['cases','recoveries','run_error','resource_abort']},indent=2))
if __name__=='__main__':main()
