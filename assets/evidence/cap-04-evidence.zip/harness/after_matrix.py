"""Automatically collect independent browser evidence after all nine sources are frozen."""
from pathlib import Path
import json,os,subprocess,sys,threading,time,traceback
from macos_telemetry import collect
from runner import api,stamp,dump
E=Path(__file__).resolve().parents[1];halt=threading.Event()
def monitor():
 with (E/'scoring/evaluation-system.jsonl').open('w') as f:
  while not halt.is_set():
   t=time.monotonic();r=collect(os.getpid());r['at']=stamp();r['stage']='independent-browser-evaluation';r['native_status']={}
   for name in ['mltf','splash','strata']:
    try:r['native_status'][name]=api(name,'/v1/status' if name=='strata' else '/status')
    except Exception as exc:r['native_status'][name]={'unavailable':repr(exc),'expected_stopped':name!='strata'}
   f.write(json.dumps(r)+'\n');f.flush();halt.wait(max(.05,1-(time.monotonic()-t)))
def main():
 print('Waiting for all nine immutable snapshots before independent evaluation',flush=True)
 while not (E/'raw/matrix-complete.json').exists():time.sleep(2)
 state=json.loads((E/'raw/matrix-complete.json').read_text());assert state['all_nine_frozen'],state.get('fatal')
 (E/'scoring').mkdir(exist_ok=True);sampler=threading.Thread(target=monitor,daemon=True);sampler.start();results=[]
 try:
  for name,cmd in [('analyze',[sys.executable,'harness/analyze.py']),('prepare',[sys.executable,'harness/prepare_evaluation.py']),('chromium',['node','harness/browser-evaluate.cjs'])]:
   at=stamp();t=time.monotonic();print('START '+name,flush=True)
   with (E/'scoring'/(name+'-driver.log')).open('w') as f:r=subprocess.run(cmd,cwd=E,stdout=f,stderr=subprocess.STDOUT,timeout=1800)
   results.append({'step':name,'at':at,'wall_s':time.monotonic()-t,'exit':r.returncode});dump(E/'scoring/automatic-collection-steps.json',results);print(json.dumps(results[-1]),flush=True);r.check_returncode()
  dump(E/'scoring/automatic-collection-complete.json',{'at':stamp(),'steps':results,'status':'Raw evidence collected; visual/manual grading still required'})
 finally:halt.set();sampler.join(timeout=5)
if __name__=='__main__':main()
