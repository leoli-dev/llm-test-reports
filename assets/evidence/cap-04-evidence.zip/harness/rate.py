from pathlib import Path
import json,hashlib
E=Path(__file__).resolve().parents[1];S=E/'scoring';schema=json.loads((E/'configs/rubric-schema.json').read_text());out=[]
notes={
'pelican-mltf':('A cheerful, complete illustration with a clear long beak and pouch. The large foreground trees partly hide the rear bicycle and the facades remain repetitive. Exports preserve the drawing.','画面明快，长嘴与喉囊清楚，内容完整。前景树部分遮住后轮，沿街立面较重复；导出保留实际画面。'),
'pelican-splash':('Strong avenue perspective and a readable bird/bicycle silhouette. The head and beak obscure most of the central Arc de Triomphe; flat shapes and repeated windows limit craft.','大道透视清晰，鸟与单车轮廓可辨；头和嘴遮住中央凯旋门大部分结构。平面造型及重复窗格限制精细度。'),
'pelican-strata':('The off-centre rider leaves the landmark legible; beret and trailing scarf add a coherent Paris story. Angular limbs remain simple. Portrait mode wastes much of the screen with black letterboxing.','骑手靠左，地标保持清楚；贝雷帽与飘动围巾加强巴黎故事感。肢体仍较硬朗简单，竖屏上下黑边浪费大量空间。'),
'courtyard-mltf':('A readable enclosed compound with a well-fitted overview, lattice, timber details and water/bridge. Repeated bright ripple rings look artificial and fixed mobile panels obscure the scene. The agent timed out in its own test and supplied no README or visual notes.','围合院落完整，总览能容纳全院，窗棂、木构、池桥清楚。重复亮色水纹较生硬，手机固定面板遮挡场景。代理卡在自测超时，没有交付 README 或视觉记录。'),
'courtyard-splash':('All twenty checklist items are represented, with roof, pavilion, bridge, rockery and planting. Default framing crowds the foreground and crops the compound; deep eaves are very dark and large roof planes dominate both desktop and portrait views.','二十项元素均有呈现，包括屋顶、亭、桥、假山与种植。默认构图前景拥挤且裁切院落，檐下过暗，大片屋顶主导桌面及手机视图。'),
'courtyard-strata':('The clearest spatial organisation: entry garden and screen wall lead through a moon gate to the inner pond, bridge, pavilion and hall. Tiled roofs, joinery and lattice have the most detail. Labels and a long panel clutter the desktop, but can be hidden; mobile controls collapse.','空间组织最清楚：入口园景与影壁，经月洞门进入池、桥、亭、主厅内院。瓦顶、木构、窗棂细节最丰富。桌面标签及长面板偏拥挤，但可隐藏；手机控件可折叠。'),
'sun-mltf':('All major stages animate and controls work. Soft oversized particles and a bright band across the core weaken physical form; much of the frame is empty. The 4.6-billion-years-to-90-seconds wording ambiguously mixes the age of the Sun with the duration of formation.','主要阶段均有动画，控件可用。偏大的柔光粒子、核心亮带削弱立体形态，构图留黑较多。「46亿年压缩成90秒」含混地混合太阳年龄与形成过程时长。'),
'sun-splash':('A strong cinematic approach with a large protostar, warm disk and clear clearing-to-stable-star transition. The fusion stage is heavily overexposed. The footer incorrectly describes the real formation process as spanning about 4.6 billion years.','较有电影感：原恒星大，暖色盘明显，清除到稳定恒星的转场清楚。聚变阶段严重过曝；页脚将真实形成过程写成跨越约46亿年，表达有误。'),
'sun-strata':('The clearest educational sequence, including a core cutaway, readable chapter titles and a stage navigator. Fine particles, a textured star and restrained colour transitions are coherent. It remains a stylised illustration, not an astrophysical simulation.','科普顺序最清楚，有核心剖视、清晰章节标题与阶段导航。细粒子、恒星纹理及配色转变较统一；仍是风格化示意，并非天体物理模拟。')}
visual={'pelican-mltf':[3,3,4,3,4],'pelican-splash':[3,3,3,4,3],'pelican-strata':[4,3,4,4,4],'courtyard-mltf':[4,3,3,3,3],'courtyard-splash':[2,2,2,3,3],'courtyard-strata':[4,4,4,4,4],'sun-mltf':[3,2,3,3,3],'sun-splash':[4,3,4,4,4],'sun-strata':[4,4,4,4,5]}
exceptions={
('pelican-splash','content','C07'):(2,'The head/beak hides most of the Arc; part of its upper mass and avenue inscription remain visible.','鸟头与嘴遮住凯旋门大部分，仅上部及大道字样仍可见。'),
('pelican-strata','usability','U03'):(1,'Controls are usable, but the landscape canvas becomes a small strip between large black bars.','控件可用，但横向画布在竖屏成为上下大黑边之间的小条画面。'),
('courtyard-mltf','usability','U09'):(1,'Real touch orbit works, but two fixed panels obscure much of the upper mobile scene.','真实触摸事件环绕有效，但两个固定面板遮挡手机上方大量场景。'),
('courtyard-splash','usability','U01'):(1,'Entry renders, but the default camera crops the compound and foreground roof blocks the pond. Other views recover it.','入口可渲染，但默认视角裁切院落，前景屋顶遮住池水；切换视角后可观察。'),
('courtyard-splash','usability','U09'):(1,'Touch orbit works and controls are reachable; the portrait scene is tightly cropped and dominated by roofs.','触摸环绕有效，控件可达；竖屏裁切较紧，屋顶占据过多画面。'),
('sun-mltf','content','C10'):(2,'The stages and caveats are present, but 4.6 billion years to 90 seconds ambiguously confuses formation duration and age.','阶段与示意说明齐全，但46亿年压缩成90秒的表述混淆形成时长与年龄。'),
('sun-splash','content','C10'):(2,'The footer explicitly calls the real formation process about 4.6 billion years. That is the Sun\'s age, not its formation duration.','页脚明确将真实形成过程写成约46亿年；这是太阳年龄，不是其形成所需时长。'),
('sun-mltf','usability','U09'):(1,'Mobile controls and captions work, but the early cloud is strongly cropped horizontally.','手机控件与字幕有效，但早期云团横向裁切明显。'),
('sun-splash','usability','U09'):(1,'Mobile controls work, but the early cloud lies low and is cropped by the lower interface.','手机控件有效，但早期云团位于下方，并被底部界面裁切。')}
for topic in ['pelican','courtyard','sun']:
 for model in ['mltf','splash','strata']:
  id=topic+'-'+model;case={'id':id,'summary_en':notes[id][0],'summary_cn':notes[id][1],'findings':[],'evidence':[]}
  ev=[f'scoring/{id}/browser-v1/results.json',f'scoring/{id}/manual-v1/results.json',f'scoring/{id}/manual-v1/mobile-fresh.png']
  ev += [f'scoring/{id}/manual-v1/live-{n:02}.png' for n in [0,15,30,45,60,75,89]] if topic=='sun' else [f'scoring/{id}/browser-v1/desktop-initial.png']
  if topic=='courtyard':ev += [f'scoring/{id}/manual-v1/ui-{n}-no-labels.png' for n in ['overview','detail','side']]+[f'scoring/{id}/manual-keyboard/results.json']
  if topic=='pelican':ev += [f'scoring/{id}/manual-v1/opened-export-{n}.png' for n in ['png','svg']]
  for g,items in schema['topics'][topic].items():
   rows=[]
   for i,item in enumerate(items):
    score=item['max'];en=cn=''
    if g=='content':en='Visible in the independently captured scene/stages from appropriate views; source checked for interpretation.';cn='在独立截图的适当视角或阶段中可见，并用源码核对解释。'
    if g=='visual':score=visual[id][i];en=notes[id][0];cn=notes[id][1]
    if g=='usability':en='Verified with actual visible controls, downloaded output or desktop/mobile inspection; see independent records.';cn='经真实可见控件、导出文件或桌面/手机画面核验，见独立记录。'
    if g=='technical':en='Independent Chromium run: no fatal errors, local resources, stable resize and 60-second loop; actual Canvas2D/SVG or WebGL rendering.';cn='独立 Chromium 运行无致命错误，资源本地加载，缩放及60秒循环稳定，使用真实 Canvas2D/SVG 或 WebGL。'
    if g=='handoff':en='Frozen README and visual notes document launch, controls, coverage and limitations; local entry independently opened.';cn='冻结的 README 与视觉记录载有启动、操作、覆盖与限制，本机入口经独立打开。'
    if (id,g,item['id']) in exceptions:
     score,en,cn=exceptions[(id,g,item['id'])];case['findings'].append({'criterion':item['id'],'en':en,'cn':cn})
    if id=='courtyard-mltf' and g=='handoff':
     score=[0,.5,.5,0,1][i];en=['No README was delivered before the deadline.','Controls are explained in the visible page, but no handoff document.','The visible element list supplies partial coverage information, but no document.','No limitations document was delivered.','The frozen index.html opens through a local static server.'][i];cn=['到时仍没有 README。','页面有操作提示，但没有交接文档。','页面元素清单提供部分覆盖说明，但没有交接文档。','没有限制说明文档。','冻结的 index.html 可用本机静态服务器打开。'][i]
    rows.append({'id':item['id'],'max':item['max'],'score':score,'reason_en':en,'reason_cn':cn,'evidence':ev if g!='handoff' else ([f'artifacts/{id}/README.md',f'artifacts/{id}/VISUAL-NOTES.md'] if id!='courtyard-mltf' else ev)})
   case[g]=rows
  case['evidence']=ev;case['totals']={g:sum(x['score'] for x in case[g]) for g in schema['weights']};case['total']=sum(case['totals'].values());out.append(case)
result={'experiment':'CAP-04','reviewer':'Codex, identity-aware AI review, no human/blind panel','rubric_source':'PLAN.md frozen before runs; configs/rubric-schema.json bilingual transcription','conclusion_en':'Strata produces the strongest overall visual results in these three observed tasks. Pelican scores are close; courtyard and solar explanation show larger craft gaps. MLTF courtyard is an agent-delivery failure with a usable artifact, not an inference crash.','conclusion_cn':'本次三个题目中，Strata 的整体视觉作品最强。鹈鹕分差较小，庭院与太阳科普的制作差距较大。MLTF 庭院是代理交付失败，但作品可用，并非推理引擎崩溃。','cases':out}
(S/'review.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
for c in out:print(c['id'],c['totals'],c['total'])
