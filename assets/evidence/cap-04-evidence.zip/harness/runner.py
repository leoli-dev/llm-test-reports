"""Paired Pi RPC driver and recording proxy. Application source is never edited here."""
import copy,datetime,hashlib,http.server,json,os,pathlib,queue,signal,subprocess,sys,threading,time,urllib.request,urllib.error
import psutil
from resource_collector import ResourceCollector,_process
E=pathlib.Path(__file__).resolve().parents[1];ROOT=E.parent;L=pathlib.Path('/Users/benchmark/local_llms');PY='/Users/benchmark/local_llms/strata/runtime/terminal/0.1.51/python/bin/python3'
def dump(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def stamp():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def api(label,path):
 key=(L/label/'data/api-key').read_text().strip();headers={'Authorization':'Bearer '+key} if key else {}
 with urllib.request.urlopen(urllib.request.Request('http://127.0.0.1:'+str({'mltf':8083,'splash':8084,'strata':8085}[label])+path,headers=headers),timeout=3) as f:return json.load(f)
def backend_identity(label):
 if label in ['mltf','splash']:return json.loads((L/label/'data/service.json').read_text())['pid']
 matches=[p.pid for p in psutil.process_iter(['cmdline']) if 'serve.server' in (p.info['cmdline'] or []) and 'strata/runtime' in ' '.join(p.info['cmdline'] or [])]
 assert len(matches)==1,matches
 return matches[0]
class Run:
 def __init__(self,runid,mode='formal'):
  self.case=next(x for x in json.loads((E/'matrix.json').read_text()) if x['id']==runid);label=self.case['label'];self.runid=runid
  self.label=label;self.mode=mode;self.dest=E/'raw'/runid/mode;self.dest.mkdir(parents=True,exist_ok=False);self.stop=threading.Event();self.lock=threading.Lock();self.q=queue.Queue();self.seq=0;self.phase=0;self.tools=0;self.output=0;self.reason=None;self.pi=None;self.requests=[];self.stage='baseline';self.started=time.monotonic();self.identity=None
 def record(self,name,x):
  with self.lock:
   with (self.dest/name).open('a') as f:f.write(json.dumps({'at':stamp(),'unix_s':time.time(),**x},ensure_ascii=False)+'\n')
 def progress(self):dump(self.dest/'progress.json',{'runid':self.runid,'label':self.label,'mode':self.mode,'phase':self.phase,'stage':self.stage,'elapsed_s':time.monotonic()-self.started,'tool_starts':self.tools,'assistant_output_tokens':self.output,'reason':self.reason})
 def proxy(self):
  run=self;port={'mltf':8083,'splash':8084,'strata':8085}[self.label]
  class Handler(http.server.BaseHTTPRequestHandler):
   def log_message(self,*args):pass
   def do_GET(self):self.forward()
   def do_POST(self):self.forward()
   def forward(self):
    raw=self.rfile.read(int(self.headers.get('Content-Length','0')));start=time.monotonic()
    with run.lock:run.seq+=1;i=run.seq
    d=run.dest/'requests'/f'{i:04d}';d.mkdir(parents=True);meta={'id':i,'phase':run.phase,'started_at':stamp(),'started_unix_s':time.time(),'path':self.path,'first_content_s':None,'usage':None,'timings':None,'error':None}
    if raw:
     (d/'request.json').write_bytes(raw)
     try:
      payload=json.loads(raw);meta['model']=payload.get('model');meta['sampling']={k:payload.get(k) for k in ['temperature','top_p','top_k','reasoning_effort','max_tokens']};meta['message_count']=len(payload.get('messages',[]));meta['request_sha256']=hashlib.sha256(raw).hexdigest()
     except Exception:pass
    run.record('request-events.jsonl',{'event':'start','id':i,'phase':run.phase})
    headers={'Content-Type':'application/json'};key=(L/run.label/'data/api-key').read_text().strip()
    if key:headers['Authorization']='Bearer '+key
    try:
     req=urllib.request.Request(f'http://127.0.0.1:{port}'+self.path,data=raw or None,method=self.command,headers=headers)
     try:response=urllib.request.urlopen(req,timeout=1800)
     except urllib.error.HTTPError as e:response=e
     with response as upstream,(d/'response.bin').open('wb') as out,(d/'sse.jsonl').open('w') as parsed:
      meta['http_status']=upstream.code;self.send_response(upstream.code);self.send_header('Content-Type',upstream.headers.get('Content-Type','application/json'));self.send_header('Connection','close');self.end_headers()
      for line in upstream:
       out.write(line);out.flush()
       if line.startswith(b'data:'):
        val=line[5:].strip()
        if val and val!=b'[DONE]':
         try:
          event=json.loads(val);t=time.monotonic()-start;parsed.write(json.dumps({'seconds':t,'event':event},ensure_ascii=False)+'\n');parsed.flush()
          if event.get('usage'):meta['usage']=event['usage']
          if event.get('timings'):meta['timings']=event['timings']
          if event.get('error'):meta['error']=event['error']
          if meta['first_content_s'] is None and any(any((c.get('delta') or {}).get(k) for k in ['content','reasoning_content','tool_calls']) for c in event.get('choices',[])):meta['first_content_s']=t
         except Exception as exc:run.record('proxy-errors.jsonl',{'id':i,'error':repr(exc)})
       self.wfile.write(line);self.wfile.flush()
    except Exception as exc:
     meta['error']=repr(exc)
     try:self.send_error(502,'Local recording proxy error')
     except Exception:pass
    finally:
     meta['wall_s']=time.monotonic()-start;meta['finished_unix_s']=time.time();dump(d/'result.json',meta);run.requests.append(meta);run.record('request-events.jsonl',{'event':'end',**meta});self.close_connection=True
  self.http=http.server.ThreadingHTTPServer(('127.0.0.1',18086),Handler);self.http.daemon_threads=True;threading.Thread(target=self.http.serve_forever,daemon=True).start()
 def sampler(self):
  c=ResourceCollector(self.pid,'mltf',status_callback=lambda:api(self.label,self.status_path),engine_name='strata' if self.label=='strata' else 'splash');baseline=psutil.swap_memory().used;critical=0
  with (self.dest/'resources.jsonl').open('w') as f:
   while not self.stop.is_set():
    t=time.monotonic();row=c.collect(stage=self.stage,phase=str(self.phase));row['backend']=self.label;row['swap_delta_bytes']=(row.get('swap_used_bytes') or baseline)-baseline;row['pi_processes']=[]
    if self.pi:
     try:row['pi_processes']=[_process(p.pid) for p in [psutil.Process(self.pi.pid)]+psutil.Process(self.pi.pid).children(recursive=True)]
     except psutil.Error:pass
    row['pi_tree_rss_sum_bytes']=sum(x.get('process_rss_bytes') or 0 for x in row['pi_processes']);row['engine_allocation_source']='Splash memory_actual if exposed; unavailable for Strata, never zero-filled' if self.label=='strata' else row.get('engine_allocation_source');row['temperature_c']=None
    f.write(json.dumps(row)+'\n');f.flush();critical=critical+1 if row.get('memory_pressure_name')=='critical' else 0
    if critical>=15 or (row.get('process_physical_footprint_bytes') or 0)>115*2**30 or (row.get('process_tree_rss_sum_bytes') or 0)>115*2**30 or row['swap_delta_bytes']>8*2**30:self.reason='resource_abort';dump(self.dest/'resource-abort.json',row);self.q.put({'type':'guard_abort'});return
    self.stop.wait(max(.05,1-(time.monotonic()-t)))
 def reader(self):
  with (self.dest/'pi-events.jsonl').open('ab') as f:
   for line in self.pi.stdout:
    f.write(line);f.flush()
    try:
     v=json.loads(line);typ=v.get('type')
     if typ=='tool_execution_start':self.tools+=1
     if typ=='message_end' and v.get('message',{}).get('role')=='assistant':self.output+=v['message'].get('usage',{}).get('output',0)
     if typ in ['tool_execution_start','tool_execution_end','message_end','agent_start','agent_end','agent_settled','response','compaction_start','compaction_end','auto_retry_start','auto_retry_end']:
      self.record('timeline.jsonl',{'phase':self.phase,**v})
     self.q.put(v)
    except Exception as exc:self.record('reader-errors.jsonl',{'error':repr(exc)})
  self.q.put({'type':'process_eof'})
 def send(self,v):self.record('commands.jsonl',v);self.pi.stdin.write((json.dumps(v,ensure_ascii=False)+'\n').encode());self.pi.stdin.flush()
 def clean_apps(self,cwd,started_epoch):
  for p in psutil.process_iter(['cmdline','cwd','create_time']):
   try:
    cmd=p.info['cmdline'] or []
    if p.pid not in [os.getpid(),self.pid] and p.info['cwd']==str(cwd) and p.info['create_time']>=started_epoch:p.terminate();self.record('cleanup.jsonl',{'pid':p.pid,'reason':'candidate temporary app'})
   except psutil.Error:pass
 def execute(self):
  self.status_path='/v1/status' if self.label=='strata' else '/status';status=api(self.label,self.status_path);ctx=status.get('context',{}).get('native') if self.label=='strata' else status.get('maximum_context_tokens');assert ctx==262144,status
  self.pid=backend_identity(self.label);self.identity={'pid':self.pid,'created':psutil.Process(self.pid).create_time()};dump(self.dest/'backend-before.json',{'identity':self.identity,'status':status});self.proxy();sam=threading.Thread(target=self.sampler,daemon=True);sam.start();time.sleep(10)
  cwd=pathlib.Path(self.case['path']) if self.mode=='formal' else self.dest/'smoke-project';cwd.mkdir(exist_ok=True);env=os.environ.copy();env.update(PI_CODING_AGENT_DIR=str(E/'private'/('pi-'+self.label)),PI_OFFLINE='1',PI_TELEMETRY='0')
  model=self.case['model'];cmd=['/Users/benchmark/.local/bin/pi','--mode','rpc','--provider',self.label,'--model',model,'--thinking','medium','--no-mcp','--no-extensions','--no-skills','--no-prompt-templates','--no-context-files','--tools','read,bash,edit,write','--session-dir',str(self.dest/'sessions'),'--append-system-prompt','Work only within the current project directory. Never use pkill, killall or process-name based cleanup; terminate only your own recorded PIDs. Do not modify vendor/ or tools/; those are frozen identical benchmark resources. Do not read sibling projects, evaluator files, global private configuration or previous implementations. Do not use external network, another model, or delegation. Use Chromium if browser testing. You alone write the application source.']
  err=(self.dest/'pi-stderr.log').open('wb');epoch=time.time();self.started=time.monotonic();self.stage='development' if self.mode=='formal' else 'smoke';self.pi=subprocess.Popen(cmd,cwd=cwd,env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err,start_new_session=True);dump(self.dest/'launch.json',{'at':stamp(),'cmd':cmd,'cwd':str(cwd),'pi_pid':self.pi.pid});threading.Thread(target=self.reader,daemon=True).start();self.send({'id':'state-before','type':'get_state'});self.send({'id':'retry-off','type':'set_auto_retry','enabled':False});self.phase=1
  prompts=[(E/f'phase-{i}.txt').read_text() for i in range(1,4)] if self.mode=='formal' else ['Use write to create probe.txt containing exactly 391 (17*23), use bash to read it back, then answer only JSON {"ok":true,"product":391}. Do not create other code.']
  self.send({'id':'phase-1','type':'prompt','message':prompts[0]});phase_start=self.started;phases=[];finished=False;limit=3600 if self.mode=='formal' else 240
  try:
   while self.pi.poll() is None:
    self.progress()
    if time.monotonic()-self.started>limit:self.reason='wall_timeout';break
    try:v=self.q.get(timeout=1)
    except queue.Empty:continue
    typ=v.get('type')
    if typ=='guard_abort':break
    if typ=='process_eof':self.reason='unexpected_pi_exit';break
    if typ=='response' and v.get('success') is False:self.reason='rpc_command_error';break
    if typ=='agent_settled':
     phases.append({'phase':self.phase,'wall_s':time.monotonic()-phase_start,'event':v,'output_tokens_total':self.output,'tool_starts_total':self.tools});dump(self.dest/'phases.json',phases);self.record('lifecycle.jsonl',{'event':'phase_settled','phase':self.phase});print(json.dumps({'runid':self.runid,'label':self.label,'mode':self.mode,'phase':self.phase,'state':'settled','wall_s':phases[-1]['wall_s']}),flush=True)
     if self.phase==len(prompts):finished=True;self.reason='completed_phases';break
     self.phase+=1;phase_start=time.monotonic();self.send({'id':f'phase-{self.phase}','type':'prompt','message':prompts[self.phase-1]+'\nRemaining total wall budget: '+str(max(0,int(limit-(time.monotonic()-self.started))))+' seconds.'})
  finally:
   wall=time.monotonic()-self.started
   if not finished:
    try:self.send({'id':'abort','type':'abort'})
    except Exception:pass
   try:self.pi.stdin.close();self.pi.wait(timeout=8)
   except Exception:
    try:os.killpg(self.pi.pid,signal.SIGTERM);self.pi.wait(timeout=5)
    except Exception:
     try:os.killpg(self.pi.pid,signal.SIGKILL)
     except ProcessLookupError:pass
   self.clean_apps(cwd,epoch);self.stop.set();sam.join(timeout=6);self.http.shutdown();self.http.server_close();err.close()
   try:after=api(self.label,self.status_path);same=psutil.Process(self.pid).create_time()==self.identity['created']
   except Exception as exc:after={'error':repr(exc)};same=False
   dump(self.dest/'summary.json',{'runid':self.runid,'label':self.label,'mode':self.mode,'completed_phases':finished,'reason':self.reason,'wall_s':wall,'phase_count':len(phases),'tool_starts':self.tools,'assistant_output_tokens':self.output,'request_count':len(self.requests),'backend_identity_unchanged':same,'backend_after':after,'pi_returncode':self.pi.poll()});self.progress()
   if self.mode=='formal':
    subprocess.run(['git','add','-A'],cwd=cwd,check=True);subprocess.run(['git','-c','user.name=Benchmark Snapshot','-c','user.email=local@benchmark.invalid','commit','--allow-empty','-m','Freeze Pi-authored final artifact; supervisor snapshot only'],cwd=cwd,stdout=subprocess.DEVNULL,check=True)
    dump(self.dest/'source-snapshot.json',{'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=cwd,text=True).strip(),'status':subprocess.check_output(['git','status','--porcelain'],cwd=cwd,text=True),'source_files':subprocess.check_output(['git','ls-files'],cwd=cwd,text=True).splitlines()})
   if self.reason=='resource_abort':subprocess.run([str(L/self.label/'stop.sh')],capture_output=True)
def main():Run(sys.argv[1],sys.argv[2] if len(sys.argv)>2 else 'formal').execute()
if __name__=='__main__':main()
