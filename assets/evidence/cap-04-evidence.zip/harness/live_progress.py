from pathlib import Path
import json,time
E=Path(__file__).resolve().parents[1]
def load(p):
 for _ in range(3):
  try:return json.loads(p.read_text())
  except (ValueError,OSError):time.sleep(.02)
 return {}
s=load(E/'raw/matrix-progress.json');rid=s.get('runid');p=E/'raw'/str(rid)/'formal';d=load(p/'progress.json');health={}
f=p/'resources.jsonl'
if f.exists():
 with f.open('rb') as stream:
  stream.seek(max(0,f.stat().st_size-180000));lines=stream.read().splitlines()
 for line in reversed(lines):
  try:
   x=json.loads(line);health={'pressure':x.get('memory_pressure_name'),'gpu_busy_pct':x.get('gpu_device_utilization_percent'),'swap_delta_MiB':round(x.get('swap_delta_bytes',0)/2**20,2),'telemetry_errors':x.get('errors',{}),'native_failed':(x.get('native_status')or{}).get('requests',{}).get('failed')};break
  except ValueError:pass
complete=len(list((E/'raw').glob('*/formal/source-snapshot.json')));matrix=load(E/'raw/matrix-complete.json');collection=load(E/'scoring/automatic-collection-complete.json');steps=load(E/'scoring/automatic-collection-steps.json')
stop=bool(collection) or bool(matrix.get('fatal')) or bool(isinstance(steps,list) and steps and steps[-1].get('exit'))
print(json.dumps({'completed':complete,'total':9,'matrix_phase':s.get('phase'),'id':rid,'development_min':round(d.get('elapsed_s',0)/60,2),'phase':d.get('phase'),'tool_calls':d.get('tool_starts'),'output_tokens':d.get('assistant_output_tokens'),'reason':d.get('reason'),'health':health,'all_frozen':matrix.get('all_nine_frozen',False),'collection_complete':bool(collection),'stop_watch':stop},ensure_ascii=False))
