"""Standalone measurement charts from frozen observations and explicit assessor scores."""
from pathlib import Path
import hashlib,json,math,os
E=Path(__file__).resolve().parents[1];os.environ.setdefault('MPLCONFIGDIR',str(E/'private/matplotlib'))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
F=Path('/Users/benchmark/Code/llm-test-reports/assets/figures');colors={'mltf':'#2563eb','splash':'#0f766e','strata':'#9333ea'};names={'mltf':'MLTF','splash':'Splash','strata':'Strata'};topics={'pelican':'2D Pelican','courtyard':'3D Courtyard','sun':'3D Sun formation'};groups=['content','visual','usability','technical','handoff'];maxima=[40,25,20,10,5]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 data=json.loads((E/'scoring/run-analyses.json').read_text());assert len(data)==9,'Plot only the full nine-cell matrix'
 review=json.loads((E/'scoring/review.json').read_text());ratings={x['id']:x for x in review['cases']};assert len(ratings)==9
 byid={x['case']['id']:x for x in data};ordered=[byid[t+'-'+m] for t in topics for m in names];labels=[topics[x['case']['topic']]+' / '+names[x['case']['label']] for x in ordered];sources=[];F.mkdir(parents=True,exist_ok=True)
 plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'axes.titleweight':'bold','figure.facecolor':'white','axes.facecolor':'white','savefig.facecolor':'white','svg.fonttype':'none'})
 def save(fig,name,inputs):
  fig.savefig(F/(name+'.png'),dpi=180,bbox_inches='tight');fig.savefig(F/(name+'.svg'),bbox_inches='tight');plt.close(fig)
  sources.append({'figure':name,'inputs':{str(p.relative_to(E)):sha(p) for p in inputs},'outputs':{s:sha(F/(name+s)) for s in ['.png','.svg']},'method':'Matplotlib from actual records; no artwork pixels generated or redrawn'})
 #Elapsed time, with each topic receiving the same maximum budget.
 fig,axes=plt.subplots(1,3,figsize=(14,4.5),sharey=True,layout='constrained')
 for ax,(topic,title) in zip(axes,topics.items()):
  vals=[byid[topic+'-'+m]['run']['wall_s']/60 for m in names];bars=ax.bar(list(names.values()),vals,color=list(colors.values()),width=.62);ax.set_title(title);ax.set_ylim(0,65);ax.axhline(60,color='#9ca3af',ls='--',lw=1);ax.grid(axis='y',alpha=.17);ax.set_axisbelow(True)
  for bar,value in zip(bars,vals):ax.text(bar.get_x()+bar.get_width()/2,value+.8,f'{value:.2f}',ha='center',fontsize=11)
 axes[0].set_ylabel('Development wall time (minutes)');fig.suptitle('Actual development time — one run per cell, maximum 60 minutes',fontsize=14,fontweight='bold');save(fig,'cap-04-development-time',[E/'scoring/run-analyses.json'])
 #Scores are judgments; components are shown instead of hiding gaps in one total.
 fig,ax=plt.subplots(figsize=(14,7.2),layout='constrained');y=np.arange(9);left=np.zeros(9);scorecolors=['#64748b','#a78bfa','#2dd4bf','#93c5fd','#fbbf24']
 totals=np.zeros(9)
 for group,cap,color in zip(groups,maxima,scorecolors):
  scores=[]
  for item in ordered:
   section=ratings[item['case']['id']][group];assert sum(x['max'] for x in section)==cap;assert all(0<=x['score']<=x['max'] for x in section);scores.append(sum(x['score'] for x in section))
  vals=np.array(scores);ax.barh(y,vals,left=left,label=group.capitalize()+f' / {cap}',color=color,height=.65);left+=vals
 totals=left
 for i,total in enumerate(totals):ax.text(total+.6,i,f'{total:g}',va='center',fontsize=11,fontweight='bold')
 ax.set_yticks(y,labels);ax.invert_yaxis();ax.set_xlim(0,105);ax.set_xlabel('Fixed rubric points / 100\nIdentity-aware review; one project per model/topic. Not a general model ranking.',labelpad=10);ax.set_title('Assessor ratings — content, craft, interaction, runtime and handoff');ax.legend(ncol=3,loc='lower left',bbox_to_anchor=(0,1.02),frameon=False);ax.grid(axis='x',alpha=.15);ax.set_axisbelow(True);save(fig,'cap-04-rubric-scores',[E/'scoring/review.json',E/'scoring/run-analyses.json'])
 #Independent overlapping memory counters, never stacked or summed.
 fig,ax=plt.subplots(figsize=(14,7.2),layout='constrained');y=np.arange(9)
 for key,label,color,marker in [('process_rss_bytes','Native RSS peak','#64748b','o'),('process_physical_footprint_bytes','Native footprint peak','#2563eb','s'),('gpu_in_use_system_memory_bytes','Global GPU in-use peak (all apps)','#ea580c','D')]:
  vals=[(x['resource']['metrics'][key]['max']/2**30 if x['resource']['metrics'][key]['max'] is not None else np.nan) for x in ordered];ax.scatter(vals,y,s=55,label=label,color=color,marker=marker)
 ax.set_yticks(y,labels);ax.invert_yaxis();ax.set_xlabel('GiB — overlapping counters; do not add');ax.set_xlim(left=0);ax.set_title('Memory observations during each measured development interval');ax.legend(ncol=3,loc='lower left',bbox_to_anchor=(0,1.02),frameon=False);ax.grid(axis='x',alpha=.15);ax.set_axisbelow(True);save(fig,'cap-04-memory-counters',[E/'scoring/run-analyses.json'])
 #All recorded development samples, no aesthetic inference from the curves.
 fig,axes=plt.subplots(3,3,figsize=(15,10.5),sharex=True,sharey=True,layout='constrained');memorymax=max((x['resource']['metrics'][k]['max']/2**30 for x in ordered for k in ['process_rss_bytes','process_physical_footprint_bytes'] if x['resource']['metrics'][k]['max'] is not None),default=0);ymax=math.ceil((memorymax+5)/10)*10
 used=[]
 for row,(topic,title) in enumerate(topics.items()):
  for col,model in enumerate(names):
   item=byid[topic+'-'+model];p=E/'raw'/item['case']['id']/'formal/resources.jsonl';used.append(p);start=item['resource']['development_start_unix'];end=item['resource']['development_end_unix'];samples=[]
   for line in p.read_text().splitlines():
    x=json.loads(line)
    if x.get('stage')=='development' and start<=x['unix_seconds']<=end:samples.append(x)
   ax=axes[row,col];t=[(x['unix_seconds']-start)/60 for x in samples]
   for key,color,label in [('process_rss_bytes','#94a3b8','Native RSS'),('process_physical_footprint_bytes','#2563eb','Native footprint')]:ax.plot(t,[(x[key]/2**30 if x.get(key) is not None else np.nan) for x in samples],color=color,lw=1,label=label)
   right=ax.twinx();right.plot(t,[x.get('gpu_device_utilization_percent',float('nan')) for x in samples],color='#ea580c',alpha=.65,lw=.7,label='Global GPU busy');right.set_ylim(0,105)
   if col<2:right.set_yticklabels([])
   else:right.set_ylabel('Global GPU busy (%)',color='#9a3412')
   ax.set_title(f'{title} · {names[model]}\n{item["run"]["wall_s"]/60:.2f} min',fontsize=10);ax.set_xlim(0,60);ax.set_ylim(0,ymax);ax.grid(alpha=.15)
   if col==0:ax.set_ylabel('Native memory (GiB)')
   if row==2:ax.set_xlabel('Development minute')
 handles=[plt.Line2D([0],[0],color='#94a3b8',lw=2),plt.Line2D([0],[0],color='#2563eb',lw=2),plt.Line2D([0],[0],color='#ea580c',lw=2)];axes[0,0].legend(handles,['Native RSS','Native footprint','Global GPU busy (all apps)'],loc='upper right',fontsize=8,frameon=False);fig.suptitle('Recorded development pressure — nominal 1 Hz; actual timestamps, no resampling',fontsize=14,fontweight='bold');save(fig,'cap-04-pressure-timelines',[*used,E/'scoring/run-analyses.json'])
 (E/'scoring/figure-provenance.json').write_text(json.dumps({'tool':'Matplotlib '+matplotlib.__version__,'figures':sources},ensure_ascii=False,indent=2)+'\n');print('Wrote four standalone charts, PNG and SVG, with source hashes')
if __name__=='__main__':main()
