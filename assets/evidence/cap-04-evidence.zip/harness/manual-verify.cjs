// Independent real-control checks. Every flow opens a fresh page; immutable source is never edited.
const fs=require('fs'),path=require('path'),http=require('http'),crypto=require('crypto');
const {chromium}=require('/Users/benchmark/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const E=path.resolve(__dirname,'..'),sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const configs={
 'pelican-mltf':{play:'#playBtn',reset:'#resetBtn',png:'#pngBtn',svg:'#svgBtn'},
 'pelican-splash':{play:'#btnPlay',reset:'#btnReset',png:'#btnPNG',svg:'#btnSVG'},
 'pelican-strata':{play:'#btnPlay',reset:'#btnReset',png:'#btnPng',svg:'#btnSvg'},
 'courtyard-splash':{play:'#bPlay',reset:'#bReset',labels:'#bLabel',views:['#bOver','#bDetail','#bSide']},
 'courtyard-strata':{play:'#play',reset:'#reset',labels:'#labelsBtn',views:['总览','细节','侧面'],panel:'#panelBtn'},
 'courtyard-mltf':{play:'#pauseBtn',reset:'#resetView',labels:'#labelsChk',views:['全景','近景','侧面']},
 'sun-strata':{play:'#playBtn',reset:'#replayBtn',timeline:'#tl',speed:'#speed',auto:'#autoCam',speedKind:'select'},
 'sun-mltf':{play:'#playBtn',reset:'#resetBtn',timeline:'#timeline',speed:'#speedSel',auto:'#autoCamBtn',speedKind:'select'},
 'sun-splash':{play:'#btnPlay',reset:'#btnReplay',timeline:'#tl',speed:'2×',auto:'#btnAuto',speedKind:'button'}
};
const time=s=>s?.time??s?.t??null;
async function serve(root,output){
 const server=http.createServer((req,res)=>{try{const name=decodeURIComponent(new URL(req.url,'http://local').pathname);let base=root,rel=name;if(name.startsWith('/_exports/')){base=output;rel=name.slice('/_exports'.length);}let p=path.resolve(base,'.'+rel);if(fs.existsSync(p)&&fs.statSync(p).isDirectory())p=path.join(p,'index.html');if(!p.startsWith(base+path.sep)||!fs.existsSync(p)||!fs.realpathSync(p).startsWith(fs.realpathSync(base)+path.sep)){res.writeHead(404);res.end('not found');return;}res.setHeader('Content-Type',({'.html':'text/html','.js':'text/javascript','.css':'text/css','.json':'application/json','.svg':'image/svg+xml','.png':'image/png'})[path.extname(p)]||'application/octet-stream');res.end(fs.readFileSync(p));}catch(e){res.writeHead(500);res.end('static observer error');}});
 await new Promise(r=>server.listen(0,'127.0.0.1',r));return{server,url:'http://127.0.0.1:'+server.address().port+'/'};
}
async function verify(browser,c){
 const cfg=configs[c.id],dest=path.join(E,'scoring',c.id,'manual-v1');fs.mkdirSync(dest,{recursive:true});const {server,url}=await serve(path.join(E,'scoring',c.id,'frozen'),dest);const result={id:c.id,started:new Date().toISOString(),checks:[],errors:[],downloads:[],liveFrames:[]};
 const add=(name,pass,detail)=>result.checks.push({name,pass,detail});
 async function fresh(name,fn,mobile=false){const context=await browser.newContext({viewport:mobile?{width:390,height:844}:{width:1440,height:900},deviceScaleFactor:1,isMobile:mobile,hasTouch:mobile,acceptDownloads:true});const p=await context.newPage();p.setDefaultTimeout(5000);p.on('pageerror',e=>result.errors.push({flow:name,error:String(e)}));await context.route('**/*',r=>{let u=r.request().url();u.startsWith(url)||u.startsWith('data:')||u.startsWith('blob:')?r.continue():r.abort();});try{await p.goto(url,{waitUntil:'networkidle'});await p.waitForTimeout(800);await fn(p,context);}catch(e){add(name+'-flow-error',false,String(e));}finally{await context.close();}}
 const state=p=>p.evaluate(()=>window.__BENCH__?.getState?.()??null);
 const shot=(p,n)=>p.screenshot({path:path.join(dest,n+'.png'),fullPage:false});
 const click=(p,s)=>s.startsWith('#')?p.locator(s).click():p.getByRole('button',{name:s,exact:true}).click();
 async function pause(p){if((await state(p))?.playing)await click(p,cfg.play);await p.waitForTimeout(120);}
 try{
  await fresh('playback-keyboard',async p=>{
   const a=await state(p);await p.waitForTimeout(1100);const b=await state(p);add('autoplay-progress',time(b)>time(a)+.5,{a,b});
   await pause(p);const pausedA=await state(p);const ca=p.locator('canvas').first();let frameA=null;if(await ca.count())frameA=sha(await ca.screenshot());await p.waitForTimeout(1100);const pausedB=await state(p);let frameB=null;if(await ca.count())frameB=sha(await ca.screenshot());add('visible-pause-time',Math.abs(time(pausedB)-time(pausedA))<.06&&!pausedB.playing,{a:pausedA,b:pausedB,exactCanvasFreeze:frameA&&frameB?frameA===frameB:null});
   await click(p,cfg.play);const playA=await state(p);await p.waitForTimeout(1100);const playB=await state(p);add('visible-resume-progress',time(playB)>time(playA)+.5,{a:playA,b:playB});
   if(c.topic!=='courtyard'){await p.locator(cfg.play).focus();const before=await state(p);await p.keyboard.press('Space');await p.waitForTimeout(150);const after=await state(p);add('focused-button-space-single-toggle',after.playing!==before.playing,{before,after});await click(p,cfg.reset);await p.waitForTimeout(120);const reset=await state(p);add('visible-reset-replay',time(reset)<.7,{state:reset});}
   await shot(p,'controls-after-playback');
  });
  if(c.topic==='pelican'){
   await fresh('exports',async p=>{await pause(p);for(const kind of ['png','svg']){const pending=p.waitForEvent('download',{timeout:8000});await click(p,cfg[kind]);const dl=await pending;const filename='export.'+kind;await dl.saveAs(path.join(dest,filename));const bytes=fs.readFileSync(path.join(dest,filename));const valid=kind==='png'?bytes.subarray(1,4).toString()==='PNG':/<svg[\s>]/i.test(bytes.toString());const data={kind,filename,bytes:bytes.length,sha256:sha(bytes),suggestedFilename:dl.suggestedFilename(),signatureValid:valid};result.downloads.push(data);add('real-'+kind+'-download',valid&&bytes.length>100,data);}
    await shot(p,'export-source-paused');});
   for(const kind of ['png','svg'])if(fs.existsSync(path.join(dest,'export.'+kind))){await fresh('open-'+kind,async p=>{await p.goto(url+'_exports/export.'+kind,{waitUntil:'networkidle'});await p.waitForTimeout(250);await shot(p,'opened-export-'+kind);const size=await p.evaluate(()=>{const e=document.querySelector('svg')||document.querySelector('img');return e?{tag:e.tagName,width:e.getBoundingClientRect().width,height:e.getBoundingClientRect().height}:null;});add('downloaded-'+kind+'-opens',!!size&&size.width>0&&size.height>0,size);});}
  }
  if(c.topic==='courtyard'){
   await fresh('views-labels',async p=>{await pause(p);const before=await state(p);if(cfg.labels.endsWith('Chk'))await p.locator(cfg.labels).uncheck();else if(before.labels)await click(p,cfg.labels);add('visible-labels-toggle',(await state(p)).labels===false,{before,after:await state(p)});
    for(let i=0;i<cfg.views.length;i++){await click(p,cfg.views[i]);await p.waitForTimeout(1600);const s=await state(p);await shot(p,['ui-overview-no-labels','ui-detail-no-labels','ui-side-no-labels'][i]);add('visible-preset-'+['overview','detail','side'][i],s.preset===['overview','detail','side'][i],{state:s});}
    await click(p,cfg.reset);await p.waitForTimeout(1300);add('visible-view-reset',(await state(p)).preset==='overview',{state:await state(p)});
    if(c.id==='courtyard-strata'){await p.getByRole('button',{name:/^月洞门 moon gate/}).click();await p.waitForTimeout(1500);await shot(p,'focused-moon-gate');add('element-list-focus',true,{state:await state(p)});}
   });
  }
  if(c.topic==='sun'){
   await fresh('timeline-speed',async p=>{await pause(p);const before=await state(p),range=p.locator(cfg.timeline),box=await range.boundingBox();await range.click({position:{x:box.width*.5,y:box.height*.5}});await p.waitForTimeout(1800);const seek=await state(p);await shot(p,'real-timeline-midpoint');add('real-timeline-scrub',Math.abs(time(seek)-45)<3,{before,after:seek});
    await click(p,cfg.reset);if(cfg.speedKind==='select')await p.locator(cfg.speed).selectOption('2');else await click(p,cfg.speed);const a=await state(p),start=performance.now();await p.waitForTimeout(1400);const b=await state(p),wall=(performance.now()-start)/1000,rate=(time(b)-time(a))/wall;add('real-speed-two',rate>1.5&&rate<2.5,{a,b,wall_s:wall,observed_rate:rate});
   });
  }
  if(c.topic!=='pelican'){
   await fresh('real-camera',async p=>{await pause(p);let s=await state(p);if(c.topic==='sun'&&(s.autoCam||s.camera?.auto||s.camera==='auto'))await click(p,cfg.auto);await p.waitForTimeout(1000);const canvas=p.locator('canvas').first(),box=await canvas.boundingBox(),a=sha(await canvas.screenshot());await p.waitForTimeout(350);const stable=sha(await canvas.screenshot())===a;const before=await state(p);await p.mouse.move(box.x+box.width*.55,box.y+box.height*.6);await p.mouse.down();await p.mouse.move(box.x+box.width*.74,box.y+box.height*.48,{steps:15});await p.mouse.up();await p.waitForTimeout(900);const b=sha(await canvas.screenshot()),after=await state(p);await shot(p,'real-orbit-paused');add('real-orbit-with-paused-scene',a!==b,{baselineStable:stable,before,after,beforeImage:a,afterImage:b});await p.mouse.wheel(0,-300);await p.waitForTimeout(1000);const z=sha(await canvas.screenshot());await shot(p,'real-zoom-paused');add('real-wheel-zoom',z!==b,{beforeImage:b,afterImage:z,state:await state(p)});});
  }
  await fresh('mobile-fresh',async(p,context)=>{await p.waitForTimeout(1800);await shot(p,'mobile-fresh');const dim=await p.evaluate(()=>({width:innerWidth,scroll:document.documentElement.scrollWidth}));add('fresh-mobile-no-page-overflow',dim.scroll<=dim.width+1,dim);
   if(cfg.panel){await click(p,cfg.panel);await p.waitForTimeout(250);await shot(p,'mobile-controls-open');await click(p,cfg.panel);}
   if(c.topic!=='pelican'){await pause(p);const s=await state(p);if(c.topic==='sun'&&(s.autoCam||s.camera?.auto||s.camera==='auto'))await click(p,cfg.auto);const ca=p.locator('canvas').first(),a=sha(await ca.screenshot()),cdp=await context.newCDPSession(p);await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{x:210,y:600,id:1}]});for(let i=1;i<=12;i++)await cdp.send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[{x:210+i*8,y:600-i*4,id:1}]});await cdp.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});await p.waitForTimeout(800);const b=sha(await ca.screenshot());await shot(p,'mobile-after-real-touch');add('mobile-real-touch-orbit',a!==b,{beforeImage:a,afterImage:b,state:await state(p)});await cdp.detach();}
  },true);
  if(c.topic==='sun'){
   await fresh('live-full-film',async p=>{await click(p,cfg.reset);const wall=performance.now();for(const target of [0,15,30,45,60,75,89]){while(time(await state(p))<target){if(performance.now()-wall>130000)throw new Error('Live film did not reach '+target+'seconds in130s');await p.waitForTimeout(80);}const s=await state(p),name='live-'+String(target).padStart(2,'0');await shot(p,name);result.liveFrames.push({target_s:target,state:s,wall_s:(performance.now()-wall)/1000,image:name+'.png'});}await p.waitForTimeout(1300);result.liveEnd=await state(p);add('live-full-nominal-film',result.liveFrames.length===7,{frames:result.liveFrames,end:result.liveEnd,wall_s:(performance.now()-wall)/1000});});
  }
 }finally{result.finished=new Date().toISOString();fs.writeFileSync(path.join(dest,'results.json'),JSON.stringify(result,null,2)+'\n');await new Promise(r=>server.close(r));console.log(JSON.stringify({id:c.id,checks:result.checks.length,failed:result.checks.filter(x=>!x.pass).map(x=>x.name),errors:result.errors}));}
 return result;
}
(async()=>{const browser=await chromium.launch({headless:true,executablePath:'/Applications/Chromium.app/Contents/MacOS/Chromium'});try{const matrix=JSON.parse(fs.readFileSync(path.join(E,'matrix.json'))),ids=process.argv.slice(2),out=[];for(const c of matrix)if(!ids.length||ids.includes(c.id))out.push(await verify(browser,c));fs.writeFileSync(path.join(E,'scoring/manual-checks.json'),JSON.stringify({version:1,browser:browser.version(),cases:out},null,2)+'\n');}finally{await browser.close();}})().catch(e=>{console.error(e);process.exitCode=1;});
