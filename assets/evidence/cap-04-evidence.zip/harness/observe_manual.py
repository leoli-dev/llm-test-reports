"""One-second system/native status while the owned independent UI verifier is alive."""
from pathlib import Path
import json,os,subprocess,time
import psutil
from runner import api,stamp
from macos_telemetry import collect
E=Path(__file__).resolve().parents[1]
def main():
 matches=[]
 for p in psutil.process_iter(['cmdline','cwd','create_time']):
  try:
   if p.info['cwd']==str(E) and 'harness/manual-verify.cjs' in (p.info['cmdline']or[]):matches.append(p)
  except psutil.Error:pass
 assert len(matches)==1,[x.pid for x in matches]
 p=matches[0];pid=p.pid;born=p.create_time();caffeine=subprocess.Popen(['/usr/bin/caffeinate','-i','-w',str(pid)],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
 with (E/'scoring/manual-evaluation-system.jsonl').open('w') as f:
  while True:
   try:
    if not p.is_running() or p.create_time()!=born or p.status()==psutil.STATUS_ZOMBIE:break
   except psutil.Error:break
   t=time.monotonic();row=collect(pid);row.update(at=stamp(),stage='independent-visible-control-evaluation',observed_driver_pid=pid,native_status={})
   for name in ['mltf','splash','strata']:
    try:row['native_status'][name]=api(name,'/v1/status' if name=='strata' else '/status')
    except Exception as exc:row['native_status'][name]={'unavailable':repr(exc),'expected_stopped':name!='strata'}
   f.write(json.dumps(row)+'\n');f.flush();time.sleep(max(.05,1-(time.monotonic()-t)))
 try:caffeine.wait(timeout=3)
 except subprocess.TimeoutExpired:caffeine.terminate();caffeine.wait(timeout=3)
 print('Owned UI verifier ended; manual telemetry and idle-sleep assertion stopped',flush=True)
if __name__=='__main__':main()
