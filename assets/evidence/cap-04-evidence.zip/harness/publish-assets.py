from pathlib import Path
import hashlib,json,shutil
E=Path(__file__).resolve().parents[1];F=Path('/Users/benchmark/Code/llm-test-reports/assets/figures');rows=[]
for c in json.loads((E/'matrix.json').read_text()):
 id=c['id'];s=E/'scoring'/id;pick={'desktop':s/'browser-v1/desktop-initial.png','mobile':s/'manual-v1/mobile-fresh.png'}
 if c['topic']=='pelican':pick.update({'export-png':s/'manual-v1/opened-export-png.png','export-svg':s/'manual-v1/opened-export-svg.png'})
 if c['topic']=='courtyard':pick.update({n:s/f'manual-v1/ui-{n}-no-labels.png' for n in ['overview','detail','side']})
 if c['topic']=='sun':pick.update({f'live-{n:02}':s/f'manual-v1/live-{n:02}.png' for n in [0,45,89]})
 for label,p in pick.items():
  q=F/f'cap-04-{id}-{label}.png';shutil.copyfile(p,q);sha=lambda x:hashlib.sha256(x.read_bytes()).hexdigest();assert sha(p)==sha(q);rows.append({'case':id,'label':label,'source':str(p.relative_to(E)),'asset':'assets/figures/'+q.name,'sha256':sha(q),'bytes':q.stat().st_size})
(E/'scoring/screenshot-index.json').write_text(json.dumps({'unchanged_pixels':True,'contact_sheets':'Private review only; report uses byte-identical individual screenshots','images':rows},indent=2)+'\n');print(len(rows),'byte-identical report screenshots')
