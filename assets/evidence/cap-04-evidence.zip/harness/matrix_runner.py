"""Sequential nine-cell runner. Does not edit candidate product implementation."""
from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,threading,time,traceback,urllib.request
import psutil
from runner import api,backend_identity,stamp,dump
from macos_telemetry import collect
E=Path(__file__).resolve().parents[1];L=Path('/Users/benchmark/local_llms');PY=sys.executable
stop=threading.Event();state={'phase':'setup','label':None,'runid':None};steps=[]
def record_state(**kw):state.update(kw);dump(E/'raw/matrix-progress.json',{'at':stamp(),**state})
def telemetry():
 (E/'raw').mkdir(exist_ok=True)
 with (E/'raw/lifecycle-system.jsonl').open('w') as f:
  while not stop.is_set():
   t=time.monotonic();row=collect(os.getpid());row.update(controller_state=state.copy(),at=stamp(),native_status=None)
   if state['label']:
    try:row['native_status']=api(state['label'],'/v1/status' if state['label']=='strata' else '/status')
    except Exception as exc:row['native_status_error']=repr(exc)
   f.write(json.dumps(row,ensure_ascii=False)+'\n');f.flush();stop.wait(max(.05,1-(time.monotonic()-t)))
def step(name,cmd,timeout=600,check=True):
 record_state(phase=name);start=time.monotonic()
 with (E/'raw'/(name+'.log')).open('ab') as f:r=subprocess.run(cmd,cwd=E,stdout=f,stderr=subprocess.STDOUT,timeout=timeout)
 item={'name':name,'at':stamp(),'wall_s':time.monotonic()-start,'exit':r.returncode};steps.append(item);dump(E/'raw/service-switches.json',steps);print(json.dumps(item),flush=True)
 if check:r.check_returncode()
 return r.returncode
def snapshot_services():
 out={}
 for label in ['mltf','splash','strata']:
  try:out[label]={'available':True,'status':api(label,'/v1/status' if label=='strata' else '/status')}
  except Exception as exc:out[label]={'available':False,'error':repr(exc)}
 return out
def verify_smoke(case):
 r=E/'raw'/case['id']/'smoke';events=[json.loads(x) for x in (r/'pi-events.jsonl').read_text().splitlines()];p=r/'smoke-project/probe.txt'
 checks={'write':p.exists() and p.read_text().strip()=='391','bash_readback':any(v.get('type')=='tool_execution_end' and v.get('toolName')=='bash' and not v.get('isError') for v in events),'context':False}
 for v in events:
  if v.get('type')=='response' and v.get('id')=='state-before':
   m=(v.get('data') or {}).get('model') or {};checks['context']=m.get('contextWindow')==262144
 dump(r/'checks.json',checks)
 if not all(checks.values()):raise RuntimeError('Smoke or Pi context assertion failed; preserve evidence and investigate '+str(checks))
def main():
 (E/'raw').mkdir(exist_ok=True);initial=snapshot_services();dump(E/'configs/initial-services.json',initial)
 # Never stop active unrelated requests.
 def busy(d):
  if isinstance(d,dict):return any((k in ['in_flight','inflight','active_requests'] and isinstance(v,(int,float)) and v>0) or busy(v) for k,v in d.items())
  if isinstance(d,list):return any(busy(x) for x in d)
  return False
 assert not any(busy(v.get('status',{})) for v in initial.values()),'Initial model request active; cannot switch safely'
 monitor=threading.Thread(target=telemetry,daemon=True);monitor.start();current=None;fatal=None
 original=(E/'private/mltf-config.before.json').read_bytes();changed_config=False
 try:
  for label,v in initial.items():
   if v['available']:step('initial-stop-'+label,[str(L/label/'stop.sh')])
  p=L/'mltf/config.json';assert p.read_bytes()==original;cfg=json.loads(original);cfg['context_tokens']=262144;p.write_text(json.dumps(cfg,indent=2)+'\n');changed_config=True
  checked=set()
  for case in json.loads((E/'matrix.json').read_text()):
   record_state(label=case['label'],runid=case['id'])
   if current!=case['label']:
    if current:step('stop-before-'+case['id'],[str(L/current/'stop.sh')])
    current=case['label'];step('start-'+case['id'],[str(L/current/'start.sh')],timeout=600)
   status=api(current,'/v1/status' if current=='strata' else '/status');ctx=status.get('context',{}).get('native') if current=='strata' else status.get('maximum_context_tokens');assert ctx==262144,('Native context mismatch',current,ctx)
   dump(E/'configs'/('ready-'+case['id']+'.json'),{'at':stamp(),'status':status,'root_pid':backend_identity(current)})
   if current not in checked:
    step('smoke-'+case['id'],[PY,'-u','harness/runner.py',case['id'],'smoke'],timeout=300);verify_smoke(case);checked.add(current)
   step('formal-'+case['id'],[PY,'-u','harness/runner.py',case['id'],'formal'],timeout=3670)
   summary=json.loads((E/'raw'/case['id']/'formal/summary.json').read_text());dump(E/'raw'/('cell-complete-'+case['id']+'.json'),{k:v for k,v in summary.items() if k!='backend_after'})
   if summary['reason']=='resource_abort':raise RuntimeError('Resource safety abort; do not repeat or start another large model')
  record_state(phase='all-development-frozen',label=current)
 except BaseException as exc:
  fatal=repr(exc);dump(E/'raw/matrix-error.json',{'at':stamp(),'state':state.copy(),'error':fatal,'traceback':traceback.format_exc()});print('MATRIX_ERROR '+fatal,flush=True)
 finally:
  if current:
   try:step('final-stop-'+current,[str(L/current/'stop.sh')],check=False)
   except Exception as exc:dump(E/'raw/final-stop-error.json',{'error':repr(exc)})
  if changed_config:(L/'mltf/config.json').write_bytes(original)
  # Restore initial availability after a normal matrix; keep safety-failed services stopped.
  safety='Resource safety abort' in (fatal or '')
  for label,v in initial.items():
   if v['available'] and not safety:
    try:step('restore-'+label,[str(L/label/'start.sh')],check=False)
    except Exception as exc:dump(E/'raw'/('restore-error-'+label+'.json'),{'error':repr(exc)})
  final=snapshot_services();dump(E/'raw/final-services.json',final);stop.set();monitor.join(timeout=5)
  rows=[]
  for case in json.loads((E/'matrix.json').read_text()):
   p=E/'raw'/case['id']/'formal/summary.json';rows.append({'id':case['id'],'summary':json.loads(p.read_text()) if p.exists() else None})
  dump(E/'raw/matrix-complete.json',{'at':stamp(),'fatal':fatal,'cells':rows,'all_nine_frozen':all((E/'raw'/r['id']/'formal/source-snapshot.json').exists() for r in rows),'global_pi_unchanged':hashlib.sha256((Path.home()/'.pi/agent/models.json').read_bytes()).hexdigest()==json.loads((E/'private/global-integrity-before.json').read_text())['pi_models_sha256'],'mltf_native_config_restored':(L/'mltf/config.json').read_bytes()==original})
  record_state(phase='complete' if not fatal else 'failed',label=None)
 if fatal:raise SystemExit(1)
if __name__=='__main__':main()
