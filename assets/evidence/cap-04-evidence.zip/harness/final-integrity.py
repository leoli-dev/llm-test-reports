from pathlib import Path
import hashlib,json,subprocess,sys
from runner import api
E=Path(__file__).resolve().parents[1];H=Path.home();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();cases=[]
for c in json.loads((E/'matrix.json').read_text()):
 d=E/'scoring'/c['id'];s=json.loads((d/'source-integrity.json').read_text());changed=[n for n,v in s['files'].items() if sha(d/'frozen'/n)!=v['sha256']];head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=c['path'],text=True).strip();status=subprocess.check_output(['git','status','--porcelain'],cwd=c['path'],text=True).strip();cases.append({'id':c['id'],'head':head,'snapshot_matches':head==s['snapshot_commit'],'author_worktree_clean':not status,'evaluation_copy_changed_files':changed});assert not changed and not status and head==s['snapshot_commit']
 before=json.loads((E/'private/global-integrity-before.json').read_text());services={}
for m in ['mltf','splash','strata']:
 try:
  v=api(m,'/v1/status' if m=='strata' else '/status');services[m]={'available':True,'ready':v.get('ready',v.get('loaded')),'context':v.get('context',v.get('maximum_context_tokens'))}
 except Exception:services[m]={'available':False}
x={'cases':cases,'pi_global_config_unchanged':sha(H/'.pi/agent/models.json')==before['pi_models_sha256'],'mltf_config_restored':sha(H/'local_llms/mltf/config.json')==before['mltf_config_sha256'],'report_AGENTS_unchanged':sha(H/'Code/llm-test-reports/AGENTS.md')==before['report_AGENTS_sha256'],'services':services};assert x['pi_global_config_unchanged'] and x['mltf_config_restored'] and x['report_AGENTS_unchanged'];(E/'scoring/final-integrity.json').write_text(json.dumps(x,indent=2)+'\n');print(x)
