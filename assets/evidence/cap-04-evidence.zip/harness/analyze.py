"""Summarize recorded metadata, not candidate self-reported performance."""
from pathlib import Path
import collections,datetime,hashlib,json,statistics,sys
E=Path(__file__).resolve().parents[1]
def readrows(p):return [json.loads(s) for s in p.read_text().splitlines()] if p.exists() else []
def stat(xs):
 v=[x for x in xs if isinstance(x,(float,int)) and not isinstance(x,bool)]
 return {'n':len(v),'min':min(v) if v else None,'max':max(v) if v else None,'mean':statistics.mean(v) if v else None,'median':statistics.median(v) if v else None}
def analyze(case):
 r=E/'raw'/case['id']/'formal';summary=json.loads((r/'summary.json').read_text());resources=readrows(r/'resources.jsonl');launch=json.loads((r/'launch.json').read_text());dev_start=datetime.datetime.fromisoformat(launch['at']).timestamp();dev_end=dev_start+summary['wall_s'];dev=[x for x in resources if x['stage']=='development' and dev_start<=x['unix_seconds']<=dev_end];events=readrows(r/'pi-events.jsonl');requests=[json.loads(p.read_text()) for p in sorted((r/'requests').glob('*/result.json'))]
 metrics=['process_rss_bytes','process_physical_footprint_bytes','process_tree_rss_sum_bytes','process_tree_physical_footprint_sum_bytes','process_cpu_percent','pi_tree_rss_sum_bytes','system_cpu_percent','gpu_device_utilization_percent','gpu_in_use_system_memory_bytes','gpu_in_use_driver_memory_bytes','engine_allocated_bytes','swap_used_bytes','swap_delta_bytes','native_status_local_age_seconds']
 engine_identities=collections.Counter()
 for row in dev:
  pid=row.get('engine_pid');proc=next((x for x in row.get('processes',[]) if x.get('pid')==pid),None)
  if pid and proc:engine_identities[(pid,proc.get('process_start_abstime'))]+=1
 pressure=collections.Counter(x.get('memory_pressure_name') for x in dev);errors=collections.Counter(k for x in dev for k in x.get('errors',{}));reqerrors=[{'id':x['id'],'error':x.get('error'),'http_status':x.get('http_status')} for x in requests if x.get('error') or x.get('http_status')!=200]
 usage=[x.get('usage') or {} for x in requests];timings=[x.get('timings') or {} for x in requests];timingskeys=collections.Counter(k for x in timings for k in x)
 counts=collections.Counter(x.get('type') for x in events);ended=[x for x in events if x.get('type')=='tool_execution_end'];started=[x for x in events if x.get('type')=='tool_execution_start'];starts={x.get('toolCallId') for x in started};ends={x.get('toolCallId') for x in ended}
 images=[];max_messages=0;sampling=[]
 for p in sorted((r/'requests').glob('*/request.json')):
  d=json.loads(p.read_text());max_messages=max(max_messages,len(d.get('messages',[])));sampling.append({k:d.get(k) for k in ['temperature','top_p','top_k','reasoning_effort','max_tokens']})
  for m in d.get('messages',[]):
   if isinstance(m.get('content'),list):
    for c in m['content']:
     if c.get('type')=='image_url':images.append(hashlib.sha256(str(c['image_url']).encode()).hexdigest())
 decoder_n=sum(x.get('predicted_n') or 0 for x in timings);decoder_ms=sum(x.get('predicted_ms') or 0 for x in timings)
 result={'case':case,'run':summary,'snapshot':json.loads((r/'source-snapshot.json').read_text()),'resource':{'samples_all':len(resources),'samples_development':len(dev),'sample_interval_s':stat(b['unix_seconds']-a['unix_seconds'] for a,b in zip(dev,dev[1:])),'first_sample_delay_s':dev[0]['unix_seconds']-dev_start if dev else None,'last_sample_lag_s':dev_end-dev[-1]['unix_seconds'] if dev else None,'sampling_filter':'stage=development within launch timestamp + measured wall_s; excludes post-settle process drain/cleanup','development_start_unix':dev_start,'development_end_unix':dev_end,'metrics':{k:stat(x.get(k) for x in dev) for k in metrics},'pressure':dict(pressure),'telemetry_errors':dict(errors),'native_status_stale_samples':sum(bool(x.get('native_status_stale')) for x in dev),'native_engine_identities':[{'pid':pid,'start_abstime':started,'samples':n} for (pid,started),n in engine_identities.items()],'native_engine_identity_count':len(engine_identities),'native_engine_unresolved_samples':len(dev)-sum(engine_identities.values()),'temperature':'unavailable; not zero-filled; no no-throttling claim'},'requests':{'count':len(requests),'errors':reqerrors,'input_max':max((x.get('prompt_tokens',0) for x in usage),default=0),'output_sum':sum(x.get('completion_tokens',0) for x in usage),'first_meaningful_model_event_s':stat(x.get('first_content_s') for x in requests),'request_wall_s':stat(x.get('wall_s') for x in requests),'native_decode_weighted_tok_s':decoder_n/(decoder_ms/1000) if decoder_ms else None,'native_timings_keys':dict(timingskeys),'max_messages':max_messages,'image_occurrences':len(images),'unique_images':len(set(images)),'sampling_distinct':[json.loads(x) for x in sorted(set(json.dumps(x,sort_keys=True) for x in sampling))]},'agent':{'event_counts':dict(counts),'assistant_stop_reasons':dict(collections.Counter(x['message'].get('stopReason','not-recorded') for x in events if x.get('type')=='message_end' and x.get('message',{}).get('role')=='assistant')),'tool_starts':len(started),'tool_error_flags':sum(bool(x.get('isError')) for x in ended),'unclosed_tools':sorted(starts-ends),'tool_names':dict(collections.Counter(x.get('toolName') for x in started))},'phases':json.loads((r/'phases.json').read_text()) if (r/'phases.json').exists() else []}
 dest=E/'scoring'/case['id'];dest.mkdir(parents=True,exist_ok=True);(dest/'run-analysis.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');return result
def main():
 out=[]
 for case in json.loads((E/'matrix.json').read_text()):
  if (E/'raw'/case['id']/'formal/source-snapshot.json').exists():out.append(analyze(case))
 (E/'scoring').mkdir(exist_ok=True);(E/'scoring/run-analyses.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print('Analyzed frozen cells',len(out))
if __name__=='__main__':main()
