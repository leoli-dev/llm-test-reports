// Observe contexts requested by the app; never allocate an extra context as a probe.
exports.install=async page=>page.addInitScript(()=>{
 const contexts=new WeakMap(),original=HTMLCanvasElement.prototype.getContext;
 Object.defineProperty(window,'__CODEX_OBSERVED_CANVAS_CONTEXTS__',{value:contexts});
 HTMLCanvasElement.prototype.getContext=function(type,...args){
  const result=Reflect.apply(original,this,[type,...args]);let state=contexts.get(this);
  if(!state){state={attempts:[],type:null,context:null};contexts.set(this,state);}
  state.attempts.push(String(type));if(result){state.type=String(type);state.context=result;}return result;
 };
});
exports.inspect=async page=>page.evaluate(()=>({
 canvases:[...document.querySelectorAll('canvas')].map(c=>{
  const observed=window.__CODEX_OBSERVED_CANVAS_CONTEXTS__?.get(c);const webgl=!!observed&&['webgl','webgl2','experimental-webgl'].includes(observed.type);const gl=webgl?observed.context:null;let renderer=null,vendor=null;
  if(gl){const ext=gl.getExtension('WEBGL_debug_renderer_info');renderer=ext?gl.getParameter(ext.UNMASKED_RENDERER_WEBGL):gl.getParameter(gl.RENDERER);vendor=ext?gl.getParameter(ext.UNMASKED_VENDOR_WEBGL):gl.getParameter(gl.VENDOR);}
  return{width:c.width,height:c.height,rect:c.getBoundingClientRect().toJSON(),contextType:observed?.type??null,requestedTypes:observed?.attempts??[],webgl,renderer,vendor};
 }),svgs:document.querySelectorAll('svg').length,
 observationMethod:'Recorded application getContext calls; this metadata probe creates no rendering context.'
}));
