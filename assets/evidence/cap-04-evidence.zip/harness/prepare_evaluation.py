"""Create one immutable source snapshot copy per purpose; no evaluation in author tree."""
from pathlib import Path
import hashlib,io,json,subprocess,tarfile
E=Path(__file__).resolve().parents[1]
def sha(b):return hashlib.sha256(b).hexdigest()
def prepare(case):
 r=E/'raw'/case['id']/'formal';snap=json.loads((r/'source-snapshot.json').read_text());dest=E/'scoring'/case['id'];dest.mkdir(parents=True,exist_ok=True);copy=dest/'frozen'
 if copy.exists():raise RuntimeError('Refuse to reuse an existing mutable evaluation copy '+str(copy))
 head=snap['head'];archive=subprocess.check_output(['git','archive',head],cwd=case['path']);copy.mkdir()
 with tarfile.open(fileobj=io.BytesIO(archive)) as tar:tar.extractall(copy,filter='data')
 files={str(p.relative_to(copy)):{'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size} for p in copy.rglob('*') if p.is_file() and not p.is_symlink()}
 current=subprocess.check_output(['git','rev-parse','HEAD'],cwd=case['path'],text=True).strip();status=subprocess.check_output(['git','status','--porcelain'],cwd=case['path'],text=True)
 assert current==head and not status,(current,head,status)
 (dest/'source-integrity.json').write_text(json.dumps({'snapshot_commit':head,'archive_sha256':sha(archive),'author_worktree_clean':not status,'files':files},ensure_ascii=False,indent=2)+'\n')
 print('Prepared immutable evaluation copy',case['id'],head)
def main():
 matrix=json.loads((E/'matrix.json').read_text());assert all((E/'raw'/c['id']/'formal/source-snapshot.json').exists() for c in matrix),'All nine source snapshots must be frozen before evaluation'
 for case in matrix:prepare(case)
if __name__=='__main__':main()
