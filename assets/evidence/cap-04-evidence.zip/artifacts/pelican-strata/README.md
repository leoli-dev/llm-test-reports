# 鹈鹕骑车游香榭丽舍大道 · Pelican on the Champs-Élysées

Original 2D browser illustration (Canvas2D, hand-authored geometry; static artwork with
optional animation). No external fonts, images, CDNs or network resources.

## Launch

```bash
python3 -m http.server 4203 --bind 127.0.0.1
# then open http://127.0.0.1:4203/index.html
```

(Use `--bind` and `127.0.0.1` as separate arguments, as required by the run spec.)

## What's in the scene

- **Pelican** (readable silhouette): long beak with hooked tip and large drooping
  gular pouch, S-neck, plump body with folded wing, tail feathers, legs with
  webbed feet on the pedals; wing-tips rest on the handlebar grips. Beret and
  wind-blown scarf as Parisian accents.
- **Bicycle**: two spoked wheels with tires/rim/hub, diamond frame (seat tube,
  top tube, down tube, chain/seat stays), head tube + front fork, swept
  handlebars with grips, saddle, crank + pedal, chainring and chain, fenders.
- **Champs-Élysées**: one-point-perspective tree-lined boulevard (vanishing point
  under the Arc), central trimmed hedge, plane trees receding on both sides,
  Parisian street lamps, Haussmann facades with mansard roofs, dormers, window
  rows and ground-floor arcades, roadway with lane dashes and curbs,
  **Arc de Triomphe** closing the vista, low sun behind it, clouds and birds.
- Everything is drawn from geometry — no text labels claim it is Paris.

## Controls (mouse + keyboard, all focusable with visible focus ring)

| Control | UI | Keyboard |
|---|---|---|
| Play / Pause | ⏸/▶ button (aria-pressed) | Space |
| Reset time | ↺ button | R |
| Step ±1 s | — | ← / → |
| Speed 0–2× | range slider | focus slider, arrows |
| Export PNG of current frame | ⬇ PNG button | focus + Enter |
| Export SVG of current frame | ⬇ SVG button | focus + Enter |

The SVG export rebuilds the *same* path list that was rendered to canvas, so the
exported vector file matches the visible frame (verified by re-rendering the
exported SVG in Chromium).

## Test hooks

`window.__BENCH__` (available once the page loads):

- `getState()` → `{t, playing, speed, scene, designW, designH}` (JSON-serializable)
- `setTime(seconds)`, `pause()`, `play()`, `reset()`
- No `cameraPreset` — this is a fixed-camera 2D artwork.

## Responsive

Design space 1440×900, scaled "contain" to the viewport with dark letterbox.
Verified at 1440×900 (desktop) and 390×844 (mobile, header wraps, no horizontal
scroll: `scrollWidth == innerWidth`).

## Files

- `index.html` — the artwork (all geometry authored here)
- `README.md` — this file
- `VISUAL-NOTES.md` — self-review: what was actually inspected in screenshots
- `notes/final_desktop_t2.5.png`, `notes/final_desktop_t0.png`,
  `notes/final_mobile_t2.5.png`, `notes/legs_t1.5.png`, `notes/legs_t3.7.png`,
  `notes/export_test_sample.svg` — inspected screenshots / export sample

## Limitations

- Fixed one-point perspective composition; no camera panning.
- The far leg/foot is partly occluded by the frame at some crank angles.
- Sun/lighting is static (golden hour); only pedaling/scarf/road-dash motion animates.
- Mobile portrait letterboxes the 16:9 artwork (scene stays small but complete).
- Animation loops pedaling/scarf/road-dash motion only; the background itself
  does not translate (dashes convey motion).
