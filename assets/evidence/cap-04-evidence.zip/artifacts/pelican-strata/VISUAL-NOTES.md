# VISUAL-NOTES — what I actually inspected (self-review pass)

Method: Chromium (`/Applications/Chromium.app`) driven by Playwright; screenshots
saved and *viewed as images* (not just DOM/pixel counts). Viewports 1440×900 and
390×844, deviceScaleFactor 1. Animation controlled via `window.__BENCH__`
(pause/setTime) and also observed in free playback.

## 1. Composition & required subjects — verified in viewed screenshots

Desktop stills at t = 0, 1.5, 2.5, 3.2, 3.7, 5.0 (`notes/final_desktop_t2.5.png`,
`notes/final_desktop_t0.png`, `notes/legs_t1.5.png`, `notes/legs_t3.7.png`):

- Pelican is immediately readable: long straight beak with hooked tip, large
  drooping gular pouch (orange, with inner shading line), S-neck, plump white
  body, folded wing whose tip ends on the handlebar grip (red grip visible under
  it), tail feathers, two legs ending in orange webbed feet on the pedals.
- Bicycle shows two spoked wheels (tire, rim, hub, 8 spokes), diamond frame
  (seat/down/top tubes, chain/seat stays), head tube + front fork, swept
  handlebars, saddle, crank arms (near and far), pedals, chainring + chain,
  fenders. Feet contact pedals at every sampled crank angle.
- Boulevard: one-point perspective converging exactly under the Arc de
  Triomphe; central trimmed hedge row; receding plane trees both sides; Parisian
  lamps; Haussmann facades with mansard roofs, dormers, window rows, arcade
  band; curbs and lane dashes. No text label is used to claim "Paris".
- Focal hierarchy: dark bike frame + white pelican against grey road reads as
  the clear focus; the Arc frames the vanishing point; the pelican's beak
  points toward the VP.

## 2. Animation stages & actual playback — verified

- Stills at multiple crank phases (t=0/1.5/2.2/3.2/3.7/5.0) show pedals at
  different angles, spokes rotated, scarf wave changed, lane dashes advanced.
- Free playback: two live screenshots ~1.2 s apart with no pause;
  `getState().t` advanced 0.77→2.05 and frames visibly differ; play button
  shows the red "⏸ 暂停 Pause" state while playing.
- The sun is a static light source behind the Arc (glow rings + warm horizon
  band); it does not animate — consistent across all stages, which is intended.

## 3. Geometry problems found and fixed during this review

- **Leg zig-zag at high pedal** (seen in t=1.5 screenshot): the old midpoint
  knee offset made the knee jut sideways and the raised foot look detached.
  Replaced with fixed femur/tibia two-segment IK (knee always bends forward);
  re-captured crops at t=1.5/2.2/3.7 confirm both feet stay attached to pedals
  with a natural bend at all phases.
- **Floating far pedal**: far crank arm and far pedal were missing; added —
  visible in the crops.
- **Knee joint spikes**: added round line-join in canvas renderer and
  `stroke-linejoin="round"` in SVG export.

## 4. Controls exercised — verified

- Desktop: Space toggles play (state false after press), ←/→ step ±1 s, R
  resets; clicking ⏸/▶, ↺ works; speed slider 0 → t frozen (0.02 after 0.9 s),
  2 → t≈1.8 after 0.9 s.
- Keyboard focus: Tab reaches buttons in order; orange focus ring clearly
  visible in screenshot on the focused button.
- Mobile 390×844 (touch context): tapping ⏸/▶ toggles (true→false→true), ↺
  resets; `scrollWidth == innerWidth` (no horizontal scroll); header compacted
  during this review so the artwork strip is larger (before/after screenshots
  compared).

## 5. Export — verified

- ⬇ PNG and ⬇ SVG produce downloads (≈200 KB / ≈53 KB). The exported SVG was
  opened in Chromium and screenshotted: renders identically to the canvas
  frame (same layer order, gradient sky, all shapes).

## 6. Claims I do NOT make (limitations)

- 60 fps smoothness on real devices — only frame-difference checks, no
  frame-rate profiling.
- Anatomical/technical accuracy — pelican and bicycle are stylized; the far
  leg is partly occluded by the frame at some crank angles (visible in crops).
- Mobile portrait keeps the 16:9 scene letterboxed; the scene is complete but
  small — unavoidable without cropping the composition.
- Lighting is a fixed golden-hour scheme; no dynamic light/shadow changes over
  time (shadow ellipse is static).
- Trees/lamps are stylized blobs, not botanical studies; hedge reads as a
  dotted row at close zoom when inspected very closely.

## Files inspected as images during this review

rev_t{0,1.5,3.2,5.0}.png, rev_live{1,2}.png, rev2_t{1.5,2.2,3.7}.png (leg
crops), rev2_focus.png, rev2_tabfocus.png, notes/final_desktop_t0.png,
notes/final_desktop_t2.5.png, notes/final_mobile_t2.5.png, svg_render_check.png
(exported SVG re-render). Intermediates deleted; evidence kept in `notes/`.
