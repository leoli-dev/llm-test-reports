# 江南庭院 · 聽雨軒 — 3D Traditional Chinese Courtyard

An original, self-contained 3D artwork of a Jiangnan (Suzhou-style, 粉牆黛瓦 "white
walls, ink-dark tiles") enclosed courtyard, built with Three.js (local vendor
build). All geometry, textures (procedural Canvas2D) and animation are authored
in `index.html`. No network, fonts, images or external assets are loaded.

## Launch

```bash
python3 -m http.server 4204 --bind 127.0.0.1
# open http://127.0.0.1:4204/
```

Desktop target 1440×900, mobile 390×844 (OrbitControls supports touch: one
finger rotate, two finger pinch-zoom / pan).

## Controls (visible in UI)

| Control | Action |
|---|---|
| Drag / one finger | orbit around the compound |
| Wheel / pinch | zoom |
| Two-finger drag | pan |
| 俯瞰 / 近景 / 側景 | camera presets `overview` / `detail` / `side` (smooth tween) |
| 重置視角 | reset to overview preset |
| 標籤 | toggle projected 3D element labels |
| 暫停 / 播放 | pause / play ambient animation (water ripples, bamboo sway, lantern flicker) |
| 元素清單 | toggle element checklist panel |

## Test hooks

`window.__BENCH__` is exposed after the module loads:
`getState()` (t / playing / preset / labels / elements), `setTime(seconds)`,
`pause()`, `play()`, `reset()`, `cameraPreset('overview'|'detail'|'side')`.

## Spatial layout & element coverage

One coherent Suzhou-classical style. Coordinate plan: courtyard 28×24 m,
north = hall, main gate south, moon gate in the east wall opening to a small
east garden. Circulation: 正門 → 影壁 → central stone path → 连廊 → 主厅;
east: 月洞门 → east garden rockery/bamboo; south-east: 小桥 over 池水 → 亭.

- 围合院墙 — plaster perimeter walls with dark tile caps (incl. east garden)
- 正门 — south gate with doors, studs, red lintel, roof cap, lanterns
- 月洞门 — true circular opening in the east wall (extruded shape w/ hole) + ring + "邀月" plaque
- 影壁 — T-screen inside the gate with 福 panel and tile cap
- 主厅 — raised stone platform hall, north center
- 两侧厢房 — east/west wing rooms with lattice windows and doors
- 连廊 — covered corridor linking hall to both wings (columns + curved roof)
- 亭 — hexagonal pavilion on a stone plinth, upturned hex roof + gilded finial
- 曲线瓦屋顶 — parametric curved gable roofs (concave slope + corner upturn), procedural small-tile texture
- 木柱/斗拱 — red lacquered columns, stacked dougong brackets at hall and pavilion eaves
- 窗棂 — grid lattice windows with central panel (hall front/sides, wings)
- 匾额/对联 — "聽雨軒" plaque, vertical couplets "竹影扫阶尘不动 / 月轮穿树鸟无声", 邀月/福 panels
- 石砖铺地 — procedural stone-tile paving texture over the courtyard
- 池水 — animated ripple water in a stone-rimmed basin, with three swimming koi
- 小桥 — arched stone bridge with wooden parapet crossing the pond to the pavilion
- 假山 — rockery island (dodecahedron stacks + pine) in the pond, plus east-garden rockery
- 竹子 — swaying bamboo clumps (stalks, node rings, foliage) in 5 locations
- 乔木/灌木/花卉 — low-poly trees, shrubs, flower beds
- 家具/灯笼 — tea table + stools set, hall furniture, stone bench, red lanterns (some lit)

## Visual / testing notes

See `VISUAL-NOTES.md` for the full independent self-review (animation
stages t=0/8/16, real playback verification, control clicks on desktop and
390px mobile, and fixes made during review). Summary: playback and all
visible controls verified via Chromium screenshots and `__BENCH__` state
reads; no page errors in any session.

## Limitations

- Low-poly stylization: foliage is icosahedron/cone blobs; koi are static
  ellipsoids; no wind on trees, no day/night cycle (ambient loop is
  water/sway/flicker only).
- Shadows use a single 2048px directional map; small shadows (lanterns,
  flowers) may be soft/imprecise.
- Labels overlap at some camera angles (2D overlay, no depth sorting).
- Textures are procedural at 256–512px; roof tiling repeats at long distances.
- CJK text uses system serif fonts (Songti SC fallback); glyph rendering
  depends on the OS font.
