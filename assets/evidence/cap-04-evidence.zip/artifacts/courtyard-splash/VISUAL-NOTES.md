# VISUAL-NOTES — independent self-review (2026-10-25)

Method: headless Chromium (via tools/screenshot.cjs and inline Playwright
scripts) against `python3 -m http.server 4204`. All statements below are from
screenshots I actually looked at, or from `window.__BENCH__` state reads in the
same sessions. Nothing here is an unobserved claim, except where marked
"not visually verified".

## What I inspected

### 1. Animation stages & real playback (desktop 1440×900)
- `getState().t` read 1.623 → 3.123 across a 1.5 s wait ⇒ **playback really
  advances** (not a still scene).
- Fixed-time captures at t=0 / 8 / 16 (overview) and t=8 / 20 (detail):
  - Overview frames were nearly identical at first ⇒ animation was
    imperceptible at distance. **Fixed**: water ripple strokes made brighter
    and faster, bamboo sway amplitude ×1.8, and **three koi now swim** in
    ellipses under the pond surface.
  - Koi positions sampled via API during real playback:
    (6.89,1.66)/(5.88,4.30)/(8.41,1.62) after 4 s of play ⇒ confirmed moving
    through actual playback, not just setTime.
  - Detail frames at t=8 vs t=20: lantern glow visibly differs (flicker works).
- Side-view frames at t=0 vs t=15: pond/rockery/bridge region clearly in
  frame; koi dots present (tiny at this scale — small motion is hard to see
  in stills even though API confirms movement).

### 2. Required objects — pixel-verified in captures
Observed on screen in overview/detail/side captures: perimeter white walls
with dark tile caps (all 4 sides + east garden), south gate with double doors
and studs and red lintel, true circular moon-gate opening in the east wall
(you can see through it to the east garden), shadow wall (影壁) with tile cap
inside the gate, main hall on stone platform with readable 聽雨軒 plaque and
couplets, lattice 窗棂 on hall and both wings, red columns + stacked dougong,
covered 连廊 spanning the courtyard in front of the hall, hexagonal 亭 with
gilded finial, arched 小桥 with dark wooden parapet crossing the pond,
rockery island with pine in teal pond water, stone paving grid texture,
bamboo clumps (5), trees/shrubs/flower dots, tea table + stools, stone bench,
red lanterns (some visibly glowing via point lights), east-garden rockery.
Not visually verified at pixel level: exact couplet characters from distance
(readable in the detail capture), koi count (occluded by water opacity).

### 3. Controls exercised (clicked, state read back)
Desktop: 俯瞰/近景/側景 buttons ⇒ `preset` = detail/side/overview; 重置視角;
標籤 toggle ⇒ `labels:false` and labels disappear from the frame; 元素清單 ⇒
legend panel visible listing all 23 elements; 暫停/播放 toggles `playing`;
mouse drag 200px + wheel −400 ⇒ camera orbited to the far side and zoomed
(captured). Mobile 390×844: 近景 then 側景 clicked ⇒ state detail/side,
side frame captured (pond/bridge/pavilion visible); 標籤 click ⇒ labels off.
Zero `pageerror` in every session.

### 4. Fixes made during this review
1. 小桥 label projected onto the pavilion roof (misleading) — anchor moved to
   the bridge's north end.
2. 假山/亭 labels overlapped — 亭 raised, 假山 shifted.
3. Detail preset had a large dark roof band filling the top of the frame —
   camera pulled back and raised (hall facade now centered, paving in lower
   half).
4. Pond mostly hidden by the pavilion in the default overview — overview
   camera raised/re-aimed and pavilion moved to (10.5, 8.4) so pond water,
   rockery and bridge read in the default frame.
5. Animation invisible in stills at distance — brighter/faster ripples,
   stronger sway, added swimming koi.
6. (Previous phase, also re-verified gone): floating moon-gate torus, solid
   wall behind the moon gate, misoriented bridge parapet, outside-wall
   cameras, over-dark roof/rock materials.

## Limitations (honest, observed)
- Still-frame animation: ripples and bamboo sway remain subtle at 1440px
  stills; koi are small. Movement is best confirmed in motion or via the
  koi position API. I verified via API + detail-frame lantern flicker.
- From low, user-driven orbit angles the big hall/corridor roofs dominate the
  frame and the courtyard is hidden (inherent to free orbit; polar angle is
  clamped so the camera never goes under the ground).
- Hall interior is dim (interior has only the small warm point light).
- 2D labels overlap at some angles and have no depth occlusion (e.g. a label
  can sit on top of a closer roof).
- Koi swim in fixed ellipses centered on the pond; they can momentarily
  render close to the rockery.
- Roof-tile texture visibly repeats at long range; foliage is low-poly blobs.

## Final verification pass
- Offline: `index.html` contains no external URLs/CDN/fetch calls; only
  relative `./vendor/` imports. All resources served 200 from the local server.
- Fresh desktop session: zero pageerrors, zero failed requests; all six
  `__BENCH__` methods present and exercised in sequence (preset detail/side/
  overview, pause, setTime(12), play, reset) with expected state read-back.
- Render is not blank (screenshot ground truth). Note: a readPixels/drawImage
  pixel probe read only 1 color — that is the known headless-WebGL
  no-preserveDrawingBuffer artifact, not a rendering defect; on-screen
  screenshots show the full scene.
- Fresh mobile 390×844 session: no errors, hooks work, portrait composition
  fills the screen with pond/rockery/bridge/hall and a compact readable UI.
- Final desktop + mobile screenshots inspected; committed as the final source.
