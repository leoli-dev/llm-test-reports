# VISUAL-NOTES — what was actually inspected

All items below were verified by rendering in Chromium (via `tools/screenshot.cjs`
and Playwright-driven headless Chromium at 1440×900 and 390×844, DPR 1) and reading
the resulting pixel screenshots. Unverified claims are listed separately at the end.

## Pass 1 (initial build)

- Full scene verified in a t=8 capture: sky/sun/clouds, converging Haussmann building
  bands (zinc roofs, dormers, chimneys, windows, shopfronts), tree rows, lamps,
  Arc de Triomphe with plaque at the vanishing point, road markings, zebra crossing,
  bollards, pelican + red bicycle. No blank areas.
- **Defect found & fixed**: throat pouch rendered as an oversized orange balloon;
  reshaped bill (longer/tapered) and pouch (slim crescent) — re-verified at t=1.2.
- Mobile 390px: control row overflowed and clipped the time readout; fixed with
  `flex:0 0 auto` on controls; re-verified (`scrollWidth === 390`, readout visible).
  (A stale CLI `--screenshot` capture initially showed the old layout; treated as
  profile cache and confirmed fixed via fresh capture + Playwright measurement.)
- Export pipeline: live SVG serializes (≈45.6 KB); rasterized to canvas with 25.0%
  non-transparent pixels (scene drawn, not blank).
- Favicon 404 fixed with an inline data-URI icon; subsequent captures report zero
  page/console errors.

## Pass 2 (independent self-review)

- **Real playback (not stills)**: with default load (playing=true), `getState().time`
  advanced 0.467 → 1.667 over 1.2 s without any interaction. Four consecutive
  captures while playing (t≈2.13 / 2.65 / 3.17 / 3.70) show the crank, pedals, both
  legs and both feet in distinct, opposite-phase configurations; wheel spoke
  orientations differ between frames. Feet stay flat on the pedals in every frame
  inspected; knees bend forward; no IK breakage (no detached feet or inverted legs)
  at the sampled phases.
- **Visible controls exercised (desktop, real clicks)**: `⏸ 暂停` click →
  `playing:false`, label flips to `▶ 播放`, `aria-pressed="false"`; click again →
  resumes (`playing:true`, label back). `↺ 重置` click → `time:0` while still playing.
  Keyboard `Space` (body focused) → toggles to paused.
- **Exports exercised end-to-end (actual download events, files saved & parsed)**:
  button + keyboard-triggered downloads both fire; saved
  `pelican-champs-elysees.png` = valid PNG, 3200×1800, 872,937 bytes;
  `pelican-champs-elysees.svg` = valid SVG (45,637 bytes, has `xmlns` and artwork
  paths). Re-verified after the mobile-framing change: export clone forces
  `viewBox="0 0 1600 900"` + `preserveAspectRatio="xMidYMid meet"`, so exports always
  contain the full scene even while the page shows the mobile crop.
- **Mobile 390×844 (touch)**: tapped 暂停 → paused (label/aria state correct);
  tapped 重置 → `time:0`; time readout fully inside viewport; zero console errors;
  two playing frames differ (motion confirmed on mobile too).
- **Defect found & fixed (mobile composition)**: at 390px the letterboxed artwork was
  only ~208px tall — not prominent. Added a mobile framing mode: `viewBox="420 0
  640 900"` + `xMidYMid slice` so the artwork fills the viewport centered on the
  pelican/bicycle (verified: entire pelican incl. tail and bill, Arc, and road
  visible, art occupies most of the screen). First attempt used
  `xMinYMid slice` which clipped the subject — caught by screenshot, corrected.
- **Desktop regression check after the change**: t=0.0 full-scene capture is
  unchanged (full 16:9 scene, neutral crank pose, zero errors).

## Pass 3 (fresh independent re-check, new browser sessions)

- Re-captured from scratch with no prior state: desktop 1440×900 at t=0.0, t=1.5, t=4.0
  and mobile 390×844 (default-playing + t=2.0 after a real tap on 暂停).
- **Desktop stages**: t=0.0 has near foot on the forward pedal / far foot on the rear
  pedal (θ=0 pose, correct); at t=1.5 both feet are near the bottom of the stroke;
  at t=4.0 the near foot is back up on the forward-up pedal and the far foot low. In
  all three, feet stay flat on their pedals, knees bend forward, crank arms point at
  their pedals, and wheel spoke angles differ frame-to-frame (rotation real). No
  detached feet, inverted legs, or clipped limbs at any sampled angle.
- **Scene consistency across frames**: background (buildings, trees, Arc, road
  markings, zebra crossing, bollards, sun, clouds) is pixel-identical across t=0/1.5/4
  — only the hero animates, as intended; no flicker or layout shift; zero
  page/console errors in every session.
- **Mobile re-check (390×844, DPR 1)**: `docW === 390` (no horizontal overflow); art
  occupies the full width and ~600px height via the subject-framed viewBox
  (`420 0 640 900` + slice); entire pelican (tail to bill tip), bicycle, Arc and
  crossing are inside the frame; control row wraps to two lines with the time
  readout fully visible; tapping 暂停 flipped the button to ▶ 播放 (paused) and the
  time readout then showed the set time (t = 2.0 s).
- **Verdict**: no new defects found this pass; no code changes were necessary. The
  earlier fixes (beak/pouch shape, mobile control overflow, mobile framing, export
  full-scene forcing) all hold up under fresh inspection.

## Final verification (offline + hooks + rendering, all in one fresh session)

- `index.html` contains no external references (grep: only local `url(#…)` SVG
  gradients); favicon is an inline data-URI; runs fully offline from
  `python3 -m http.server 4202 --bind 127.0.0.1`.
- Fresh-session functional sweep: `__BENCH__` play/pause/setTime(123.4)/reset/
  getState all behave correctly and state is JSON-serializable; all four visible
  buttons exist, are focusable and labeled; a real PNG download fired from the
  button and saved as a valid 3200×1800 PNG (869,247 bytes).
- Not blank: canvas raster of the serialized scene is non-transparent, and
  every prior pixel-level screenshot shows the full painted scene.
- Zero page errors and zero console errors in both the 1440×900 and 390×844
  sessions. Mobile: `scrollWidth === 390`, artwork ~619px tall (prominent),
  playing on load.
- No code defects found in this pass; no source changes beyond doc updates.

## Composition / geometry / style assessment (from the inspected pixels)

- Subject reads first: large white pelican with orange bill+pouch and dark outlines
  against warm street tones; bicycle clearly has two spoked wheels, red frame with
  seat/chain/down/top tubes, fork, handlebar + grip, saddle, chain, chainring,
  cranks, pedals.
- Perspective is coherent: building base/top lines, tree bases, road edges and curb
  lines all converge to the Arc; depth reinforced by the haze band and shrinking
  tree/lamp/bollard scale.
- Materials/lighting: intentional flat-illustration style — uniform dark outlines,
  limited warm/cool palette, soft sky→horizon and road gradients, sun halo. No
  conflicting light sources observed; shading (belly, wing, attic) is consistent.
- Pose plausibility at sampled phases: wing tip reaches the handlebar grip; hips
  stay within the body silhouette; both feet remain coplanar with their pedals.

## Limitations / not verified

- Frame rate / motion smoothness was not measured (phase-correctness across sampled
  frames was verified; temporal smoothness is inferred).
- Crank angles were sampled at t=0, 1.5, 2.0, 4.0 (≈ θ = 0°, 207°, 248°, 317°);
  not every angle was visually checked, but the extremes (top/bottom of stroke) were
  and the IK is clamped with a deterministic knee choice.
- Side view: far wheel is not drawn separately from the near wheel (stylization).
- Crank/wheel speeds are an illustrative cadence, not a physical gear ratio.
- Plain CLI `Chromium --headless --screenshot --window-size=390,844` produced a
  wider-than-390 layout in one test (harness quirk, possibly cached profile); the
  Playwright-measured 390px viewport is the reliable result and was used for the
  final mobile verdicts.
- SCIENCE.md (solar-system reference) is unrelated to this pelican brief and is
  intentionally unused, as documented in README.
