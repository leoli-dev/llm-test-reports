# 鹈鹕骑车游香榭丽舍大道 · Pelican cycling on the Champs-Élysées

Original 2D vector artwork (hand-authored SVG, generated procedurally by this project's
own JavaScript) of a white pelican riding a red bicycle down the Champs-Élysées, with a
perspective tree-lined avenue, the Arc de Triomphe at the vanishing point, Haussmann
buildings, Parisian street lamps, bollards and a zebra crossing. Includes a looping
pedal/wheel animation driven by requestAnimationFrame.

## Launch

```bash
python3 -m http.server 4202 --bind 127.0.0.1
# open http://127.0.0.1:4202/
```

Port 4202 is the one assigned in `RUN.json`. Everything runs offline; no network,
no external fonts/images/CDN. `vendor/` (Three.js) is provided but not needed for this
2D piece and is not used. (SCIENCE.md references solar-system facts which are not
relevant to this pelican brief; it is intentionally unused.)

## Controls (visible, keyboard accessible)

| Control | Action |
|---|---|
| `⏸ 暂停 / ▶ 播放` button (or **Space**) | pause / play the pedaling animation |
| `↺ 重置` button (or **R**) | reset time to 0 |
| `⬇ 导出 PNG` button (or **P**) | download the current frame as 3200×1800 PNG |
| `⬇ 导出 SVG` button (or **S**) | download the current frame as standalone SVG |

All buttons are native `<button>` elements with visible labels and `aria-pressed` state;
keyboard shortcuts are ignored while a control is focused. `prefers-reduced-motion`
starts the piece paused. Test hook: `window.__BENCH__` exposes `getState()`,
`setTime(seconds)`, `play()`, `pause()`, `reset()` (animation only, no 3D camera).

## Coverage vs. brief

- **Pelican readability**: long orange bill with nostril, prominent throat pouch,
  head/eye/crest, white body, tail feathers, two webbed orange feet, wing extended to
  the handlebar grip.
- **Bicycle readability**: two spoked wheels, red frame (seat/chain/down/top tubes,
  seatstays), front fork, handlebar with grip, saddle, chain, chainring, cranks and
  pedals. Feet stay flat on the pedals via a small two-bone IK; body bobs with cadence.
- **Setting**: one-point perspective avenue converging on the Arc de Triomphe
  (attic plaque reads CHAMPS-ÉLYSÉES), converging rows of plane trees, Parisian lamps,
  Haussmann façades with zinc roofs/dormers/chimneys, shopfronts, curbs, bollards,
  dashed centerline, zebra crossing, sun and clouds.
- **Style**: consistent flat-illustration look — uniform dark outlines, limited
  warm/cool palette, layered depth (haze band behind the Arc), visual focus on the
  white pelican against the warm street.
- **Export**: real current-frame PNG (canvas rasterized from the live SVG) or SVG.
- **Responsive**: 1440×900 desktop and 390×844 mobile verified by screenshots. On
  narrow screens the SVG switches to a subject-framed viewport (`viewBox 420 0 640 900`,
  slice) so the artwork fills the phone screen; exports always contain the full
  1600×900 scene.

## Limitations

- Side-view stylization: the far wheel is not drawn separately from the near one.
- Animation cadence (crank/wheel ratios) is illustrative, not physical.
- No camera/scene presets (2D piece); `__BENCH__` therefore has no `cameraPreset`.
- PNG export is a single 2× raster (3200×1800); no zoom/pan editing.

See `VISUAL-NOTES.md` for what was actually inspected.
