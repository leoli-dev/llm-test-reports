# Visual / testing notes (what I actually saw)

All screenshots below were taken by me with Chromium (headless, the frozen
`tools/screenshot.cjs` plus my own `qa.cjs` for mobile/interaction cases), then read
back as images and used to fix defects. Captions describe what is visible in the
image, not what the code claims.

## Pass 1 — first build (shots/overview.png, 1440×900, preset overview, 09:11)

Seen: the plan, walls, hall, wings, corridors, pond, bridge, rockery, pavilion, bamboo,
trees and lantern poles were all present and recognisable. Defects clearly visible:

1. Long dark rods sticking out into the sky beside every roof — the eave-board tubes
   were offset twice (curve already at ±d/2, then the mesh was moved again).
2. Hip ridges and bridge slabs were mis-oriented (`lookAt` + ad-hoc rotations).
3. Labels overlapped into an unreadable pile in the middle of the frame.
4. The world outside the walls was the sky-dome gradient (tan), so the compound looked
   like a floating card.

Fixes: eave curve centred at z=0 with a single offset; quaternion alignment for hip
ridges and bridge slabs; nearest-first label decluttering with overlap suppression;
large outer ground plane.

## Pass 2 — element focus shots (shots/f_*.png)

* `f_detail.png` (hall from the garden): plaque 正心堂 and both couplets legible,
  columns with stone plinths, bracket sets under the eaves, latticed doors with gold
  studs, concave tile roof. Defect found: the eave upturn was far too strong
  (lift 0.36) — the roof read as a witch-hat. Reduced lift globally
  (hall 0.20, wings 0.13, corridors 0.09, gate 0.22, pavilion 0.34, wall caps 0.08)
  and thinned the eave boards.
* `f_moon.png`: **the 月洞门 partition wall was missing entirely** — only the two ring
  mouldings stood in the air. Cause: the circular hole (r 2.5 at y 2.05) exceeded the
  3.2 m wall panel, so `ExtrudeGeometry` produced degenerate triangulation. Raised the
  east panel to 4.7 m and shrank the opening to r 2.0 at y 2.35; the wall now renders
  with a clean circular opening and the ring mouldings sit inside it.
* `f_pond.png`: the bridge read as a staircase of separate planks, and the pond rim
  turned into a splayed fan of overlapping coping stones on the concave parts of the
  outline. Replaced the plank loop with a single deck swept along the arch
  (`ExtrudeGeometry` + `extrudePath`) plus joint grooves; reduced the outline wiggle
  and the coping-stone length. Water was a pale grey with contour-like squiggles —
  reduced the normal perturbation, saturated the deep/shallow colours, weakened the
  sky reflection.
* `f_wingE.png`: first attempt put the camera inside the wing roof; second attempt was
  blocked by the rockery pine. Final framing looks from the hall corner along the
  colonnade: columns, bracket sets, latticed bays, hanging lanterns and the corridor
  roof are all distinguishable.
* `f_screen.png`: the 影壁 was framed too tightly and the carved face was on the far
  side. Added the carved 静 panel to both faces and pulled the focus camera back.
* Shrub blobs were solid pink balls; changed to green shrubs with small blossom dots.

## Pass 3 — presets, night, mobile (shots/v_*.png, shots/mobile*.png)

* `v_overview.png` 09:11: whole compound legible; roofs read as curved tile roofs,
  courtyard层次 (walls → partition → garden → hall) is visible.
* `v_side.png`: the original side preset (50, 9, 2) looked at the outside face of the
  east wall — the courtyard was hidden. Raised/pulled it to (44, 15, 7); the section
  through gate court → garden → hall now reads.
* `v_gate.png`: 憩园 plaque, studded doors, drum stones, eave lanterns all visible.
* `v_night.png` (setTime 46 → 00:31): stars, moon, glowing lattice paper, lit lanterns,
  moonlight fill. The scene is dim but the layout is still readable.
* `mobile.png` / `mobile_closed.png` (390×844, dpr 1): the panel collapses to a bottom
  sheet behind the 控制 button; labels switch to short Chinese names and are clamped
  inside the viewport. A 404 console error (missing favicon) was removed with an inline
  `data:` icon; the last runs report **zero page errors and zero console errors**.
* Interaction check (`qa.cjs --drag 260 -60`): camera moved from (30, 27, 40) to
  (−50.7, 4.8, 22.4) — orbit works with the mouse; touch uses the same OrbitControls
  handlers (touch behaviour itself is inferred from the shared code path, not
  finger-tested on a real device).

## Hook check (script, not a visual claim)

`window.__BENCH__` exposes all six functions; `setTime(30)` → hour 19.2,
`pause()/play()` flip `playing`, `cameraPreset('overview'|'detail'|'side')` moves the
camera to the expected coordinates, an unknown name falls back to `overview`,
`reset()` returns time 0 / playing true / overview. `getState()` is JSON-serialisable.

## Still unverified / weak points (honest list)

* I did not verify real touch gestures on a physical phone, only the desktop mouse path
  and the mobile CSS layout.
* Water has no true reflection of the buildings — only sky/fresnel and sun specular.
* Frame rate on a real phone is not measured; the scene is a few hundred meshes with
  one 2048 shadow map and ≤10 point lights.
* Interior detail of the hall is only visible through the open colonnade bays; I saw
  the table/screen from outside, not a walkthrough view.

---

# Second pass: independent self-review of the current build

Harness: `review.cjs` (stages, playback, every visible control, desktop + 390 px),
`shots/allfocus.cjs` (all 16 element-focus cameras), `shots/touch.cjs` (CDP-level real
touch events), plus `tools/screenshot.cjs`. Every image below was opened and read.

## Animation stages (not one still) — shots/r_hour_*.png, shots/r2_hour_*.png

Slider-driven stages inspected at 05:12, 06:35, 09:12, 12:30, 17:23, 19:36, 22:30
(`getState().dayFactor` = 0, 0.68, 1, 1, 0.68, 0, 0). What the pixels showed:

* 05:12 / 22:30 — stars, moon, lit lattice paper, glowing lanterns, long black roof
  silhouettes. Plausible night, but roofs were near-pure black.
* 06:35 / 17:23 — long raking shadows across the paving, lanterns still partly lit,
  warm-ish ground. The sky stayed rather grey; the warm horizon band was barely visible.
* 12:30 — shadows almost directly under objects; the compound reads flat at noon.
* 19:36 — already full night: the day→night ramp was too abrupt (sun elevation reaches
  0° at 18:00 and dayFactor hit 0 by ~18:40).

Changes made: widened the twilight ramp (`dayF = (elevDeg+9)/30`), warmed the sun and
sky near the horizon, raised moonlight fill 0.35 → 0.45. Re-shot as `r2_hour_*.png`:
17:23 now shows a visibly warmer, lower sun and longer shadows; 19:36 is legitimately
night (sun 1.6 h below the horizon).

## Actual playback (not a still)

`reset()` then `play()`: clock 0.00 s → 2.00 s after 2 s wall time (speed ×1), i.e. the
sun/sky/water really advance; `pause()` froze the clock at 2.084 s across a further
1.2 s. `速度` button cycled ×3 → ×0.35 → ×1 as labelled. `r_play_t2.png` shows the
scene at 09:20 with the clock line updated — the UI text and the state agree.

## Visible controls exercised (desktop 1440×900)

* 总览/细节/侧面 buttons: camera moved to the expected coordinates and the renders
  (`r_btn_*.png`) match the names — overview = whole compound, detail = garden→hall
  axis, side = east elevation looking over the wall into the courtyard.
* 重置: time 0, playing true, preset overview.
* 标签: `aria-pressed` flips, the label layer's computed display goes `block → none →
  block`; `r_labels_off.png` confirms the scene is unobstructed.
* 收起清单/展开清单: list collapses, button text and `aria-expanded` follow.
* Wheel zoom: distance 55 → 36. Mouse drag orbit: camera (30,27,40) → (−31.8, 10.6, −24.3).
* All 21 checklist chips: each flies the camera to its element and highlights itself.

## Element-focus audit (shots/sheet_focus.png, sheet_focus2.png)

Good framing already: pond, pavilion (听雨亭 plaque legible), 影壁 (静 panel), 月洞门,
正门 (憩园 plaque), corridor, 窗棂 close-up, 木柱/斗拱, 曲线瓦屋顶 from above, garden,
bamboo, 家具/灯笼.

Bad framing found and fixed:

1. 假山 rockery — the camera sat under the corridor roof: the frame was a dark blur.
   New camera (1.2, 3.2, 1.6) → the rock cluster, its cliff pine and the moon gate
   behind it are now clearly readable.
2. 东厢/西厢 — the camera looked at the blank plaster end wall (a flat grey rectangle).
   New cameras look from the hall corner along the colonnade: columns, bracket sets,
   latticed bays and hanging lanterns are visible.
3. 院落动线 — the camera looked at empty paving. New higher camera shows the whole
   route: gate → apron → 影壁 → partition → garden → hall.

## Desktop vs 390 px

* 390×844 (`r_m_closed.png`, `r_m_open.png`, `final2_mobile.png`): panel is a bottom
   sheet behind 控制; labels switch to short Chinese names. Two real problems fixed:
   the panel covered 52 % of the screen (now 46 %, list capped at 132 px) and the
   portrait aspect cropped the focus/preset cameras, so e.g. the 假山 chip put the
   camera inside a roof. Focus and preset cameras now pull back when `aspect < 1.1`
   (`focusFrame()`), and the mobile detail preset frames the whole main hall.
* Label count is capped (15 desktop / 8 portrait) and stale off-screen labels are now
   cleared each frame — previously a label that left the frustum kept its last screen
   position, which produced ghost labels while panning.
* Real touch (CDP `Input.dispatchTouchEvent`, not synthetic events): one-finger drag
   orbited the camera (30,27,40) → (−8.9, 13.4, 53.7); two-finger pinch changed the
   orbit distance 55.5 → 85 (clamped by `maxDistance`, now 85 instead of 110 so the
   compound never becomes a postage stamp).
* Orbit polar clamp tightened to 0.44 π: previously a downward drag put the camera at
   y ≈ 3.6 outside the wall, where the screen was 100 % blank wall (`r_orbit.png`);
   the same drag now ends at y ≈ 10.6 and still shows the compound (`r2_loworbit.png`).

## Errors

Zero `pageerror` and zero console errors in every run of `review.cjs` (desktop +
mobile), `qa.cjs`, `shots/touch.cjs` and `shots/allfocus.cjs`.

## Honest limitations after this review

* The noon stage is still the flattest; the artwork looks best in the morning/late
  afternoon bands (the default clock is 09:12 for that reason).
* Water remains a shader surface: sky/fresnel + sun specular only, no building
  reflections; at noon it reads pale grey-green rather than deep.
* Focus cameras are hand-authored per element; they are framed for the current layout,
  not computed from bounding boxes, so a future geometry change can break them.
* Touch behaviour was verified through CDP touch events in Chromium, not on a physical
  phone; no frame-time measurement was taken on mobile hardware.
* Interior furniture is only observable through the open colonnade bays; there is no
  walk-through camera.

---

# Final verification pass

## Offline / integrity

* `grep -nE "https?://|cdn\.|googleapis|unpkg|jsdelivr|@import|fetch\(|XMLHttpRequest"`
  over `index.html` and `js/*.js` → no matches. All module imports resolve to `./js/*`
  or `../vendor/*` (the supplied Three.js build only).
* Every asset requested through the local server returned 200: `index.html`,
  `js/{main,materials,arch,buildings,nature,layout}.js`,
  `vendor/{three.module,three.core,OrbitControls}.js`. No 404s in the console.
* Pixel sanity on the captured frames (not a DOM claim): day overview 5 943 unique
  colours, mean RGB (127,129,125), σ 54; night overview 4 237 unique colours,
  mean (44,45,46), σ 24; mobile 390×844 4 944 unique colours, σ 54. Nothing blank or
  single-colour.

## Controls + hooks (re-run of `review.cjs` after the last edits)

Zero `pageerror` / console errors on desktop and mobile. Playback advanced 0 → 2.001 s
in 2 s and froze at 2.1 s after `pause()`. Speed button cycled ×3 → ×0.35 → ×1.
Label toggle flips `aria-pressed` and the layer's computed display. All 21 checklist
chips move the camera to their element. Wheel zoom and drag orbit verified.
`__BENCH__` returns a JSON-serialisable state with time/hour/playing/speed/preset/
labels/dayFactor/camera/target/elements/ready.

## Defects found and repaired in this pass

1. **An unexplained light source.** At night a warm glow lit the garden centre with no
   visible cause. Added a bronze brazier (stone foot, stem, bowl, emissive coals) on the
   walkway at (3.4, 0, −4.2) and moved the fire light onto it. Verified in
   `v_final_pond_night.png` — the lit bowl is now in frame and the glow reads as its
   light.
2. **Blown-out lanterns.** Night lantern bodies rendered cream-white. Emissive intensity
   1.9 → 1.15 and point-light intensity 9 → 6.5; `v_final_pond_night2.png` shows orange
   lantern bodies with the surrounding paving still legible.

## Composition re-checked after the changes

`v_final_day2.png` (detail, 09:11): main hall fills the frame with plaque 正心堂, both
couplets, studded doors, lattice bays, columns with stone plinths and bracket sets all
readable. `v_final_day.png` (overview) keeps the layered reading wall → partition →
garden → hall. Mobile `final2_mobile.png` frames the whole hall with short Chinese
labels. No frame showed a blank canvas, a clipped panel or an unreadable label pile.

## Requirement status (truthful)

Complete and visually verified: enclosing walls, main gate, moon gate, screen wall,
main hall, both side wings, covered corridors, pavilion, curved tile roofs, columns +
dougong, lattice windows, plaque + couplets, stone paving, pond water, arch bridge,
rockery, bamboo, trees/shrubs/flowers, furniture + lanterns, a usable courtyard
circulation, orbit/zoom/pan, reset, overview/detail/side presets, label toggle plus an
element checklist, day/night lighting with water and wind animation, mobile layout,
`__BENCH__` hooks, README and these notes.

Partial by design / not attempted: the water has no real reflections or refraction;
the dougong is a stylised stacked-bracket set rather than a rule-complete 斗拱 system;
there is no interior walk-through camera; mobile frame rate was never measured on real
hardware (only Chromium-emulated touch at 390×844, dpr 1).
