# 憩园 · 中国传统庭院 (real-time 3D)

Original browser artwork built with plain HTML/CSS/JS + the supplied local Three.js
vendor build (`vendor/three.module.js`, `vendor/three.core.js`, `vendor/OrbitControls.js`,
three r178). Every mesh, texture and inscription is authored in this repository — the
textures are generated procedurally with Canvas2D at runtime, no image/font/CDN fetch.

## Launch

```bash
python3 -m http.server 4205 --bind 127.0.0.1
# then open  http://127.0.0.1:4205/index.html
```

No build step, no network access required. `index.html` is the entry point.

## Files

| file | role |
|---|---|
| `index.html` | page shell, UI panel, accessible labels, styles |
| `js/main.js` | scene assembly, day/night cycle, camera presets, labels, UI, `window.__BENCH__` |
| `js/layout.js` | single source of the plan (dimensions of every building/element) |
| `js/materials.js` | procedural Canvas2D textures (stone, tile, plaster, brick, wood, flowers) + materials |
| `js/arch.js` | curved tile roofs, columns, dougong, lattice windows, doors, plaques/couplets, lanterns, arch bridge, pavilion |
| `js/buildings.js` | enclosing walls, main gate, screen wall, partition + moon gate, main hall, side wings, corridors, paving |
| `js/nature.js` | pond + water shader, rockery, trees, bamboo, shrubs, flower beds |
| `qa.cjs` | my own screenshot/interaction helper (not part of the artwork) |
| `shots/` | my own captured screenshots used for the visual review |

## Controls (visible UI)

* Orbit: left-drag / one finger. Zoom: wheel / pinch. Pan: right-drag / two fingers.
  (OrbitControls; polar angle clamped to 0.44 π and distance to 4–85 so you can never
  end up under the ground or staring at a blank outer wall.)
* 视角 VIEW: `总览 overview`, `细节 detail`, `侧面 side`, `重置 reset` (time + camera).
* 时刻 TIME: slider 0–24 h drives the sun/moon, sky gradient, shadows, lantern and
  window glow; `⏸ 暂停 / ▶ 播放` toggles the animation, `速度 ×1/×3/×0.35` the day speed.
* 标签: toggles the projected element labels (auto-decluttered, nearest first).
* 元素清单 ELEMENTS: every required element is a button; clicking it flies the camera
  to that element (element-check alternative to labels). Focus/preset cameras pull back
  automatically on portrait viewports so the subject is not cropped on a phone.
* Mobile (≤760 px): the panel collapses into a bottom sheet opened by the 控制 button.

## Test hooks

`window.__BENCH__` (available once the scene is built):

```js
getState()          // {time,hour,playing,speed,preset,labels,dayFactor,camera,target,elements,ready}
setTime(seconds)    // animation clock; 72 s = one full day, clock 0 s = 09:12
pause() / play() / reset()
cameraPreset(name)  // 'overview' | 'detail' | 'side' (unknown name → overview)
```

## Required-element coverage (all present as geometry, not as text claims)

围合院墙 (four walls with brick plinths + tiled caps) · 正门 (piers, lintel, tiled roof,
studded doors, drum stones, 憩园 plaque) · 月洞门 (extruded partition wall with a real
circular opening + ring mouldings) · 影壁 (framed screen wall, tiled cap, carved 静 panel
on both faces) · 主厅 (platform + steps, colonnade, hip roof, interior furniture) ·
两侧厢房 (east/west wings facing the courtyard, colonnade, desks/bed) · 连廊 (two covered
corridors with columns, dougong, lattice screens, hanging lanterns, plus links to the wings)
· 亭 (pavilion over the pond, plaque 听雨亭, table + stools) · 曲线瓦屋顶 (procedural
concave roof surfaces with upturned eaves, ridge caps, hip ridges, eave boards) ·
木柱/斗拱 (red columns on stone plinths, stacked bracket sets under every eave) ·
窗棂 (latticed windows/doors incl. diamond motifs, paper panels that glow at night) ·
匾额/对联 (正心堂 plaque, couplets 竹影横窗书有味 / 池光映座墨生香, 东厢/西厢, 憩园/静观) ·
石砖铺地 (procedural stone-brick ground + slab walkways) · 池水 (shader water with
ripples, fresnel, sun specular, lily pads) · 小桥 (stone arch bridge, swept deck, ribs,
railings) · 假山 (rock cluster with moss and a cliff pine) · 竹子 (three bamboo groves) ·
乔木/灌木/花卉 (broadleaf + plum + pine trees, shrubs with blossom dots, flower beds) ·
家具/灯笼 (hall table/chairs/screen/brush/vase, pavilion table + stools, wing desk + bed,
pole and hanging lanterns with point lights at night, a bronze brazier with
  glowing coals by the walkway that motivates the night fire glow) · 合理院落动线 (gate → apron →
detour past the 影壁 → partition opening or moon gate → bridge → pavilion → corridors →
hall steps).

## Offline verification

`grep` over `index.html` and `js/*.js` finds no `http(s)://`, CDN, `@import`,
`fetch` or `XMLHttpRequest` reference; every import resolves to `./js/*` or `../vendor/*`,
and all ten local files return HTTP 200 from the local server. The only textures are
Canvas2D canvases created at runtime, so the page renders with the network off.

## Limitations

* The architecture is a single self-consistent scheme (北方四合院 axis + 江南 garden
  inflection); it is not a historically exhaustive dougong/roof-class system.
* Water is a shader surface over a shallow basin: no real reflections, refraction or
  transparency into the basin beyond the tint.
* Shadow map is a single 2048 directional light; at night shadows are switched off and
  only lantern point lights remain (max ~10 lights, so a few lanterns are emissive only).
* Labels are screen-projected DOM text without depth occlusion; they are decluttered by
  distance instead of hidden behind buildings.
* `devicePixelRatio` is capped at 2 for frame-rate safety.
