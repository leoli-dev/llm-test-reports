# Scientific reference provided equally to all candidates
NASA Sun Facts: https://science.nasa.gov/sun/facts/
NASA Space Place: https://spaceplace.nasa.gov/solar-system-formation/en/
Checked2026-10-25. Paraphrase: about4.6billion years ago part of a giant rotating gas/dust cloud collapsed under gravity; most mass gathered toward the center, a rotating disk remained; compression made the protosun hotter/denser; sufficiently hot core sustains hydrogen-to-helium nuclear fusion, and the young Sun's outflow cleared much of the remaining gas/dust. The Sun is a stable main-sequence star. A nearby supernova as trigger is a hypothesis, not an established necessity. Stages are schematic and animation seconds are not physical timescales. No need for exact mass/duration claims beyond the brief.
