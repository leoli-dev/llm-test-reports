# CAP-04 evaluator assumptions and manual adjudications

## EVAL-01 — Pelican export button recognition (2026-10-26)

The first automatic collector searches export/download/save verbs, while MLTF's actual controls are labelled PNG and SVG with download-arrow icons. The v1 record therefore reports no export control without attempting the real existing buttons. This is a collector-selector assumption, not evidence that export fails. Preserve v1 unchanged. Uniform independent manual verification will test the actual visible export controls on all three pelican implementations, open the downloaded file and inspect the output. Final usability scores use that verified outcome; do not silently turn the untouched v1 record into a pass. Resolved: all three implementations downloaded valid PNG and SVG, both opened in Chromium and matched the illustrated scene. Actual output was visually reviewed; final export criteria receive full credit. Original v1 failure remains unchanged.

## EVAL-02 — Supplemental keyboard fixture (2026-10-26)

The first supplemental static server crashed on a missing favicon because its own handler lacked an existence check. Added a 404 path and reran all three courtyard keyboard flows uniformly; Enter selects side view and Space toggles labels in all three, without page errors. No candidate source was changed. This observer fixture failure is distinct from the model-authored MLTF self-test hang.

## EVAL-03 — Mobile viewport and pause interpretation

All nine fresh mobile pages include a viewport meta tag and report innerWidth=scrollWidth=390 under isMobile/hasTouch emulation. There is no missing-meta defect. Scene pause is judged by time/particle progression; a separately enabled automatic camera may continue. Real camera checks disable solar auto-camera before drag/wheel. Browser v1 seek frames wait only300ms; full real90-second playback frames are used as primary solar narrative evidence. No artwork source was changed.

## EVAL-04 — Publication figures and archive viewing

The initial report score-figure footnote and pressure-figure legend overlapped labels. Only plot layout was corrected; all measurements and artwork pixels remain unchanged. First archive deep-scroll screenshots were captured before scroll/paint settled and appeared blank. Archive verification v2 uses instant scrolling, waits500ms and asserts the actual heading position before taking the screenshot; original archive-ui evidence remains available. These are report-publication checks, not new model runs or candidate repairs.
