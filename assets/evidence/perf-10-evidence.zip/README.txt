PERF-10 finalized evidence. See the full bilingual report for methods and limits.

Requests, PNG fixtures and output text retain exact bytes; metadata/log paths are generalized and the battery identifier is omitted. Numeric measurements and content hashes are retained. Publication-manifest.json lists original/published hashes.

Harness audit: original PERF-06 source hashes are in harness-provenance.json. run_comparison.py uses LOCAL_LLMS_ROOT (default ~/local_llms), local compatible Splash/MLTF installations, the included fixtures and prepare_local_model assembly. Set harness/prepared-model-path.txt to the prepared assembly, generate a fresh private/api-key locally, and run with Splash Python. Do not copy any authentication from another machine. The template validator expects the pinned target in the documented model cache. Startup and model preparation are separate from timed requests.

Report generation scripts are source records; adjust local archive/evidence paths before reuse. No model weights, runtime environments, caches, credentials or private personal sessions are shipped.
