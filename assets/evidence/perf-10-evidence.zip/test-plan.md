# PERF-10: Splash GGUF Q8_0 follow-up

Two fresh server processes replay the original PERF-06 A/B 126,976-input-token image requests, reserving 4,096 output tokens in 131,072 total. Same Splash 1.4.0 commit/binary and BF16 DFlash2 draft as PERF-09; GGUF Q8_0 target plus BF16 mmproj instead of MLX affine8 checkpoint. Request bytes, sampler, reasoning OFF, 96G cap, int8 KV, fp32 recurrent state, no disk prefix cache, native default ANE, CPU preflight, cold-KV verification, 1Hz telemetry and post-request image recovery are unchanged. API model ID is a compatibility alias so original JSON stays byte-identical. Downloads/preparation/readiness excluded from HTTP timing. No cache purge, EOS suppression, failure retry or content adjustment.

PERF-09 results are earlier same-day references and are not rerun/interleaved in this follow-up. Distinct quantized weight values and vision tower precision preclude a pure file-format speed/quality claim. Two sampled tasks do not establish general quality or a statistically stable speed ranking. Preserve any short output, error or telemetry gap.

## 2026-10-21 header inspection clarification

The earlier MLX vision tower has 333 BF16 tensors and no quantized scales/biases; the GGUF projector has 110 BF16 and 224 F32 tensors. Do not describe the MLX vision tower as affine8. The initial precision wording above was imprecise. Actual target quantization and native paths still differ; exact visual weight equivalence is not established.
