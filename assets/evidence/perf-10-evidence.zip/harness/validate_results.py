"""Audit external inference evidence; never resubmit failed requests."""
from pathlib import Path
import hashlib,json,math
OUT=Path(__file__).resolve().parent
OLD=Path('$LOCAL_LLMS_ROOT/mltf/records/history/benchmarks/2026-10-19-mltf-comparison')
summary=json.loads((OUT/'summary.json').read_text());checks=[]
def check(name,passed,details=None):checks.append({'check':name,'passed':bool(passed),'details':details})
check('both result and server-exit records present',summary['complete_evidence'] and len(summary['runs'])==2)
check('fresh-process GGUF A/B order',summary['manifest']['order']==['gguf-1','gguf-2'])
for r in summary['runs']:
 name=r['run_id'];oldname='mltf-1' if r['label']=='128k' else 'mltf-2'
 v=json.loads((OUT/name/'request-validation.json').read_text());previous=json.loads((OLD/oldname/'request-validation.json').read_text())
 check(name+' original request bytes',r['request_sha256']==hashlib.sha256((OLD/oldname/(r['label']+'-request.json')).read_bytes()).hexdigest())
 for field in ['formatted_prompt_sha256','token_ids_sha256','expanded_token_ids_sha256']:
  check(name+' historical '+field,v.get(field)==previous.get(field),v.get(field))
 check(name+' input and window budget',r['usage'].get('prompt_tokens')==126976 and r['usage'].get('total_tokens',0)<=131072)
 check(name+' requested output and sampling',v['requested_output_tokens']==4096 and v['requested_sampling']=={'temperature':1.0,'top_p':.95,'top_k':20})
 check(name+' cold KV',r['cache_matched_tokens']==0)
 check(name+' mechanical long decode',r['functional_long_decode_passed'],r['errors'])
 check(name+' full 4096 output',r['completed_requested4096'],r['usage'].get('completion_tokens'))
 check(name+' main image and recovery',r['vision_correct'] and r['recovery_correct'])
 check(name+' delivery rate recomputation',math.isclose(r['client_content_span_tok_s'],r['usage']['completion_tokens']/r['client_content_span_seconds'],rel_tol=1e-9))
 check(name+' per-second telemetry coverage',r['request_resources']['sample_count']>0 and not r['request_resources']['telemetry_error_counts'],r['request_resources']['telemetry_error_counts'])
 points=[]
 start=r['phase_boundaries']['request_start'];finish=r['phase_boundaries']['request_finish']
 for line in (OUT/name/'resources.jsonl').read_text().splitlines():
  item=json.loads(line);stamp=item.get('unix_seconds')
  if stamp is not None and start<=stamp<=finish:points.append(stamp)
 max_gap=max((b-a for a,b in zip(points,points[1:])),default=None)
 check(name+' nominal 1Hz sample density',len(points)>=r['wall_seconds']*.9,{'samples':len(points),'wall_seconds':r['wall_seconds'],'maximum_sample_gap_seconds':max_gap})
 pressure=r['request_resources']['pressure_counts'];check(name+' no warning/critical memory pressure',not pressure.get('warn',0) and not pressure.get('critical',0),pressure)
 check(name+' command counters isolated before main request',(r.get('native_command_metrics_before') or {}).get('prefill_input_tokens')==0 and (r.get('native_command_metrics_before') or {}).get('decode_output_tokens')==0)
 check(name+' no process restart',r['native_counter_deltas'].get('transport_restarts')==0)
check('both exact historical fixture hashes verified',len({r['request_sha256'] for r in summary['runs']})==2)
model=json.loads((OUT/'prepared-model-manifest.json').read_text())
check('prepared actual target is GGUF Q8_0, regardless of API alias',model.get('target_format')=='gguf' and model.get('model','').endswith('/Qwen3.8-27B-Q8_0.gguf'))
verified=json.loads((OUT/'download-verification.json').read_text())
check('all available pinned LFS hashes match',all(f['lfs_matches'] for m in verified['models'] for f in m['files'] if f.get('hub_lfs_sha256')))
inspection=json.loads((OUT/'quantization-inspection.json').read_text())
check('downloaded target header has only expected Q8_0/F32 types',inspection['Qwen3.8-27B-Q8_0.gguf']['ggml_type_id_counts']=={'8':506,'0':360})
(OUT/'validation.json').write_text(json.dumps({'checks':checks,'all_passed':all(c['passed'] for c in checks),'note':'Failures remain reportable evidence; no success-only resubmission is performed.'},indent=2)+'\n')
print(json.dumps({'checks':len(checks),'passed':sum(c['passed'] for c in checks),'failed':[c['check'] for c in checks if not c['passed']]}))
