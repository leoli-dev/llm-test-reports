"""Offline plots from summarize_comparison.py outputs; no inference imports.

Writes comparison-performance.png, comparison-resources.png and
comparison-delivery.png. Run the summarizer once more afterward to embed PNGs.
"""
from __future__ import annotations

import csv
import json
import math
from pathlib import Path

OUT = Path(__file__).resolve().parent
GIB = 2**30
COLORS = {'splash': '#257852', 'mlx-ref': '#275f8e', 'mltf-ref': '#ac5c3b'}


def value(row, key):
    try:
        result = float(row[key])
        return result if math.isfinite(result) else None
    except (KeyError, TypeError, ValueError):
        return None


def main() -> None:
    summary = json.loads((OUT / 'summary.json').read_text())
    cases = summary.get('runs') or []
    if not cases:
        raise SystemExit('No run rows in summary.json.')
    if any(case.get('result_present') and not case.get('server_exit') for case in cases):
        raise SystemExit('Wait for each started server to stop before plotting.')
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib.lines import Line2D
    from matplotlib.patches import Patch
    plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 9,
                         'axes.titlesize': 11, 'axes.labelsize': 9,
                         'axes.spines.top': False, 'axes.spines.right': False,
                         'axes.edgecolor': '#9b9b9b', 'grid.color': '#d9dde2',
                         'grid.alpha': .65, 'grid.linewidth': .5,
                         'figure.facecolor': 'white', 'axes.facecolor': 'white'})
    measured_cases = cases
    reference=json.loads((OUT.parent/'2026-10-21-perf06-replay/summary.json').read_text())
    refs=[]
    for r in reference['runs']:
        r=dict(r);r['backend']='mlx-ref' if r['backend']=='splash' else 'mltf-ref';r['run_id']='earlier '+r['run_id'];refs.append(r)
    cases=refs+measured_cases
    labels = [('MLX' if c['backend']=='mlx-ref' else 'MLTF' if c['backend']=='mltf-ref' else 'GGUF')+' '+('A' if c['label']=='128k' else 'B')+'\n'+('earlier' if c['backend'].endswith('-ref') else 'new') for c in cases]
    fig, axes = plt.subplots(1, 4, figsize=(17.5, 4.4))
    for ax, (key, title, unit) in zip(axes, (
            ('client_ttft_seconds', 'Client time to first content', 'Seconds; lower is faster'),
            ('wall_seconds', 'Complete request duration', 'Seconds; lower is faster'),
            ('client_content_span_tok_s', 'Output tokens / first-last content span', 'Tokens/s; higher is faster'),
            ('client_end_to_end_generation_tok_s', 'Output tokens / complete duration', 'Tokens/s; higher is faster'))):
        for i, case in enumerate(cases):
            metric = value(case, key)
            if metric is not None:
                bar = ax.bar(i, metric, color=COLORS.get(case['backend'], '#777777'), width=.64)
                if case.get('functional_long_decode_passed') is not True:
                    bar[0].set_hatch('//')
                ax.annotate(f'{metric:.2f}', (i, metric), xytext=(0, 4), textcoords='offset points', ha='center', fontsize=9)
            else:
                ax.annotate('missing', (i, .02), xycoords=('data', 'axes fraction'), ha='center', color='#777777', fontsize=8)
        ax.set_title(title)
        ax.set_ylabel(unit)
        ax.set_xticks(range(len(cases)), labels)
        ax.grid(axis='y'); ax.set_axisbelow(True)
        ax.set_ylim(bottom=0)
        lower, upper = ax.get_ylim(); ax.set_ylim(lower, upper * 1.13)
    fig.suptitle('Qwen3.8-27B vision, 128K: GGUF Q8_0 follow-up', x=.06, y=.99, ha='left', fontsize=15, weight='bold')
    fig.text(.06, .91, 'Same request bytes and INT8 KV. Blue/brown: earlier PERF-09 references, not interleaved reruns. Green: new GGUF Q8_0 A/B; numerically different weights.', fontsize=9, color='#555e68')
    fig.legend(handles=[Patch(facecolor=COLORS[key], label={'splash':'GGUF Q8_0 (new)','mlx-ref':'Splash MLX8 (earlier)','mltf-ref':'MLTF (earlier)'}[key]) for key in ('mlx-ref', 'mltf-ref', 'splash')] + [Patch(facecolor='white', edgecolor='#777777', hatch='//', label='Long-decode coverage not passed')], loc='lower center', ncol=3, frameon=False)
    fig.subplots_adjust(left=.06, right=.99, top=.79, bottom=.22, wspace=.32)
    fig.savefig(OUT / 'comparison-performance.png', dpi=180); plt.close(fig)

    cases=measured_cases
    with (OUT / 'merged-per-second.csv').open(newline='') as file:
        rows = list(csv.DictReader(file))
    selected = {case['run_id']: [row for row in rows if row['run_id'] == case['run_id'] and value(row, 'seconds_from_request_start') is not None and value(row, 'seconds_from_request_start') >= 0] for case in cases}
    cpu_series = (('process_cpu_percent', '#275f8e', 'Engine CPU: 100% = one core', '-'),
                  ('process_tree_cpu_percent', '#6a75a9', 'Process-tree CPU: 100% = one core', '--'),
                  ('system_cpu_percent', '#ac5c3b', 'System CPU: 100% = all cores', '-'))
    memory_series = (('process_physical_footprint_bytes', '#8d4d96', 'Engine physical footprint', '-'),
                     ('process_rss_bytes', '#275f8e', 'Engine RSS', ':'),
                     ('frontend_physical_footprint_bytes', '#bb693b', 'Python frontend footprint', '--'),
                     ('engine_allocated_bytes', '#398a49', 'Native memory_actual current', '-'),
                     ('swap_used_bytes', '#bf3c4a', 'System swap', ':'))
    all_rows = [row for run_rows in selected.values() for row in run_rows]
    cpu_max = max((value(row, key) for row in all_rows for key, *_ in cpu_series if value(row, key) is not None), default=100)
    memory_max = max((value(row, key) / GIB for row in all_rows for key, *_ in memory_series if value(row, key) is not None), default=1)
    max_seconds = max((value(row, 'seconds_from_request_start') for row in all_rows), default=1)
    fig, axes = plt.subplots(3, len(cases), figsize=(max(14,3.85 * len(cases)), 9.2), squeeze=False, sharey='row', sharex=True)
    for column, case in enumerate(cases):
        current = selected[case['run_id']]
        boundary = case['phase_boundaries']
        start, first, finish = (boundary.get(key) for key in ('request_start', 'client_first_content', 'request_finish'))
        def line(ax, key, color, scale=1, style='-'):
            if any(value(row, key) is not None for row in current):
                ax.plot([value(row, 'seconds_from_request_start') for row in current],
                        [value(row, key) / scale if value(row, key) is not None else math.nan for row in current],
                        color=color, ls=style, lw=1.1)
        for key, color, _, style in cpu_series:
            line(axes[0, column], key, color, style=style)
        line(axes[1, column], 'gpu_device_utilization_percent', '#257852')
        for key, color, _, style in memory_series:
            line(axes[2, column], key, color, GIB, style)
        for ax in axes[:, column]:
            ax.grid(True); ax.set_axisbelow(True)
            ax.set_xlim(0, max_seconds * 1.01)
            if start is not None and first is not None:
                ax.axvspan(0, first - start, color='#d7e5f3', alpha=.5, zorder=-1)
            if start is not None and finish is not None:
                ax.axvline(finish - start, color='#59616b', ls=':', lw=.9)
            if not current:
                ax.text(.5, .5, 'No request samples', transform=ax.transAxes, ha='center')
        axes[0, column].set_title(case['run_id'] + ': ' + case['backend'] + '\n' + case['label'])
        axes[0, column].set_ylim(0, max(100, cpu_max) * 1.08)
        axes[1, column].set_ylim(0, 105)
        axes[2, column].set_ylim(0, max(1, memory_max) * 1.06)
        axes[2, column].set_xlabel('Seconds after HTTP request start')
    axes[0, 0].set_ylabel('CPU utilization (%)')
    axes[1, 0].set_ylabel('Global GPU busy (%)')
    axes[2, 0].set_ylabel('Unified-memory measures (GiB)')
    handles = [Line2D([0], [0], color=color, lw=1.5, ls=style, label=label) for _, color, label, style in cpu_series]
    handles += [Line2D([0], [0], color='#257852', lw=1.5, label='Global GPU busy')]
    handles += [Line2D([0], [0], color=color, lw=1.5, ls=style, label=label) for _, color, label, style in memory_series]
    fig.legend(handles=handles, loc='lower center', bbox_to_anchor=(.5, .005), ncol=4, frameon=False, fontsize=8)
    fig.suptitle('GGUF Q8_0: engine resources at one-second sampling', x=.055, y=.985, ha='left', fontsize=15, weight='bold')
    fig.text(.055, .945, 'Shared axes. Shading: before first content; dotted: request end; later: recovery. OS / allocator memory scopes differ; overlap; do not add or infer total-RAM savings.', fontsize=9, color='#555e68')
    fig.subplots_adjust(left=.08, right=.99, top=.895, bottom=.17, hspace=.28, wspace=.25)
    fig.savefig(OUT / 'comparison-resources.png', dpi=180); plt.close(fig)

    fig, axes = plt.subplots(1, len(cases), figsize=(max(11,3.85 * len(cases)), 4.6), squeeze=False, sharey=True, sharex=True)
    max_gap, max_decode_seconds = 5, 1
    for column, case in enumerate(cases):
        ax = axes[0, column]
        first = case['phase_boundaries'].get('client_first_content')
        gaps = case.get('stream_delivery', {}).get('gaps') or []
        points = [(row['unix_seconds'] - first, row['gap_seconds']) for row in gaps if first is not None and value(row, 'gap_seconds') is not None and row['gap_seconds'] > 0]
        if points:
            ax.plot([row[0] for row in points], [row[1] for row in points], '.', ms=2, color=COLORS.get(case['backend'], '#777777'), alpha=.65)
            max_gap = max(max_gap, max(row[1] for row in points))
            max_decode_seconds = max(max_decode_seconds, max(row[0] for row in points))
        else:
            ax.text(.5, .5, 'No content gaps', transform=ax.transAxes, ha='center')
        ax.axhline(2, color='#bd9120', ls='--', lw=.8)
        ax.axhline(5, color='#b83d40', ls='--', lw=.8)
        ax.set_yscale('log'); ax.grid(True, which='major'); ax.set_axisbelow(True)
        ax.set_title(case['run_id'] + '\n' + case['backend'])
        ax.set_xlabel('Seconds after first nonempty content')
    axes[0, 0].set_ylim(1e-5, max_gap * 1.5)
    axes[0, 0].set_xlim(0, max_decode_seconds * 1.01)
    axes[0, 0].set_ylabel('Seconds since preceding content chunk (log scale)')
    fig.suptitle('GGUF Q8_0: observed SSE content delivery gaps', x=.055, y=.985, ha='left', fontsize=15, weight='bold')
    fig.text(.055, .89, 'Speculative blocks and buffering produce bursts. These are delivery intervals, not exact per-token latency. Dashed: 2s / 5s.', fontsize=9, color='#555e68')
    fig.subplots_adjust(left=.08, right=.99, top=.76, bottom=.16, wspace=.25)
    fig.savefig(OUT / 'comparison-delivery.png', dpi=180); plt.close(fig)
    for name in ('comparison-performance.png', 'comparison-resources.png', 'comparison-delivery.png'):
        print(OUT / name)


if __name__ == '__main__':
    main()
