"""Verify pinned GGUF/projector/draft weights before timed inference."""
from pathlib import Path
import hashlib,json,sys
ROOT=Path('$LOCAL_LLMS_ROOT'); OUT=Path(__file__).resolve().parent
CACHE=ROOT/'models/splash/huggingface/hub'; UPSTREAM=ROOT/'splash/records/research/2026-10-21/upstream'
sys.path.insert(0,str(ROOT/'splash/source'))
from install.local import prepare_local_model
records=[];paths=[]
for repo,names in [('unsloth/Qwen3.8-27B-GGUF',['Qwen3.8-27B-Q8_0.gguf','mmproj-BF16.gguf']),('incoai/Qwen3.8-27B-DFlash2',['model.safetensors','config.json'])]:
 info=json.loads((UPSTREAM/repo.replace('/','--')/'repo-info.json').read_text()); path=CACHE/('models--'+repo.replace('/','--'))/'snapshots'/info['sha']; files=[]
 for name in names:
  item=next(i for i in info['siblings'] if i['rfilename']==name); source=path/name; h=hashlib.sha256()
  with source.open('rb') as f:
   for block in iter(lambda:f.read(8*1024**2),b''):h.update(block)
  expected=(item.get('lfs') or {}).get('sha256');actual=h.hexdigest()
  assert source.stat().st_size==item['size'],source
  if expected:assert actual==expected,source
  files.append({'path':name,'size':source.stat().st_size,'sha256':actual,'hub_lfs_sha256':expected,'lfs_matches':actual==expected if expected else None})
 records.append({'repo':repo,'revision':info['sha'],'snapshot':str(path),'files':files});paths.append(path)
 print('Verified',repo,flush=True)
(OUT/'download-verification.json').write_text(json.dumps({'models':records,'draft_weights_same_as_perf09':True},indent=2)+'\n')
prepared=prepare_local_model(paths[0]/'Qwen3.8-27B-Q8_0.gguf',draft=paths[1],mmproj=paths[0]/'mmproj-BF16.gguf',models_dir=ROOT/'models/splash/installations')
(OUT/'prepared-model-path.txt').write_text(str(prepared)+'\n')
print('Prepared',prepared,flush=True)
