"""Offline MLTF/MLX-VLM comparison report. No model/server imports or inference.

Read runs.json and its immutable per-run evidence, then write report.md,
summary.json, summary.csv and merged-per-second.csv. By default every planned
run needs a result and server-exit record. --allow-partial documents failures.
"""
from __future__ import annotations

import argparse
from bisect import bisect_left
from collections import Counter
import csv
from datetime import datetime
import hashlib
import json
import math
from pathlib import Path
import statistics
from typing import Any
from zoneinfo import ZoneInfo

OUT = Path(__file__).resolve().parent
GIB = 2**30
RESOURCE_KEYS = (
    'process_cpu_percent', 'system_cpu_percent', 'gpu_device_utilization_percent',
    'process_rss_bytes', 'process_physical_footprint_bytes', 'frontend_cpu_percent',
    'frontend_rss_bytes', 'frontend_physical_footprint_bytes', 'process_tree_cpu_percent',
    'process_tree_rss_sum_bytes', 'process_tree_physical_footprint_sum_bytes',
    'gpu_alloc_system_memory_bytes', 'gpu_in_use_system_memory_bytes',
    'mlx_active_bytes', 'mlx_cache_bytes', 'mlx_peak_bytes',
    'engine_allocated_bytes', 'engine_allocation_peak_bytes', 'swap_used_bytes',
)


def number(value: Any) -> bool:
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


def get(data: Any, *keys: str, default=None):
    for key in keys:
        if not isinstance(data, dict):
            return default
        data = data.get(key)
    return default if data is None else data


def first(*values):
    return next((value for value in values if value is not None), None)


def read_json(path: Path, default=None):
    return json.loads(path.read_text()) if path.is_file() else default


def read_jsonl(path: Path) -> tuple[list[dict], list[str]]:
    if not path.is_file():
        return [], [f'missing {path.name}']
    rows, errors = [], []
    for n, line in enumerate(path.read_text().splitlines(), 1):
        if not line.strip():
            continue
        try:
            row = json.loads(line)
            if not isinstance(row, dict):
                raise ValueError('row is not an object')
            rows.append(row)
        except (json.JSONDecodeError, ValueError) as exc:
            errors.append(f'{path.name}:{n}: {exc}')
    return rows, errors


def stats(values: list) -> dict:
    valid = [value for value in values if number(value)]
    return {'mean': statistics.mean(valid) if valid else None,
            'min': min(valid) if valid else None, 'peak': max(valid) if valid else None,
            'valid_count': len(valid), 'missing_count': len(values) - len(valid)}


def summarize_rows(rows: list[dict]) -> dict:
    errors, messages, process_errors = Counter(), Counter(), Counter()
    for row in rows:
        for key, value in (row.get('errors') or {}).items():
            errors[key] += 1
            messages[f'{key}: {value}'] += 1
        for key, value in (row.get('allocator_errors') or {}).items():
            errors['allocator.' + key] += 1
            messages[f'allocator.{key}: {value}'] += 1
        for proc in row.get('processes') or []:
            for key in (proc.get('errors') or {}):
                process_errors[key] += 1
    return {'sample_count': len(rows),
            'metrics': {key: stats([row.get(key) for row in rows]) for key in RESOURCE_KEYS},
            'pressure_counts': dict(Counter(first(row.get('memory_pressure_name'), row.get('pressure'), 'unknown') for row in rows)),
            'telemetry_error_counts': dict(errors), 'telemetry_error_messages': dict(messages),
            'process_roster_error_counts': dict(process_errors),
            'native_status_stale_samples': sum(row.get('native_status_stale') is True for row in rows),
            'native_status_callback_failed_samples': sum(row.get('native_status_callback_failed') is True for row in rows),
            'native_status_missing_samples': sum(row.get('native_status') is None for row in rows),
            'allocator_unmatched_samples': sum(row.get('backend') == 'mlx-vlm' and not number(row.get('allocator_join_offset_seconds')) for row in rows)}


def request_start(result: dict) -> tuple[float | None, str]:
    # The runner's started_unix_seconds precedes health/metrics snapshots. Its
    # monotonic TTFT starts immediately before HTTP streaming, so project that
    # measured interval onto the first-content Unix clock for fair phases.
    first_content, ttft = result.get('first_content_unix_seconds'), result.get('client_ttft_seconds')
    if number(first_content) and number(ttft):
        return first_content - ttft, 'first_content_unix_seconds - client_ttft_seconds'
    finish, wall = result.get('finished_unix_seconds'), result.get('wall_seconds')
    if number(finish) and number(wall):
        return finish - wall, 'finished_unix_seconds - wall_seconds'
    return result.get('started_unix_seconds'), 'started_unix_seconds fallback (includes pre-request health snapshots)'


def merge_samples(rows: list[dict], allocator: list[dict], result: dict, run: dict) -> list[dict]:
    allocator = sorted((row for row in allocator if row.get('type') == 'allocator_sample' and number(row.get('unix_seconds'))), key=lambda row: row['unix_seconds'])
    times = [row['unix_seconds'] for row in allocator]
    start = request_start(result)[0]
    first_content, finish = (result.get(key) for key in ('first_content_unix_seconds', 'finished_unix_seconds'))
    merged = []
    for original in rows:
        row = dict(original)
        row.update(run_id=run['id'], backend=run['backend'], case_label=run['_case_label'],
                   raw_phase=row.get('phase'), allocator_join_offset_seconds=None,
                   allocator_errors={}, mlx_active_bytes=None, mlx_cache_bytes=None, mlx_peak_bytes=None)
        t = row.get('unix_seconds')
        if number(t) and times:
            i = bisect_left(times, t)
            candidates = [allocator[j] for j in (i - 1, i) if 0 <= j < len(allocator)]
            candidates = [candidate for candidate in candidates if candidate.get('pid') == row.get('pid')]
            if candidates:
                nearest = min(candidates, key=lambda candidate: abs(candidate['unix_seconds'] - t))
                offset = nearest['unix_seconds'] - t
                if abs(offset) <= 1.5:
                    row['allocator_join_offset_seconds'] = offset
                    row['allocator_errors'] = nearest.get('errors') or {}
                    for key in ('mlx_active_bytes', 'mlx_cache_bytes', 'mlx_peak_bytes'):
                        row[key] = nearest.get(key)
        row['phase'] = 'outside_request'
        if number(t) and number(start):
            if t < start:
                row['phase'] = 'startup'
            elif number(first_content) and start <= t < first_content:
                row['phase'] = 'before_first_content'
            elif number(first_content) and number(finish) and first_content <= t <= finish:
                row['phase'] = 'content_delivery'
            elif number(finish) and start <= t <= finish:
                row['phase'] = 'request_without_content'
            elif number(finish) and t > finish:
                row['phase'] = 'recovery_and_idle'
        row['seconds_from_request_start'] = t - start if number(t) and number(start) else None
        merged.append(row)
    return merged


def point(row: dict | None, reference: float | None) -> dict | None:
    if not row:
        return None
    keys = ('unix_seconds', 'phase', 'memory_pressure_name', 'pressure', 'swap_used_bytes',
            'process_rss_bytes', 'process_physical_footprint_bytes', 'mlx_active_bytes',
            'mlx_cache_bytes', 'mlx_peak_bytes', 'engine_allocated_bytes', 'engine_allocation_peak_bytes')
    out = {key: row.get(key) for key in keys}
    out['offset_from_reference_seconds'] = row['unix_seconds'] - reference if number(reference) else None
    return out


def stream_delivery(path: Path) -> tuple[dict, list[str]]:
    rows, errors = read_jsonl(path)
    points = []
    for row in rows:
        chunk = row.get('chunk') or {}
        content = ''.join(get(choice, 'delta', 'content', default='') or '' for choice in chunk.get('choices') or [])
        if content and number(row.get('received_unix_seconds')):
            points.append({'unix_seconds': row['received_unix_seconds'],
                           'relative_seconds': row.get('relative_seconds'), 'content_characters': len(content)})
    gaps = [{'unix_seconds': after['unix_seconds'], 'relative_seconds': after.get('relative_seconds'),
             'gap_seconds': after['unix_seconds'] - before['unix_seconds']}
            for before, after in zip(points, points[1:])]
    return {'content_chunk_count': len(points), 'gaps': gaps,
            'max_gap_seconds': max((row['gap_seconds'] for row in gaps), default=None),
            'over_2s': sum(row['gap_seconds'] > 2 for row in gaps),
            'over_5s': sum(row['gap_seconds'] > 5 for row in gaps)}, errors


def summarize_case(base: Path, run: dict, result_path: str) -> tuple[dict, list[dict]]:
    result = read_json(base / result_path, {})
    metadata = dict(run.get('metadata') or {})
    metadata.update(result.get('metadata') or {})
    backend, run_id, label = run['backend'], run['id'], run['_case_label']
    directory = run.get('directory', run_id)
    request_path = base / directory / f'{label}-request.json'
    actual_request_sha = hashlib.sha256(request_path.read_bytes()).hexdigest() if request_path.is_file() else None
    latest = get(result, 'metrics_after', 'latest', default={})
    timings = first(result.get('timings'), get(result, 'terminal_chunk', 'timings'), {})
    usage = first(result.get('usage'), get(result, 'terminal_chunk', 'usage'), {})
    native_metrics = first(result.get('backend_metrics'), get(result, 'terminal_chunk', 'metrics'), {})
    client_span = result.get('client_content_span_seconds')
    if client_span is None and number(result.get('last_content_unix_seconds')) and number(result.get('first_content_unix_seconds')):
        client_span = result['last_content_unix_seconds'] - result['first_content_unix_seconds']
    completion = usage.get('completion_tokens')
    wall = result.get('wall_seconds')
    before, after = (result.get(key) or {} for key in ('server_status_before', 'server_status_after'))
    native_diagnostics = {}
    if backend in ('mltf', 'splash'):
        for key, path in (('image_encodes', ('images', 'encodes')),
                          ('denied_reservations', ('memory_governor', 'denied_reservations')),
                          ('transport_restarts', ('transport', 'restarts')),
                          ('requests_failed', ('requests', 'failed'))):
            a, b = get(before, *path), get(after, *path)
            native_diagnostics[key] = {'before': a, 'after': b,
                                       'delta': b - a if number(a) and number(b) else None}
        native_diagnostics.update(ready_after=after.get('ready'), metal_healthy_after=get(after, 'metal', 'healthy'))
    resources_path = run.get('resources', f'{directory}/resources.jsonl')
    resources, parse_errors = read_jsonl(base / resources_path)
    allocator_path = run.get('allocator')
    allocator, allocator_errors = read_jsonl(base / allocator_path) if allocator_path else ([], [])
    merged = merge_samples(resources, allocator, result, run)
    request_rows = [row for row in merged if row['phase'] in ('before_first_content', 'content_delivery', 'request_without_content')]
    timed = sorted((row for row in merged if number(row.get('unix_seconds'))), key=lambda row: row['unix_seconds'])
    start, start_source = request_start(result)
    finish = result.get('finished_unix_seconds')
    baselines = [row for row in timed if number(start) and row['unix_seconds'] <= start]
    endpoints = [row for row in timed if number(finish) and row['unix_seconds'] <= finish]
    baseline, endpoint = (baselines[-1] if baselines else None), (endpoints[-1] if endpoints else None)
    tail = timed[-1] if timed else None
    swap_delta = endpoint['swap_used_bytes'] - baseline['swap_used_bytes'] if baseline and endpoint and number(baseline.get('swap_used_bytes')) and number(endpoint.get('swap_used_bytes')) else None
    recovery_swap_delta = tail['swap_used_bytes'] - baseline['swap_used_bytes'] if baseline and tail and number(baseline.get('swap_used_bytes')) and number(tail.get('swap_used_bytes')) else None
    phases = {phase: summarize_rows([row for row in merged if row['phase'] == phase])
              for phase in ('before_first_content', 'content_delivery', 'request_without_content', 'recovery_and_idle')}
    request_resources = summarize_rows(request_rows)
    stream_path = f'{directory}/{label}-stream.jsonl'
    delivery, stream_errors = stream_delivery(base / stream_path) if (base / stream_path).is_file() else ({}, ['missing stream'])
    pressure = request_resources['pressure_counts']
    flags = []
    functional = result.get('functional_long_decode_passed')
    if functional is not True:
        flags.append('长 decode 覆盖未通过或未完成')
    if actual_request_sha and metadata.get('payload_sha256') and actual_request_sha != metadata['payload_sha256']:
        flags.append('保存的请求 SHA256 与运行元数据不符')
    if result.get('vision_correct') is False:
        flags.append('主回答图片识别失败')
    if result.get('recovery_correct') is not True:
        flags.append('短图片恢复未通过或未完成')
    if pressure.get('warn') or pressure.get('critical'):
        flags.append('请求期间出现内存压力告警')
    if number(swap_delta) and swap_delta > 0:
        flags.append('请求期间系统 swap 增加')
    if get(result, 'chunk_gaps', 'over_5s', default=0) or delivery.get('over_5s', 0):
        flags.append('正文 SSE 出现 >5s 交付间隔')
    elif get(result, 'chunk_gaps', 'over_2s', default=0) or delivery.get('over_2s', 0):
        flags.append('正文 SSE 出现 >2s 交付间隔')
    if request_resources['telemetry_error_counts']:
        flags.append('请求期间存在遥测错误（详见计数）')
    if request_resources['native_status_stale_samples']:
        flags.append('请求期间存在 native status 缓存快照')
    if not request_rows:
        flags.append('没有可归入主请求的资源样本')
    peak_resets = []
    for a, b in zip(merged, merged[1:]):
        for key in ('mlx_peak_bytes', 'engine_allocation_peak_bytes'):
            if a.get('pid') == b.get('pid') and number(a.get(key)) and number(b.get(key)) and b[key] < a[key]:
                peak_resets.append({'field': key, 'unix_seconds': b.get('unix_seconds'), 'before': a[key], 'after': b[key]})
    if peak_resets:
        flags.append('观察到 allocator 累计 peak 回退 / 重置')
    if get(native_diagnostics, 'denied_reservations', 'delta', default=0) > 0:
        flags.append('MLTF memory governor 出现 reservation 拒绝')
    run_error = read_json(base / directory / 'run-error.json')
    if run_error:
        flags.append('运行失败记录已保存')
    prompt_ms = timings.get('prompt_ms')
    decode_ms = timings.get('predicted_ms')
    backend_timing = {
        'prompt_seconds': (latest.get('prompt_eval_time_s') if backend == 'mlx-vlm' else prompt_ms / 1000 if number(prompt_ms) else None),
        'prompt_tok_s': first(latest.get('prefill_tok_s'), timings.get('prompt_per_second')) if backend == 'mlx-vlm' else timings.get('prompt_per_second'),
        'decode_seconds': latest.get('decode_elapsed_s') if backend == 'mlx-vlm' else get(native_metrics, 'request_latency', 'first_token_to_done_ms') / 1000 if number(get(native_metrics, 'request_latency', 'first_token_to_done_ms')) else decode_ms / 1000 if number(decode_ms) else None,
        'decode_tok_s': first(latest.get('decode_tok_s'), timings.get('predicted_per_second')) if backend == 'mlx-vlm' else first(get(native_metrics, 'request_latency', 'stream_tokens_per_second'), timings.get('predicted_per_second')),
        'decode_token_numerator': completion if backend == 'mlx-vlm' else get(native_metrics, 'decode', 'tokens'),
        'scope': 'VLM prompt_eval_time_s; decode_elapsed_s, full completion token numerator' if backend == 'mlx-vlm' else 'Native start-to-first-emission; verify runtime metrics definitions for each version; client timing is the common comparison',
        'timings': timings, 'metrics_latest': latest if backend == 'mlx-vlm' else native_metrics,
    }
    cache_n = first(timings.get('cache_n'), result.get('cache_matched_tokens'), get(native_metrics, 'cache', 'matched_tokens'))
    path_map = {'result': result_path, 'resources': resources_path, 'allocator': allocator_path,
                'request': f'{directory}/{label}-request.json', 'stream': stream_path,
                'output': f'{directory}/{label}-output.txt', 'server_log': f'{directory}/server.log',
                'server_exit': run.get('server_exit', f'{directory}/server-exit.json')}
    return {
        'run_id': run_id, 'backend': backend, 'label': label, 'metadata': metadata,
        'result_present': bool(result), 'functional_long_decode_passed': functional,
        'completed_requested4096': first(result.get('completed_requested4096'), completion == 4096 if number(completion) else None),
        'vision_correct': result.get('vision_correct'), 'recovery_correct': result.get('recovery_correct'),
        'vision_validation': result.get('vision_validation'), 'recovery_validation': result.get('recovery_validation'),
        'errors': result.get('errors', []), 'run_error': run_error, 'flags': flags,
        'usage': usage, 'finish_reason': first(result.get('finish_reason'), latest.get('finish_reason')),
        'stream_done': result.get('stream_done'), 'cache_matched_tokens': cache_n,
        'sampling': metadata.get('sampling'), 'request_sha256': actual_request_sha,
        'recorded_request_sha256': metadata.get('payload_sha256'),
        'request_sha_matches_metadata': actual_request_sha == metadata.get('payload_sha256') if actual_request_sha and metadata.get('payload_sha256') else None,
        'client_ttft_seconds': result.get('client_ttft_seconds'), 'wall_seconds': wall,
        'client_content_span_seconds': client_span,
        'client_content_span_tok_s': completion / client_span if number(completion) and number(client_span) and client_span > 0 else None,
        'client_end_to_end_generation_tok_s': completion / wall if number(completion) and number(wall) and wall > 0 else None,
        'chunk_gaps': result.get('chunk_gaps', {}), 'stream_delivery': delivery,
        'backend_timing': backend_timing,
        'phase_boundaries': {'request_start': start, 'request_start_source': start_source,
                             'recorded_started_unix_seconds': result.get('started_unix_seconds'),
                             'client_first_content': result.get('first_content_unix_seconds'), 'request_finish': finish},
        'resource_phases': phases, 'request_resources': request_resources,
        'resource_baseline': point(baseline, start), 'resource_request_end': point(endpoint, finish),
        'resource_after_recovery': point(tail, finish), 'request_swap_delta_bytes': swap_delta,
        'recovery_swap_delta_bytes': recovery_swap_delta, 'allocator_peak_resets': peak_resets,
        'all_samples': summarize_rows(merged), 'parse_errors': parse_errors + allocator_errors + stream_errors,
        'engine_pids': sorted({row['pid'] for row in merged if isinstance(row.get('pid'), int)}),
        'frontend_pids': sorted({row['frontend_pid'] for row in merged if isinstance(row.get('frontend_pid'), int)}),
        'server_status_before': before, 'server_status_after': after,
        'native_status_diagnostics': native_diagnostics,
        'native_command_metrics_before': before.get('metrics') if backend in ('mltf', 'splash') else None,
        'native_command_metrics_after': after.get('metrics') if backend in ('mltf', 'splash') else None,
        'native_counter_deltas': result.get('native_counter_deltas'),
        'post_recovery_status': result.get('post_recovery_status'),
        'server_exit': read_json(base / path_map['server_exit']), 'paths': path_map,
    }, merged


def build_summary(base: Path = OUT) -> tuple[dict, list[dict]]:
    manifest = read_json(base / 'runs.json')
    if not isinstance(manifest, dict) or not manifest.get('runs'):
        raise ValueError('runs.json with runs list is required')
    runs, merged, missing = [], [], []
    for original in manifest['runs']:
        run = dict(original)
        items = run.get('results') or {}
        if isinstance(items, str):
            items = {get(run, 'metadata', 'label', default='128k'): items}
        if not items:
            raise ValueError(f'{run.get("id")}: missing result mapping')
        for label, result_path in items.items():
            run['_case_label'] = label
            case, rows = summarize_case(base, run, result_path)
            runs.append(case)
            merged.extend(rows)
            if not case['result_present']:
                missing.append(result_path)
            if case['server_exit'] is None:
                missing.append(case['paths']['server_exit'])
    groups = {}
    for backend in sorted({case['backend'] for case in runs}):
        cases = [case for case in runs if case['backend'] == backend]
        groups[backend] = {'n_planned': len(cases), 'n_results': sum(case['result_present'] for case in cases),
                           'n_long_decode_passed': sum(case['functional_long_decode_passed'] is True for case in cases),
                           'metrics': {key: stats([case.get(key) for case in cases]) for key in
                                       ('client_ttft_seconds', 'wall_seconds', 'client_content_span_seconds',
                                        'client_content_span_tok_s', 'client_end_to_end_generation_tok_s')}}
    pairs = []
    for label in sorted({case['label'] for case in runs}):
        cases = {case['backend']: case for case in runs if case['label'] == label}
        if 'splash' in cases and 'mltf' in cases:
            a, b = cases['splash'], cases['mltf']
            ratios = {}
            for key in ('client_ttft_seconds', 'wall_seconds', 'client_end_to_end_generation_tok_s', 'client_content_span_tok_s'):
                av, bv = a.get(key), b.get(key)
                ratios[key + '_mltf_over_splash'] = bv / av if number(av) and number(bv) and av > 0 else None
            pairs.append({'label': label, 'same_payload_sha256': bool(a['request_sha256']) and a['request_sha256'] == b['request_sha256'],
                          'splash_run': a['run_id'], 'mltf_run': b['run_id'], 'ratios': ratios})
    return {'schema_version': 1, 'generated_unix_seconds': datetime.now().timestamp(),
            'manifest': manifest, 'hardware': read_json(base / 'hardware.json'),
            'runs': runs, 'backend_groups': groups, 'paired_tasks': pairs,
            'missing_evidence': sorted(set(missing)), 'complete_evidence': not missing,
            'run_complete': read_json(base / 'run-complete.json'),
            'cleanup': read_json(base / 'cleanup-status.json'),
            'historical_perf06_summary': '$LOCAL_LLMS_ROOT/mltf/records/history/benchmarks/2026-10-19-mltf-comparison/summary.json'}, merged


def fmt(value, digits=2):
    return f'{value:,.{digits}f}' if number(value) else '未取得'


def gib(value):
    return fmt(value / GIB) if number(value) else '未取得'


def yes(value):
    return '通过' if value is True else '失败' if value is False else '未完成 / 未记录'


def safe(value):
    return str(value).replace('|', '\\|').replace('\n', ' ')


def peak(case, phase, key):
    return get(case, 'resource_phases', phase, 'metrics', key, 'peak')



def write_outputs(summary: dict, rows: list[dict], base: Path = OUT) -> None:
    (base / 'summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
    flat = []
    for case in summary['runs']:
        row = {key: case.get(key) for key in ('run_id', 'backend', 'label', 'functional_long_decode_passed', 'completed_requested4096', 'vision_correct', 'recovery_correct', 'client_ttft_seconds', 'wall_seconds', 'client_content_span_seconds', 'client_content_span_tok_s', 'client_end_to_end_generation_tok_s', 'cache_matched_tokens', 'request_swap_delta_bytes', 'recovery_swap_delta_bytes')}
        row.update(prompt_tokens=case['usage'].get('prompt_tokens'), completion_tokens=case['usage'].get('completion_tokens'),
                   backend_prompt_seconds=case['backend_timing']['prompt_seconds'], backend_prompt_tok_s=case['backend_timing']['prompt_tok_s'],
                   backend_decode_seconds=case['backend_timing']['decode_seconds'], backend_decode_tok_s=case['backend_timing']['decode_tok_s'])
        for key, values in case['request_resources']['metrics'].items():
            row[key + '_mean'], row[key + '_peak'] = values['mean'], values['peak']
        row['flags'] = '; '.join(case['flags'])
        flat.append(row)
    with (base / 'summary.csv').open('w', newline='') as file:
        writer = csv.DictWriter(file, fieldnames=list(flat[0]) if flat else ['run_id'])
        writer.writeheader(); writer.writerows(flat)
    fields = ['run_id', 'backend', 'case_label', 'unix_seconds', 'monotonic_seconds', 'seconds_from_request_start',
              'phase', 'raw_phase', 'pid', 'root_pid', 'frontend_pid', 'engine_pid', *RESOURCE_KEYS,
              'memory_pressure_level', 'memory_pressure_name', 'pressure', 'allocator_join_offset_seconds',
              'native_status_stale', 'native_status_age_ms', 'native_status_callback_failed', 'sample_duration_seconds',
              'errors', 'allocator_errors']
    with (base / 'merged-per-second.csv').open('w', newline='') as file:
        writer = csv.DictWriter(file, fieldnames=fields, extrasaction='ignore')
        writer.writeheader()
        for original in rows:
            row = dict(original)
            for key in ('errors', 'allocator_errors'):
                row[key] = json.dumps(row.get(key) or {}, ensure_ascii=False)
            writer.writerow(row)
    # Bilingual reports are authored from these preserved summary data separately.


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--allow-partial', action='store_true', help='Write a report with explicit missing/failed evidence')
    args = parser.parse_args()
    summary, rows = build_summary()
    if summary['missing_evidence'] and not args.allow_partial:
        raise SystemExit('Wait for all results and server-exit records, or use --allow-partial: ' + ', '.join(summary['missing_evidence']))
    write_outputs(summary, rows)
    print(OUT / 'summary.json')


if __name__ == '__main__':
    main()
