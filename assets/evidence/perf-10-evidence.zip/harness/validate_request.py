"""Count a Chat+image request through the native server CPU-only endpoints.

This module never submits generation, starts a server, or changes the payload.
Call validate(base_url, payload, headers, out_dir) after a fresh server is ready.
payload may be a dict or the original JSON bytes (preferred for exact byte hash).
"""
from __future__ import annotations

import os
import base64
import hashlib
import io
import json
from pathlib import Path
import struct
from typing import Mapping
import urllib.request

from PIL import Image


BASELINE_TEMPLATE = Path(os.environ.get('LOCAL_LLMS_ROOT', '~/local_llms')).expanduser() / 'models/splash/huggingface/hub/models--mlx-community--Qwen3.8-27B-8bit/snapshots/815b83c0df8ffd1d1b5244cf75fd6ef14fca9ef9/chat_template.jinja'
EXPECTED_PROMPT = 126976
EXPECTED_OUTPUT = 4096
CONTEXT = 131072
IMAGE_PAD = "<|image_pad|>"
NO_THINK_ENDING = "<|im_start|>assistant\n<think>\n\n</think>\n\n"


def _sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _json_write(path: Path, value) -> None:
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")
    temp.replace(path)


def _image_info(part: dict) -> dict:
    value = part.get("image_url")
    url = value.get("url") if isinstance(value, dict) else value
    if not isinstance(url, str) or not url.startswith("data:image/"):
        raise ValueError("Expected the original base64 data:image image_url")
    header, encoded = url.split(",", 1)
    if ";base64" not in header:
        raise ValueError("Expected a base64 image data URL")
    raw = base64.b64decode(encoded, validate=True)
    with Image.open(io.BytesIO(raw)) as source:
        width, height = source.size
        # MLTF v0.1.2 server/images.py smart_resize: patch16, merge2.
        # The original fixture is inside both pixel limits, so only rounding
        # applies. Reject different geometry rather than guess another path.
        if (width, height) != (840, 280):
            raise ValueError(f"Expected original 840x280 image; got {source.size}")
        target = (round(width / 32) * 32, round(height / 32) * 32)
        resized = source.convert("RGB").resize(target, Image.Resampling.BICUBIC)
        pixels = resized.tobytes()
    grid_width, grid_height = target[0] // 16, target[1] // 16
    digest = hashlib.sha256(struct.pack("<II", grid_height, grid_width) + pixels).digest()
    return {
        "original_width": width, "original_height": height,
        "resized_width": target[0], "resized_height": target[1],
        "grid_height": grid_height, "grid_width": grid_width,
        "expanded_tokens": (grid_height // 2) * (grid_width // 2),
        "rgb_bytes": len(pixels), "image_file_sha256": _sha(raw),
        "resized_rgb_sha256": _sha(pixels),
        "native_image_digest_sha256": digest.hex(),
        "native_image_digest_lo": struct.unpack_from("<Q", digest, 0)[0],
        "native_image_digest_hi": struct.unpack_from("<Q", digest, 8)[0],
    }


def validate(base_url, payload, headers, out_dir) -> dict:
    """Persist exact counts and raise ValueError on any comparison mismatch.

    Only GET /v1/models and POST /apply-template /tokenize are called. All
    endpoints perform metadata/CPU preparation, never model generation.
    No request content is truncated or adjusted to satisfy the token budget.
    """
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    if isinstance(payload, (bytes, bytearray)):
        original_bytes = bytes(payload)
        body = json.loads(original_bytes)
        byte_hash_kind = "original_json_bytes"
    elif isinstance(payload, str):
        original_bytes = payload.encode("utf-8")
        body = json.loads(payload)
        byte_hash_kind = "provided_json_string_utf8"
    elif isinstance(payload, Mapping):
        body = dict(payload)
        original_bytes = json.dumps(body, ensure_ascii=False).encode("utf-8")
        byte_hash_kind = "dict_reserialized_not_original_file_bytes"
    else:
        raise TypeError("payload must be a dict, JSON string, or original JSON bytes")
    request_headers = {"Content-Type": "application/json", **dict(headers or {})}
    base = str(base_url).rstrip("/")
    metadata = {
        "schema_version": 1, "validation_passed": False,
        "base_url": base, "model": body.get("model"),
        "payload_sha256": _sha(original_bytes), "payload_hash_kind": byte_hash_kind,
        "payload_bytes": len(original_bytes),
        "source_version": "Splash 1.4.0; validator adapted from MLTF v0.1.2",
        "source_contract": "https://github.com/DT-HJ/my-little-trie-forge/blob/v0.1.2/server/frontend.py",
        "expected_prompt_tokens": EXPECTED_PROMPT,
        "expected_output_tokens": EXPECTED_OUTPUT, "total_context_budget": CONTEXT,
        "generation_submitted": False,
        "errors": [],
    }

    def call(path, value=None):
        if path not in ("/v1/models", "/apply-template", "/tokenize"):
            raise ValueError("This helper permits only metadata/CPU endpoints")
        request = urllib.request.Request(
            base + path, headers=request_headers,
            data=None if value is None else json.dumps(value, ensure_ascii=False).encode("utf-8"),
        )
        with urllib.request.urlopen(request, timeout=180) as response:
            return json.load(response)

    try:
        errors = metadata["errors"]
        models = call("/v1/models")
        served = [item for item in models.get("data", []) if item.get("id") == body.get("model")]
        metadata["served_model_metadata"] = served
        if not served:
            errors.append("The original request model ID is not advertised by /v1/models")
        elif served[0].get("context_length", served[0].get("max_model_len", 0)) < CONTEXT:
            errors.append("Server-advertised context window is below 131072")

        images = []
        text_parts = []
        for message_index, message in enumerate(body.get("messages", [])):
            content = message.get("content")
            parts = content if isinstance(content, list) else [{"type": "text", "text": content}]
            for part_index, part in enumerate(parts):
                if part.get("type") == "image_url":
                    images.append({"message_index": message_index, "part_index": part_index, **_image_info(part)})
                elif part.get("type") in ("text", "input_text") and isinstance(part.get("text"), str):
                    text_parts.append((message_index, part_index, part["text"]))
        metadata["images"] = images
        metadata["image_count"] = len(images)
        if len(images) != 1 or any(image["expanded_tokens"] != 234 for image in images):
            errors.append("Expected exactly one original image expanding to 234 tokens")

        count_body = {**body, "add_generation_prompt": True}
        template_response = call("/apply-template", count_body)
        formatted = template_response.get("prompt")
        if not isinstance(formatted, str):
            raise ValueError("/apply-template did not return {prompt: string}")
        formatted_bytes = formatted.encode("utf-8")
        (out / "formatted-prompt.txt").write_bytes(formatted_bytes)
        metadata.update(
            formatted_prompt_path=str(out / "formatted-prompt.txt"),
            formatted_prompt_sha256=_sha(formatted_bytes),
            formatted_prompt_chars=len(formatted),
            formatted_prompt_bytes=len(formatted_bytes),
            add_generation_prompt=True,
            image_placeholder_count=formatted.count(IMAGE_PAD),
            actual_assistant_suffix=formatted[-len(NO_THINK_ENDING):],
            expected_assistant_suffix=NO_THINK_ENDING,
            thinking_none_suffix_matches=formatted.endswith(NO_THINK_ENDING),
        )
        source = BASELINE_TEMPLATE.read_bytes()
        metadata["baseline_template"] = {"path": str(BASELINE_TEMPLATE), "sha256": _sha(source)}
        source_text = source.decode("utf-8")
        if "enable_thinking is defined and enable_thinking is false" not in source_text or "'<think>\\n\\n</think>\\n\\n'" not in source_text:
            errors.append("Baseline source no longer contains the audited thinking-OFF ending")
        if not metadata["thinking_none_suffix_matches"]:
            errors.append("Formatted assistant ending differs from baseline thinking OFF; set MLTF --default-reasoning-effort none")
        if formatted.count(IMAGE_PAD) != 1:
            errors.append("Formatted prompt must contain exactly one unexpanded image placeholder")

        metadata["text_parts"] = [
            {"message_index": mi, "part_index": pi, "chars": len(text),
             "sha256": _sha(text.encode("utf-8")), "present_without_truncation": text in formatted}
            for mi, pi, text in text_parts
        ]
        if not all(part["present_without_truncation"] for part in metadata["text_parts"]):
            errors.append("At least one original text part is absent/changed in the formatted prompt")

        ids = call("/tokenize", {"content": formatted, "add_special": False})["tokens"]
        pad_ids = call("/tokenize", {"content": IMAGE_PAD, "add_special": False})["tokens"]
        if not isinstance(ids, list) or not all(type(token) is int and 0 <= token < 2**32 for token in ids):
            raise ValueError("/tokenize tokens must be a list of unsigned integer IDs")
        if not isinstance(pad_ids, list) or len(pad_ids) != 1 or ids.count(pad_ids[0]) != 1:
            errors.append("Image pad must encode as exactly one special token, occurring once")
        expanded = len(ids) + sum(image["expanded_tokens"] - 1 for image in images)
        requested_output = body.get("max_completion_tokens", body.get("max_tokens"))
        metadata.update(
            unexpanded_prompt_tokens=len(ids), image_pad_token_ids=pad_ids,
            token_ids_sha256=_sha(b"".join(struct.pack("<I", token) for token in ids)),
            token_ids_hash_encoding="concatenated unsigned uint32 little endian; before image expansion",
            token_ids_first_16=ids[:16], token_ids_last_32=ids[-32:],
            expanded_prompt_tokens=expanded, requested_output_tokens=requested_output,
            requested_total_tokens=expanded + requested_output if type(requested_output) is int else None,
            requested_sampling={key: body.get(key) for key in ("temperature", "top_p", "top_k")},
        )
        if len(pad_ids) == 1 and ids.count(pad_ids[0]) == 1 and len(images) == 1:
            pad_index = ids.index(pad_ids[0])
            expanded_ids = ids[:pad_index] + [pad_ids[0]] * images[0]["expanded_tokens"] + ids[pad_index + 1:]
            metadata["expanded_token_ids_sha256"] = _sha(b"".join(struct.pack("<I", token) for token in expanded_ids))
            metadata["expanded_token_ids_hash_encoding"] = "concatenated unsigned uint32 little endian; image pad repeated 234 times"
            metadata["image_span_start_token"] = pad_index
            metadata["expanded_token_ids_length"] = len(expanded_ids)
        if expanded != EXPECTED_PROMPT:
            errors.append(f"Actual expanded prompt is {expanded}, expected {EXPECTED_PROMPT}; no truncation or filler adjustment was performed")
        if type(requested_output) is not int or requested_output != EXPECTED_OUTPUT:
            errors.append(f"Requested output is {requested_output!r}, expected 4096")
        if type(requested_output) is int and expanded + requested_output > CONTEXT:
            errors.append(f"Expanded input + reserved output = {expanded + requested_output} exceeds 131072")
        if metadata["requested_sampling"] != {"temperature": 1.0, "top_p": 0.95, "top_k": 20}:
            errors.append("Expected the unchanged sampled baseline temperature=1, top_p=.95, top_k=20")
        historical = {'052763e089b1f87de8e721832e9ee918ac56503473efc2a1136d3cd8062da790': {'formatted_prompt_sha256': '97836e1dd7042f537b12a9209dd4363f92f32e7cd9618e187dde7fa3445c375a', 'token_ids_sha256': '12c22d84c08cfa596f0641d0eba2fdfb4c8fad0e54cb26a81d9e83f6dc2912c4', 'expanded_token_ids_sha256': '4a282b941080c009a313edb954c5478efe2bb43537f399e63a9d5bddea8b0107'}, '2055ef57041a7afa551928d99fe9b7047ae5ee070a38e87f8727671bde35d45c': {'formatted_prompt_sha256': 'dd7feb873402da7195abca2727b1151bd3510135003cb4d66a58a321dbc1740a', 'token_ids_sha256': '9da9425fd31dfad16fe8a99189d38f56cc356983be3a05974867e2f4312e15af', 'expanded_token_ids_sha256': '65e7b7f5f4dec5064245f5a34231ac95cfa6ba7457921d021aa77f0603fec203'}}.get(metadata["payload_sha256"])
        if historical is None:
            errors.append("Request is not one of the two pinned original fixtures")
        else:
            for field, expected_hash in historical.items():
                if metadata.get(field) != expected_hash:
                    errors.append("Historical prompt/token-ID mismatch: " + field)
        metadata["validation_passed"] = not errors
    except Exception as error:
        metadata["errors"].append(f"{type(error).__name__}: {error}")
        _json_write(out / "request-validation.json", metadata)
        raise
    _json_write(out / "request-validation.json", metadata)
    if not metadata["validation_passed"]:
        raise ValueError("MLTF preflight failed: " + "; ".join(metadata["errors"]) + f"; evidence: {out / 'request-validation.json'}")
    return metadata
