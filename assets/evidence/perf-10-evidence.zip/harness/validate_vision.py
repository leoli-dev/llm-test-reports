"""Validate saved shape/color/order answers offline; never imports a model.

Read result locations from run-sessions.json when present. Earlier attempts
are validated separately and never substituted for the five main rows.
Default: require all five long answers and recovery probes. --allow-partial
checks available answers while reporting pending ones explicitly. Both modes
write vision-validation.json. Incorrect or ambiguous answers exit nonzero.
The parser accepts unambiguous English color-shape / shape-is-color pairs;
unexpected wording is a failure requiring review, never an inferred pass.
"""
from __future__ import annotations

import argparse
from datetime import datetime
import hashlib
import json
from pathlib import Path
import re
from zoneinfo import ZoneInfo

OUT = Path(__file__).resolve().parent
FIXTURES = {
    "32k": ("blue", "orange", "green"),
    "64k": ("red", "purple", "yellow"),
    "96k": ("green", "blue", "red"),
    "128k": ("purple", "yellow", "blue"),
    "128k-repeat": ("orange", "green", "purple"),
}
SHAPES = ("circle", "triangle", "rectangle")
COLOR = r"blue|orange|green|red|purple|yellow|black|white|brown|pink|cyan|magenta|gr[ae]y|teal|navy|violet|indigo|lime"
SHAPE = r"circle|triangle|rectangle|square|oval|ellipse|star|diamond|hexagon|pentagon"
PAIR = re.compile(
    rf"\b(?P<color_before>{COLOR})\s+(?P<shape_after>{SHAPE})\b"
    rf"|\b(?P<shape_before>{SHAPE})\s+(?:(?:is|in|colored|coloured)\s+)?(?P<color_after>{COLOR})\b",
    re.IGNORECASE,
)
SHAPE_WORD = re.compile(rf"\b(?:{SHAPE})s?\b", re.IGNORECASE)
UNCERTAIN = re.compile(r"\b(?:not|no|without|isn't|aren't|maybe|perhaps|uncertain|instead|rather|right.to.left)\b", re.IGNORECASE)


def validate_answer(text, expected):
    if text is None:
        return {"status": "pending", "passed": None, "text": None, "recognized_order": [], "errors": []}
    errors, recognized = [], []
    if not isinstance(text, str) or not text.strip():
        errors.append("Missing or empty answer text")
        text = text if isinstance(text, str) else repr(text)
    else:
        for match in PAIR.finditer(text):
            recognized.append({
                "shape": (match.group("shape_after") or match.group("shape_before")).casefold(),
                "color": (match.group("color_before") or match.group("color_after")).casefold(),
            })
        if len(SHAPE_WORD.findall(text)) != 3:
            errors.append("Expected exactly three shape mentions")
        if UNCERTAIN.search(text):
            errors.append("Negation, uncertainty or reversed-order wording requires review")
        if recognized != expected:
            errors.append("Shape/color pairs or their left-to-right order differ from the fixture")
    return {"status": "fail" if errors else "pass", "passed": not errors,
            "text": text, "recognized_order": recognized, "errors": errors}


def validate_result(label, colors, relative_path, session_id=None):
    expected = [{"shape": shape, "color": color} for shape, color in zip(SHAPES, colors)]
    path = OUT / relative_path
    errors, result, source_hash = [], {}, None
    if path.is_file():
        raw = path.read_bytes()
        source_hash = hashlib.sha256(raw).hexdigest()
        try:
            result = json.loads(raw)
            if not isinstance(result, dict):
                raise ValueError("Result must be a JSON object")
        except (ValueError, TypeError) as exc:
            errors.append(f"Cannot read result: {exc}")
            result = {}
        if result and result.get("metadata", {}).get("expected_colors") != list(colors):
            errors.append("Result metadata colors differ from run_stability.py fixtures")
    content = result.get("content")
    long_text = content.splitlines()[0] if isinstance(content, str) and content else content
    recovery = result.get("recovery_response") or {}
    choices = recovery.get("choices") or []
    recovery_text = (choices[0].get("message") or {}).get("content") if choices else None
    long_answer = validate_answer(long_text, expected)
    recovery_answer = validate_answer(recovery_text, expected)
    complete = long_answer["status"] != "pending" and recovery_answer["status"] != "pending"
    passed = complete and not errors and long_answer["passed"] and recovery_answer["passed"]
    return {"label": label, "session_id": session_id, "expected_order": expected,
            "source_result": relative_path, "source_sha256": source_hash,
            "complete": complete, "passed": bool(passed), "errors": errors,
            "long_answer": long_answer, "recovery_answer": recovery_answer}


def has_failure(stage):
    return bool(stage["errors"]) or any(
        stage[key]["status"] == "fail" for key in ("long_answer", "recovery_answer"))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--allow-partial", action="store_true", help="Validate available answers; retain explicit pending stages.")
    args = parser.parse_args()
    manifest_path = OUT / "run-sessions.json"
    locations, prior_locations = {}, []
    if manifest_path.is_file():
        manifest = json.loads(manifest_path.read_text())
        for session in manifest["sessions"]:
            for label, path in session.get("results", {}).items():
                if label in locations:
                    raise SystemExit(f"Duplicate main result in manifest: {label}")
                locations[label] = (path, session["id"])
            for label, path in session.get("prior_attempts", {}).items():
                prior_locations.append((label, path, session["id"]))
        missing = set(FIXTURES) - locations.keys()
        if missing:
            raise SystemExit(f"Manifest omits required main result labels: {sorted(missing)}")
    else:
        locations = {label: (f"{label}-result.json", None) for label in FIXTURES}
    stages = [validate_result(label, colors, *locations[label]) for label, colors in FIXTURES.items()]
    prior_attempts = []
    for label, path, session_id in prior_locations:
        matching = [fixture for fixture in FIXTURES if label == fixture or label.startswith(fixture + "-")]
        if not matching:
            raise SystemExit(f"Unknown fixture for prior attempt: {label}")
        fixture_label = max(matching, key=len)
        prior_attempts.append(validate_result(label, FIXTURES[fixture_label], path, session_id))
    pending = [stage["label"] for stage in stages if not stage["complete"]]
    failures = [stage["label"] for stage in stages if has_failure(stage)]
    prior_failures = [stage["label"] for stage in prior_attempts if has_failure(stage)]
    report = {
        "schema_version": 2, "date": "2026-10-19", "timezone": "America/Toronto",
        "validated_at": datetime.now(ZoneInfo("America/Toronto")).isoformat(),
        "method": "Offline comparison of first long-answer line and full recovery answer against the three fixed shape/color fixtures, in textual left-to-right order.",
        "scope": "Checks visual answer content only; does not validate generated application code or run inference. all_passed applies to the five manifest-selected main results; prior attempts remain separate and missing recovery answers never pass.",
        "source_manifest": manifest_path.name if manifest_path.is_file() else None,
        "all_five_completed": not pending, "all_passed": not pending and not failures,
        "available_answers_passed": not failures and not prior_failures, "missing_stages": pending,
        "failed_stages": failures, "stages": stages,
        "prior_attempts": prior_attempts, "failed_prior_attempts": prior_failures,
    }
    output = OUT / "vision-validation.json"
    output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({"output": str(output), "all_passed": report["all_passed"],
                      "pending": pending, "failed": failures,
                      "failed_prior_attempts": prior_failures}, ensure_ascii=False))
    raise SystemExit(1 if failures or prior_failures else (2 if pending and not args.allow_partial else 0))


if __name__ == "__main__":
    main()
