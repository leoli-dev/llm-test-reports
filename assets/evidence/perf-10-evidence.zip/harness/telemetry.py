"""Unprivileged macOS telemetry for the long-context benchmark.

Uses only the Python standard library and macOS APIs/tools. GPU counters are
system-wide IOAccelerator driver statistics, not per-process measurements.
Apple silicon has unified memory: never add GPU memory counters to process RSS
or footprint, and do not describe these counters as dedicated VRAM.

CPU times are cumulative seconds. Compute process CPU percentage from adjacent
samples as 100 * delta(process_cpu_seconds) / delta(monotonic_seconds). 100% is
one logical CPU; this can exceed 100%. System CPU percentage can be computed as
100 * delta(system_cpu_busy_ticks) / delta(system_cpu_total_ticks). The 32-bit
system counters may wrap and need modulo-2**32 deltas per individual counter
for runs spanning the wrap.
"""

from __future__ import annotations

import ctypes
import os
import plistlib
import subprocess
import time
from typing import Any


class _RUsageInfoV0(ctypes.Structure):
    # RUSAGE_INFO_V0, from the macOS SDK's sys/resource.h.
    _fields_ = [("uuid", ctypes.c_uint8 * 16)] + [
        (name, ctypes.c_uint64)
        for name in (
            "user_time",
            "system_time",
            "pkg_idle_wkups",
            "interrupt_wkups",
            "pageins",
            "wired_size",
            "resident_size",
            "phys_footprint",
            "proc_start_abstime",
            "proc_exit_abstime",
        )
    ]


class _MachTimebaseInfo(ctypes.Structure):
    _fields_ = [("numer", ctypes.c_uint32), ("denom", ctypes.c_uint32)]


_libproc = ctypes.CDLL("/usr/lib/libproc.dylib", use_errno=True)
_libproc.proc_pid_rusage.argtypes = [ctypes.c_int, ctypes.c_int, ctypes.c_void_p]
_libproc.proc_pid_rusage.restype = ctypes.c_int
_libsystem = ctypes.CDLL("/usr/lib/libSystem.B.dylib", use_errno=True)
_libsystem.mach_timebase_info.argtypes = [ctypes.POINTER(_MachTimebaseInfo)]
_libsystem.mach_timebase_info.restype = ctypes.c_int
_libsystem.mach_host_self.argtypes = []
_libsystem.mach_host_self.restype = ctypes.c_uint32
_libsystem.host_statistics.argtypes = [
    ctypes.c_uint32,
    ctypes.c_int,
    ctypes.c_void_p,
    ctypes.POINTER(ctypes.c_uint32),
]
_libsystem.host_statistics.restype = ctypes.c_int
_timebase = _MachTimebaseInfo()
_timebase_status = _libsystem.mach_timebase_info(ctypes.byref(_timebase))
_host_port = _libsystem.mach_host_self()


def collect(pid: int) -> dict[str, Any]:
    """Return one sample. Missing metrics are None and explained in errors.

    GPU percentages are the driver's sampled percentage at collection time;
    their averaging interval is not specified by the public IORegistry data.
    RSS and footprint come from proc_pid_rusage for exactly ``pid`` (no children).
    ``sample_duration_seconds`` exposes collector overhead; ioreg usually takes
    roughly 20 ms on this machine. Collection never requires sudo.
    """
    started = time.monotonic()
    out: dict[str, Any] = {
        "unix_seconds": time.time(),
        "monotonic_seconds": started,
        "pid": int(pid),
        "process_user_cpu_seconds": None,
        "process_system_cpu_seconds": None,
        "process_cpu_seconds": None,
        "process_rss_bytes": None,
        "process_physical_footprint_bytes": None,
        "process_wired_bytes": None,
        "process_pageins": None,
        "gpu_device_utilization_percent": None,
        "gpu_renderer_utilization_percent": None,
        "gpu_tiler_utilization_percent": None,
        "gpu_alloc_system_memory_bytes": None,
        "gpu_in_use_system_memory_bytes": None,
        "gpu_in_use_driver_memory_bytes": None,
        "system_cpu_user_ticks": None,
        "system_cpu_system_ticks": None,
        "system_cpu_idle_ticks": None,
        "system_cpu_nice_ticks": None,
        "system_cpu_busy_ticks": None,
        "system_cpu_total_ticks": None,
        "logical_cpu_count": os.cpu_count(),
        "errors": {},
    }
    try:
        if _timebase_status != 0 or _timebase.denom == 0:
            raise RuntimeError(f"mach_timebase_info failed: {_timebase_status}")
        usage = _RUsageInfoV0()
        ctypes.set_errno(0)
        status = _libproc.proc_pid_rusage(int(pid), 0, ctypes.byref(usage))
        if status != 0:
            code = ctypes.get_errno()
            raise OSError(code, os.strerror(code))
        # These macOS cumulative CPU fields are Mach absolute-time ticks, NOT
        # nanoseconds. M5 Max here uses numer=125, denom=3 (24 MHz ticks).
        seconds_per_tick = _timebase.numer / _timebase.denom / 1e9
        out.update(
            process_user_cpu_seconds=usage.user_time * seconds_per_tick,
            process_system_cpu_seconds=usage.system_time * seconds_per_tick,
            process_cpu_seconds=(usage.user_time + usage.system_time) * seconds_per_tick,
            process_rss_bytes=int(usage.resident_size),
            process_physical_footprint_bytes=int(usage.phys_footprint),
            process_wired_bytes=int(usage.wired_size),
            process_pageins=int(usage.pageins),
        )
    except Exception as exc:
        out["errors"]["process"] = f"{type(exc).__name__}: {exc}"

    try:
        # HOST_CPU_LOAD_INFO = 3, CPU_STATE_{USER,SYSTEM,IDLE,NICE} = 0..3.
        counters = (ctypes.c_uint32 * 4)()
        count = ctypes.c_uint32(4)
        status = _libsystem.host_statistics(_host_port, 3, counters, ctypes.byref(count))
        if status != 0 or count.value != 4:
            raise RuntimeError(f"host_statistics failed: status={status}, count={count.value}")
        user, system, idle, nice = map(int, counters)
        out.update(
            system_cpu_user_ticks=user,
            system_cpu_system_ticks=system,
            system_cpu_idle_ticks=idle,
            system_cpu_nice_ticks=nice,
            system_cpu_busy_ticks=user + system + nice,
            system_cpu_total_ticks=user + system + idle + nice,
        )
    except Exception as exc:
        out["errors"]["system_cpu"] = f"{type(exc).__name__}: {exc}"

    try:
        result = subprocess.run(
            ["/usr/sbin/ioreg", "-r", "-c", "IOAccelerator", "-a", "-l", "-d", "1"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            check=True,
            timeout=5,
        )
        devices = plistlib.loads(result.stdout)
        device = next(item for item in devices if "PerformanceStatistics" in item)
        stats = device["PerformanceStatistics"]
        fields = {
            "gpu_device_utilization_percent": "Device Utilization %",
            "gpu_renderer_utilization_percent": "Renderer Utilization %",
            "gpu_tiler_utilization_percent": "Tiler Utilization %",
            "gpu_alloc_system_memory_bytes": "Alloc system memory",
            "gpu_in_use_system_memory_bytes": "In use system memory",
            "gpu_in_use_driver_memory_bytes": "In use system memory (driver)",
        }
        for output_key, driver_key in fields.items():
            if driver_key in stats:
                out[output_key] = stats[driver_key]
            else:
                out["errors"][output_key] = f"Missing IOAccelerator statistic: {driver_key}"
    except Exception as exc:
        out["errors"]["gpu"] = f"{type(exc).__name__}: {exc}"
    out["sample_duration_seconds"] = time.monotonic() - started
    return out


if __name__ == "__main__":
    import json
    import sys

    print(json.dumps(collect(int(sys.argv[1]) if len(sys.argv) > 1 else os.getpid()), indent=2))
