"""Fresh-process, cold-KV GGUF Q8_0 follow-up using identical saved vision requests."""
from __future__ import annotations

import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import signal
import socket
import statistics
import subprocess
import threading
import time
import urllib.error
import urllib.request

from resource_collector import ResourceCollector

ROOT = Path(os.environ.get('LOCAL_LLMS_ROOT', '~/local_llms')).expanduser()
HISTORY = ROOT / 'mltf/records/history/benchmarks'
MODEL_ROOT_FILE = Path(__file__).resolve().parent / 'prepared-model-path.txt'
OUT = Path(__file__).resolve().parent
BASELINE = OUT / 'fixtures'
KEY = (OUT / 'private/api-key').read_text().strip()
MODEL = 'mlx-community/Qwen3.8-27B-8bit'
ORDER = [('gguf-1','splash','128k',8084), ('gguf-2','splash','128k-repeat',8084)]


def persist(path, value):
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
    temporary.replace(path)


def api(base, path, payload=None, timeout=10):
    request = urllib.request.Request(base + path,
        data=None if payload is None else json.dumps(payload).encode(),
        headers={'Authorization':f'Bearer {KEY}','Content-Type':'application/json'})
    with urllib.request.urlopen(request, timeout=timeout) as response:
        return json.load(response)


def fresh_status(base):
    status=None
    for _ in range(15):
        status=api(base,'/status',timeout=3)
        if status.get('transport',{}).get('status_stale') is False:return status
        time.sleep(.2)
    raise RuntimeError('MLTF /status remained stale after request')


def module_from(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def gaps_summary(values):
    values = sorted(values)
    if not values:
        return {}
    return {'median_seconds':statistics.median(values),
            'p95_seconds':values[int((len(values)-1)*.95)],
            'p99_seconds':values[int((len(values)-1)*.99)],
            'max_seconds':max(values),'over_2s':sum(v>2 for v in values),
            'over_5s':sum(v>5 for v in values)}


def prepare_cases():
    runs = []
    for run_id, backend, label, port in ORDER:
        directory = OUT / run_id
        directory.mkdir(exist_ok=False)
        raw = (BASELINE / f'{label}-request.json').read_bytes()
        payload = json.loads(raw)
        previous = json.loads((BASELINE / f'{label}-result.json').read_text())
        assert payload['model'] == MODEL and payload['max_tokens'] == 4096
        assert payload['temperature'] == 1 and payload['top_p'] == .95 and payload['top_k'] == 20
        assert payload['enable_thinking'] is False
        (directory / f'{label}-request.json').write_bytes(raw)
        (directory / f'{label}-image.png').write_bytes((BASELINE / f'{label}-image.png').read_bytes())
        meta = dict(previous['metadata'])
        meta.update(backend=backend, run_id=run_id, label=label, actual_target='unsloth/Qwen3.8-27B-GGUF:Q8_0', target_revision='4ca720788d1e01f1bff70c033e0d0028fd02e502', api_model_id_is_compatibility_alias=True,
                    source_request=str(BASELINE / f'{label}-request.json'),
                    payload_sha256=hashlib.sha256(raw).hexdigest(),
                    image_path=str(directory / f'{label}-image.png'),
                    image_sha256=hashlib.sha256((directory/f'{label}-image.png').read_bytes()).hexdigest(),
                    same_request_bytes_as_baseline=True, expected_prompt_tokens=126976,
                    total_context_budget=131072, requested_output_tokens=4096)
        runs.append({'id':run_id,'backend':backend,'directory':run_id,'port':port,
                     'results':{label:f'{run_id}/{label}-result.json'},
                     'resources':f'{run_id}/resources.jsonl',
                     'allocator':f'{run_id}/allocator.jsonl' if backend=='mlx-vlm' else None,
                     'server_exit':f'{run_id}/server-exit.json','metadata':meta})
    persist(OUT/'runs.json',{'runs':runs,'order':[r['id'] for r in runs],
        'notes':['One fresh process per main request; GGUF A then B; cold KV verified. PERF-09 comparisons are earlier same-day observations, not freshly interleaved.',
                 'Main request bytes identical to the saved recommended-sampling VLM vision requests.',
                 'Splash defaults to reasoning none; exact original request bytes retained.',
                 'Actual target is Unsloth GGUF Q8_0, not the MLX compatibility model ID retained in original request bytes. Q8_0 and affine8 have different quantized values.',
                 'Common process counters refer to each native splash engine; frontend/tree are separate.',
                 'Backend prompt_ms and decode denominators differ; shared client timing is reported too.']})
    return runs


def measure_request(base, directory, label, metadata, state, status_path):
    raw = (directory/f'{label}-request.json').read_bytes()
    payload = json.loads(raw)
    result = {'metadata':metadata,'started_unix_seconds':time.time(),
              'health_before':fresh_status(base) if metadata['backend'] in ('mltf','splash') else api(base,status_path),'errors':[]}
    if metadata['backend']=='mlx-vlm':
        result['metrics_before']=api(base,'/metrics')
    else:
        result['server_status_before']=result['health_before']
    state['phase']='prefill'
    start=time.monotonic();first=None;times=[];parts=[];usage=None;timings={};metrics={};terminal=None
    try:
        request=urllib.request.Request(base+'/v1/chat/completions',data=raw,
            headers={'Authorization':f'Bearer {KEY}','Content-Type':'application/json'})
        print(json.dumps({'run':metadata['run_id'],'status':'request_started','sha256':metadata['payload_sha256']}),flush=True)
        with urllib.request.urlopen(request,timeout=3600) as response, (directory/f'{label}-stream.jsonl').open('w') as stream:
            result['http_status']=response.status
            done=False
            for line in response:
                if not line.startswith(b'data:'):continue
                line=line[5:].strip()
                if line==b'[DONE]':done=True;break
                chunk=json.loads(line); now=time.monotonic();unix=time.time()
                stream.write(json.dumps({'received_unix_seconds':unix,'relative_seconds':now-start,'chunk':chunk},ensure_ascii=False)+'\n');stream.flush()
                if chunk.get('error'):raise RuntimeError(chunk['error'])
                content=''.join(c.get('delta',{}).get('content') or '' for c in (chunk.get('choices') or []))
                if content:
                    if first is None:
                        first=now;result['first_content_unix_seconds']=unix;state['phase']='decode'
                    times.append(now);parts.append(content);result['last_content_unix_seconds']=unix
                if chunk.get('timings'):timings=chunk['timings'];result['timings_chunk']=chunk
                if chunk.get('metrics'):metrics=chunk['metrics']
                if chunk.get('usage'):usage=chunk['usage'];terminal=chunk
                for choice in chunk.get('choices') or []:
                    if choice.get('finish_reason') is not None:result['finish_reason']=choice['finish_reason']
            result['stream_done']=done
        result.update(finished_unix_seconds=time.time(),wall_seconds=time.monotonic()-start,
            client_ttft_seconds=first-start if first is not None else None,
            content=''.join(parts),content_chunk_count=len(times),usage=usage,timings=timings,
            backend_metrics=metrics,terminal_chunk=terminal,
            chunk_gaps=gaps_summary([b-a for a,b in zip(times,times[1:])]))
        span=times[-1]-times[0] if len(times)>1 else None
        result['client_content_span_seconds']=span
        result['client_content_span_tok_s']=usage['completion_tokens']/span if usage and span else None
        result['client_end_to_end_generation_tok_s']=usage['completion_tokens']/result['wall_seconds'] if usage else None
        state['phase']='post_request';time.sleep(.2)
        result['health_after']=fresh_status(base) if metadata['backend'] in ('mltf','splash') else api(base,status_path)
        if metadata['backend']=='mlx-vlm':result['metrics_after']=api(base,'/metrics')
        else:result['server_status_after']=result['health_after']
        errors=result['errors']
        if not done or not usage:errors.append('SSE did not finish with usage')
        if usage:
            if usage['prompt_tokens']!=126976:errors.append('Processed input count mismatch')
            if usage['completion_tokens']<2048:errors.append('Insufficient long-decode coverage (<2048)')
            if usage['prompt_tokens']+usage['completion_tokens']>131072:errors.append('Total context exceeded131072')
        result['completed_requested4096']=bool(usage and usage['completion_tokens']==4096)
        if not result['content'].strip():errors.append('Empty content')
        if metadata['backend']=='mlx-vlm':
            if result['health_after'].get('status')!='healthy':errors.append('VLM unhealthy after request')
            if timings.get('cache_n')!=0:errors.append('VLM cache hit or unverified cold prefill')
            if not timings.get('draft_rounds') or not timings.get('draft_n_accepted'):errors.append('DFlash participation unverified')
        else:
            cached=metrics.get('cache',{}).get('matched_tokens')
            result['cache_matched_tokens']=cached
            if cached!=0:errors.append('Native cache hit or unverified cold prefill')
            before=result['server_status_before'];after=result['server_status_after']
            if after.get('ready') is not True or after.get('metal',{}).get('healthy') is not True:
                errors.append('MLTF not ready/Metal unhealthy after request')
            if after.get('maximum_context_tokens')!=131072:errors.append('MLTF configured context mismatch')
            delta={}
            for key in ('drafted_tokens','accepted_draft_tokens'):
                delta[key]=after.get('metrics',{}).get(key,0)-before.get('metrics',{}).get(key,0)
                if delta[key]<=0:errors.append('MLTF speculation counter did not increase: '+key)
            delta['images_encodes']=after.get('images',{}).get('encodes',0)-before.get('images',{}).get('encodes',0)
            if delta['images_encodes']<=0:errors.append('MLTF native image encode unverified')
            delta['transport_restarts']=after.get('transport',{}).get('restarts',0)-before.get('transport',{}).get('restarts',0)
            if delta['transport_restarts']!=0:errors.append('MLTF restarted during main request')
            result['native_counter_deltas']=delta
        result['functional_long_decode_passed']=not errors
    except Exception as exc:
        result['errors'].append(repr(exc));result['functional_long_decode_passed']=False
        result.setdefault('finished_unix_seconds',time.time());result['content']=''.join(parts)
        result.update(usage=usage,timings=timings,backend_metrics=metrics,terminal_chunk=terminal)
    finally:
        persist(directory/f'{label}-result.json',result)
        (directory/f'{label}-output.txt').write_text(result.get('content',''))
    # Recovery is recorded even if the long output ended early.
    state['phase']='recovery'
    image=payload['messages'][0]['content'][1]
    recovery={'model':MODEL,'messages':[{'role':'user','content':[
        {'type':'text','text':'Describe the three shapes and colors from left to right in one short English line.'},image]}],
        'max_tokens':128,'temperature':0,'enable_thinking':False,'stream':False}
    (directory/'recovery-request.json').write_text(json.dumps(recovery))
    try:
        probe=api(base,'/v1/chat/completions',recovery,timeout=180)
        result['recovery_response']=probe
        validator=module_from(OUT/'validate_vision.py','visual_check')
        expected=[{'shape':shape,'color':color} for shape,color in zip(('circle','triangle','rectangle'),metadata['expected_colors'])]
        first_line=(result.get('content') or '').splitlines()[0] if result.get('content') else ''
        answer=probe['choices'][0]['message']['content']
        result['vision_validation']=validator.validate_answer(first_line,expected)
        result['recovery_validation']=validator.validate_answer(answer,expected)
        result['vision_correct']=result['vision_validation']['passed']
        result['recovery_correct']=result['recovery_validation']['passed']
        result['vision_answer']=first_line
        time.sleep(2);result['post_recovery_status']=api(base,status_path)
    except Exception as exc:
        result['errors'].append('recovery: '+repr(exc));result['recovery_correct']=False
    persist(directory/f'{label}-result.json',result)
    state['phase']='between_stages'
    print(json.dumps({'run':metadata['run_id'],'status':'request_finished','usage':result.get('usage'),
        'timings':result.get('timings'),'functional_pass':result.get('functional_long_decode_passed'),
        'vision':result.get('vision_correct'),'recovery':result.get('recovery_correct'),'errors':result['errors']}),flush=True)
    return result


def sample_loop(proc, backend, base, directory, label, state, stop):
    collector=ResourceCollector(proc.pid,backend='mltf',
        status_callback=(lambda:api(base,'/status',timeout=2)) if backend in ('mltf','splash') else None)
    critical_count=0
    with (directory/'resources.jsonl').open('w') as file:
        while not stop.is_set():
            tick=time.monotonic()
            row=collector.collect(stage=label if state['phase']!='startup' else 'startup',phase=state['phase'])
            row['backend']=backend
            row['engine_allocation_source']=backend + ' memory_actual current/peak; retain raw native_status for definitions'
            row['pressure_level']=row.get('memory_pressure_level')
            row['pressure']=row.get('memory_pressure_name')
            file.write(json.dumps(row)+'\n');file.flush()
            critical_count=critical_count+1 if row.get('pressure')=='critical' else 0
            if critical_count>=15 or (row.get('process_physical_footprint_bytes') or 0)>115*2**30:
                persist(directory/'resource-abort.json',{'reason':'critical15 samples or engine footprint>115GiB','sample':row})
                os.killpg(proc.pid,signal.SIGTERM)
                return
            stop.wait(max(.05,1-(time.monotonic()-tick)))


def thermal_snapshot():
    r=subprocess.run(['pmset','-g','therm'],capture_output=True,text=True,timeout=5)
    return {'unix_seconds':time.time(),'command':'pmset -g therm','stdout':r.stdout,'stderr':r.stderr,'returncode':r.returncode}


def run_server_case(run):
    directory=OUT/run['directory'];backend=run['backend'];label=run['metadata']['label']
    base=f"http://127.0.0.1:{run['port']}"
    with socket.socket() as sock:
        sock.settimeout(1)
        if sock.connect_ex(('127.0.0.1',run['port']))==0:
            raise RuntimeError(f"Port {run['port']} already occupied; refusing to replace another server")
    env=dict(os.environ,TZ='America/Toronto', SPLASH_API_KEY=KEY,
             HF_HUB_OFFLINE='1', MLTF_NO_UPDATE_CHECK='1',
             HF_HUB_CACHE=str(ROOT/'models/splash/huggingface/hub'))
    if backend=='splash':
        env['PYTHONPATH']=str(ROOT/'splash/source')
        command=[str(ROOT/'splash/source/.venv/bin/python'),'-P','-m','server.server',
                 MODEL_ROOT_FILE.read_text().strip(),'--model',MODEL,
                 '--binary',str(ROOT/'splash/source/build/splash'),
                 '--host','127.0.0.1','--port',str(run['port']),
                 '--default-reasoning-effort','none','--kv-format','int8',
                 '--state-format','fp32','--max-memory','96G','--max-context','128K',
                 '--max-cache-disk','0','--idle-release','off','--no-webui']
    else:
        env['MLTF_DATA_ROOT']=str(directory/'runtime-data')
        command=[str(ROOT/'mltf/.venv/bin/mltf'),'serve','--model',MODEL,
                 '--model-path',str(ROOT/'models/Qwen3.8-27B-MLTF-q8c/prepared-q8c'),
                 '--host','127.0.0.1','--port',str(run['port']),
                 '--default-reasoning-effort','none','--kv-format','int8',
                 '--max-memory','96G','--max-context','128K',
                 '--max-concurrent-requests','1','--no-webui','--no-update-check']
    log=(directory/'server.log').open('w')
    proc=subprocess.Popen(command,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    state={'phase':'startup'};stop=threading.Event()
    persist(directory/'run-state.json',{'pid':proc.pid,'process_group':proc.pid,'backend':backend,
        'endpoint':base,'started_unix_seconds':time.time(),'command':command,'metadata':run['metadata']})
    sampler=threading.Thread(target=sample_loop,args=(proc,backend,base,directory,label,state,stop),daemon=True)
    sampler.start()
    try:
        deadline=time.monotonic()+900
        while time.monotonic()<deadline:
            if proc.poll() is not None:raise RuntimeError(f'{run["id"]} exited during startup: {proc.returncode}')
            try:
                h=api(base,'/health' if backend=='mlx-vlm' else '/status',timeout=2)
                if (h.get('status')=='healthy' if backend=='mlx-vlm' else h.get('ready') is True):break
            except (urllib.error.URLError,TimeoutError):pass
            time.sleep(1)
        else:raise RuntimeError('Server startup timeout')
        persist(directory/'health-before.json',h)
        persist(directory/'thermal-before.json',thermal_snapshot())
        if backend=='mlx-vlm':
            assert h['effective_context_limit']==131072 and h['loaded_model']==MODEL,h
            assert not h.get('apc_enabled'),h
        else:
            h=fresh_status(base)
            assert h['maximum_context_tokens']==131072 and h.get('metal',{}).get('healthy') is True,h
            validator=module_from(OUT/'validate_request.py','mltf_request_check')
            payload=(directory/f'{label}-request.json').read_bytes()
            checked=validator.validate(base,payload,{'Authorization':f'Bearer {KEY}'},directory)
            persist(directory/'request-validation.json',checked)
        result=measure_request(base,directory,label,run['metadata'],state,
                               '/health' if backend=='mlx-vlm' else '/status')
        persist(directory/'thermal-after.json',thermal_snapshot())
        persist(directory/'run-complete.json',{'completed':True,'functional_pass':result['functional_long_decode_passed'],
            'vision':result.get('vision_correct'),'recovery':result.get('recovery_correct'),
            'finished_unix_seconds':time.time()})
    except Exception as exc:
        persist(directory/'run-error.json',{'error':repr(exc),'unix_seconds':time.time()})
        raise
    finally:
        stop.set();sampler.join(timeout=6)
        try:os.killpg(proc.pid,signal.SIGTERM)
        except ProcessLookupError:pass
        try:proc.wait(timeout=25)
        except subprocess.TimeoutExpired:
            os.killpg(proc.pid,signal.SIGKILL);proc.wait(timeout=5)
        log.close()
        persist(directory/'server-exit.json',{'pid':proc.pid,'returncode':proc.returncode,'finished_unix_seconds':time.time()})


def main():
    # No model preparation, installation or downloads should run concurrently.
    runs=prepare_cases()
    hardware={'captured_unix_seconds':time.time(),'os':subprocess.check_output(['sw_vers'],text=True),
              'chip':subprocess.check_output(['sysctl','-n','machdep.cpu.brand_string'],text=True).strip(),
              'memory_bytes':int(subprocess.check_output(['sysctl','-n','hw.memsize'],text=True)),
              'cpu_count':int(subprocess.check_output(['sysctl','-n','hw.logicalcpu'],text=True)),
              'gpu_cores':40, 'gpu_cores_evidence':'system_profiler SPDisplaysDataType: sppci_model Apple M5 Max, sppci_cores 40',
              'architecture':subprocess.check_output(['uname','-m'],text=True).strip(),
              'power_source_before':subprocess.check_output(['pmset','-g','batt'],text=True),
              'thermal_before':thermal_snapshot(),
              'power_settings':subprocess.check_output(['pmset','-g'],text=True)}
    persist(OUT/'hardware.json',hardware)
    for run in runs:run_server_case(run)
    persist(OUT/'run-complete.json',{'completed':True,'runs':[run['id'] for run in runs],
        'finished_unix_seconds':time.time()})


if __name__=='__main__':main()
