"""Verify pinned checkpoint files and prepare Splash before any benchmark."""
import hashlib
import json
import sys
from pathlib import Path

ROOT = Path('$LOCAL_LLMS_ROOT')
OUT = Path(__file__).resolve().parent
CACHE = ROOT / 'models/splash/huggingface/hub'
SNAPSHOTS = ROOT / 'splash/records/research/2026-10-21/upstream'
sys.path.insert(0, str(ROOT / 'splash/source'))
from install.local import prepare_local_model

records = []
paths = []
for repo in ['mlx-community/Qwen3.8-27B-8bit', 'incoai/Qwen3.8-27B-DFlash2']:
    info = json.loads((SNAPSHOTS / repo.replace('/', '--') / 'repo-info.json').read_text())
    path = CACHE / ('models--' + repo.replace('/', '--')) / 'snapshots' / info['sha']
    files = []
    for item in info['siblings']:
        source = path / item['rfilename']
        assert source.is_file(), source
        digest = hashlib.sha256()
        with source.open('rb') as file:
            for block in iter(lambda: file.read(8 * 1024**2), b''):
                digest.update(block)
        actual = digest.hexdigest()
        expected = (item.get('lfs') or {}).get('sha256')
        assert source.stat().st_size == item['size'], source
        if expected:
            assert actual == expected, source
        files.append({'path': item['rfilename'], 'size': source.stat().st_size,
                      'sha256': actual, 'hub_lfs_sha256': expected,
                      'lfs_matches': actual == expected if expected else None})
    records.append({'repo': repo, 'revision': info['sha'], 'snapshot': str(path), 'files': files})
    paths.append(path)
    print('Verified', repo, sum(f['size'] for f in files), 'bytes', flush=True)

draft = next(f for f in records[1]['files'] if f['path'] == 'model.safetensors')
old_draft = json.loads((ROOT / 'models/Qwen3.8-27B-MLTF-q8c/provenance/draft-source-comparison.json').read_text())
old_hash = next(f['sha256'] for f in old_draft['dedf8df68adfb1afeaf7b7480c0a0243108177b4'] if f['path'] == 'model.safetensors')
assert draft['sha256'] == old_hash
(OUT / 'download-verification.json').write_text(json.dumps({'models': records, 'draft_source_weights_match_mltf': True}, indent=2) + '\n')
prepared = prepare_local_model(paths[0], draft=paths[1], models_dir=ROOT / 'models/splash/installations')
(OUT / 'prepared-model-path.txt').write_text(str(prepared) + '\n')
print('Prepared', prepared, flush=True)
