# PERF-13 — Strata direct-client TTFT / prefill / decode

Start2026-10-26 America/Toronto. New user-authorised10×128K tasks followed by10×256K stress tasks, after questioning previous proxy/agent timing. No Pi or proxy in this new measurement path.

## Frozen workload and order

- Installed Terminal0.2.6/Control0.1.51/released Metal0.1.50, original Flash Next GSQ-RCO IQ3_S, M5 Max18CPU/40GPU/128GiB. Keep loaded262144 service, single slot, AC power and ordinary background apps. Do not rebuild/download/modify native configuration.
- Formal attempts1–10:131072 actual input tokens plus at most4096 output. This is128K **input**, not a server restarted with a128K capacity.
- Attempts11–20:258040 actual input+4096 output+8 internal reserve=262144. Only actual4096-output cases fill the full budget. Natural EOS remains visible.
- Same synthetic five-key record retrieval followed by CREATE TABLE and2000 INSERT statements in each case. Source archives adapted from PERF-12. Change five12-character reference values and a unique leading nonce on every trial. Verify20 distinct first32 token-ID hashes. These are repeated controlled workloads, not20different real-world projects.
- Temperature0, top_p.95/top_k20; reasoning_effort none and chat_template_kwargs.enable_thinking false. Record any actual reasoning as protocol deviation. Max output4096, no ignore_eos/min_tokens forcing, discarded attempts, automatic retries or best-of selection.
- Local pinned tokenizer/template fit exact counts before timing; record payload/rendered/ID hashes and key positions. Do not infer on a timed payload before its formal attempt. Actual usage and a count-only API confirmation **after** each timed request verify counts.
- One separately labelled short warmup and one final recovery are not part of the20-case averages. Sequential128k01…10 then256k01…10. Keep failed/EOS/contaminated rows. If safety aborts, mark remaining trials not attempted.

## Clocks and rates

- Serialize JSON before timing. Start perf_counter_ns immediately before direct HTTPConnection.request(), including connection/upload, front-end/tokenization, queuing, prefill and first decode.
- Timestamp every received SSE line immediately after read, before JSON parsing/disk writes. Ignore headers, keepalives, empty role/content and usage-only chunks as generated tokens.
- TTFT=request start→first nonempty content/reasoning text. TTFO=start→first nonempty non-reasoning content. Thinking disabled should make them equal. Record headers, first bytes, first reasoning, last token, DONE and end times separately. Native internal first-token clocks are not substituted for client clocks.
- Per-request native prefill=prompt_n/(prompt_ms/1000); native decode=predicted_n/(predicted_ms/1000), from that request's own SSE timings only. No fallback to stale global last_timings; cached history is not counted as new prefill tokens. Engine rates differ from end-to-end output throughput.
- Report all20rows, sample mean/median/min/max/P95, and pooled native rates=sum tokens/sum corresponding native seconds. Cache_n must be0 for the cold subset; contaminated rows remain in the full table. Retrieval accuracy, mechanical completion and4096/full-window coverage are separate.
- Cold means KV-cache miss, not model-loading cold start or empty OS weight cache. Different nonce prevents shared initial cache blocks; native cache_n and usage cached_tokens verify this rather than assuming it.

## Observation and limits

Nominal1Hz actual-timestamp CPU/pressure/swap/global GPU/native RSS/physical footprint/process identity and selected status. Counters overlap and are never added. No zero-filled temperature/no-throttling claim. Safety abort: critical memory pressure15consecutive samples, native footprint or native-tree RSS>115GiB, swap growth>8GiB. Close only this runner's current HTTP socket and stop later attempts; no broad process kill or model restart to rescue results. Whole-request deadline900s. Native identity change is a failure. Fixed order/background load/MTP acceptance/repetitive SQL can affect results; no pure engine/quantisation/general-quality causal claim.

Sources checked2026-10-26: NVIDIA AIPerf TTFT/TTFO https://docs.nvidia.com/aiperf/reference/ai-perf-metrics-reference ; vLLM client timing/cache warning https://docs.vllm.ai/en/v0.31.0/benchmarking/cli/ . This task requests local measurement records, not a public upload. Protocol/harness freeze in local Git before any formal request. Report setup/measurement deviations explicitly.
