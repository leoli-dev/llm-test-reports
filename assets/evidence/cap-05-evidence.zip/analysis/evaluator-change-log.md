# Independent evaluator changes, after all candidates frozen

No model reruns, candidate source fixes or tailored feedback occurred. These are observer corrections, not successful-product evidence by themselves.

- Initial server launcher used a Python without psutil. No candidate server started; connection-refused capture attempts were setup failures. Launcher then used the existing Strata control Python with psutil. All six complete captures were rerun after readiness.
- Initial movie UI automation did not await rating rerender before typing, so draft comments were cleared. Strata logout/hash navigation also raced. Add explicit render waits; preserve movie-browser-first-attempt.txt. Corrected visible comment submission and XSS escaping are recorded in browser-flow.json. No application fix.
- First Splash gameplay readiness called optional getState before boot created world. Preserve play-attempt-early-hook.json and the failure console; change observer readiness to catch early hook errors. Normal page startup and corrected play completed with no page errors. This early observer exception is not counted as a fatal game UI bug.
- First Strata tool-chain observer looked for button names matching recipe names; actual buttons say Craft. Wrong-selector errors retained in followup-results.json. Corrected row-scoped selector succeeds in followup-craft-corrected.json, producing wood tools. A later stone pickaxe is legitimately disabled when one stick remains; not marked a defect.
- First Splash wood scout landed on leaves and aimed above the trunk. Corrected approach/aim attempts, including failures, retained in wood-aim-corrected.json. Assistive teleports/material grants never establish an unassisted full progression run.
- No-pause supplemental check captures panel visibility before closing it, correcting an earlier observer's post-close visibility field.
- High-world screenshot retaken after closing Strata's menu overlay. Same y=400 fixture and unchanged sources; both copies restore original save data after the check.

Formal inference analysis correction: Splash timings.prompt_n means total input; Strata prompt_n means uncached input. Normalize both using usage.prompt_tokens minus cache_n, with backend source proofs in measurement-definitions.json. Earlier negative uncached analysis was an observer bug; raw responses unchanged. All 10486 measurement integrity checks passed after normalization.

Archive-only acceptance corrections: fixed preview port was already occupied by an unrelated Node service; it was left untouched and the preview switched to an OS-assigned free port. The first multi-document test selected a single-document experiment; the fixture was corrected to the existing TET-01 pair. Neither required a site code change. Archive acceptance is published separately from the evidence ZIP to avoid a self-referential ZIP checksum.
