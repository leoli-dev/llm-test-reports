from pathlib import Path
import psutil,json,time,sys
E=Path(__file__).resolve().parents[1];rows=[]
for c in json.loads((E/'private/evaluation-servers.json').read_text()):
 try:
  p=psutil.Process(c['pid']);assert abs(p.create_time()-c['created'])<.001 and p.cwd()==c['cwd'];p.terminate();p.wait(6);rows.append({'case':c['case'],'stopped_owned_pid':c['pid'],'identity_verified':True})
 except psutil.NoSuchProcess:rows.append({'case':c['case'],'already_stopped':True})
x=json.loads((E/'private/lifecycle-monitor.json').read_text())
try:
 p=psutil.Process(x['pid']);assert abs(p.create_time()-x['create_time'])<.001 and 'lifecycle_monitor.py' in ' '.join(p.cmdline());p.terminate();p.wait(6);rows.append({'lifecycle_monitor_stopped':True,'identity_verified':True})
except psutil.NoSuchProcess:rows.append({'lifecycle_monitor_already_stopped':True})
from runner import api
s=api('strata','/v1/status');rows.append({'original_strata':{k:s.get(k)for k in ['state','model','context','in_flight']}})
try:z=api('splash','/status');rows.append({'splash_unexpected_active':True})
except Exception:rows.append({'splash_stopped':True})
(E/'analysis/cleanup.json').write_text(json.dumps(rows,indent=2));print(rows)
