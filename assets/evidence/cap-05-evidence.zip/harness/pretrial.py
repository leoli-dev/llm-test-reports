from pathlib import Path
import datetime,json,sys,time,urllib.request,threading,subprocess
from resource_collector import ResourceCollector
E=Path(__file__).resolve().parents[1];L=Path('/Users/benchmark/local_llms');D=E/'pretrial';D.mkdir(exist_ok=True)
label=sys.argv[1];profile=sys.argv[2];port={'splash':8084,'strata':8085}[label];key=(L/label/'data/api-key').read_text().strip();headers={'Content-Type':'application/json','Authorization':'Bearer '+key} if key else {'Content-Type':'application/json'}
def api(path):
 with urllib.request.urlopen(urllib.request.Request(f'http://127.0.0.1:{port}'+path,headers=headers),timeout=5) as f:return json.load(f)
pid=json.loads((L/'splash/data/service.json').read_text())['pid'] if label=='splash' else __import__('runner').backend_identity(label)
stop=threading.Event();c=ResourceCollector(pid,'mltf',status_callback=lambda:api('/status' if label=='splash' else '/v1/status'),engine_name='splash' if label=='splash' else 'strata')
def sample():
 with (D/f'{label}-{profile}-resources.jsonl').open('w') as f:
  while not stop.is_set():
   t=time.monotonic();f.write(json.dumps(c.collect(stage='pretrial',phase=profile))+'\n');f.flush();stop.wait(max(.05,1-time.monotonic()+t))
threading.Thread(target=sample,daemon=True).start()
rows=[]
try:
 for trial in range(3):
  code='\n'.join(f'// record {trial}-{i}: id={i}, title="Cinema inventory {i}", watched=false, score=null; validate permissions and audit edits.' for i in range(240))
  payload={'model':'qwen3.8-flash-next-iq3_s','messages':[{'role':'system','content':'You are a coding assistant. Output code only, do not finish early.'},{'role':'user','content':code+'\nWrite a complete JavaScript module for a secure movie rating repository with SQL parameterization, transactions, authorization and validation. Include many concrete functions and tests.'}],'max_tokens':512,'temperature':0,'reasoning_effort':'none','stream':True,'stream_options':{'include_usage':True}}
  (D/f'{label}-{profile}-{trial}-request.json').write_text(json.dumps(payload));start=time.monotonic();first=None;events=[]
  with urllib.request.urlopen(urllib.request.Request(f'http://127.0.0.1:{port}/v1/chat/completions',data=json.dumps(payload).encode(),headers=headers),timeout=600) as res:
   for raw in res:
    if raw.startswith(b'data:') and raw[5:].strip()!=b'[DONE]':
     ev=json.loads(raw[5:]);t=time.monotonic()-start;events.append({'seconds':t,'event':ev})
     if first is None and any(any((x.get('delta') or {}).get(k) for k in ['content','reasoning_content','tool_calls']) for x in ev.get('choices',[])):first=t
  status=api('/status' if label=='splash' else '/v1/status');row={'trial':trial,'ttft_s':first,'wall_s':time.monotonic()-start,'usage':next((x['event']['usage'] for x in reversed(events) if x['event'].get('usage')),None),'metrics':next((x['event']['metrics'] for x in reversed(events) if x['event'].get('metrics')),None),'timings':next((x['event']['timings'] for x in reversed(events) if x['event'].get('timings')),None),'status':status};rows.append(row)
  (D/f'{label}-{profile}-{trial}-events.json').write_text(json.dumps(events));(D/f'{label}-{profile}-results.json').write_text(json.dumps(rows,indent=2));print(json.dumps({k:v for k,v in row.items() if k!='status'}),flush=True)
finally:stop.set()
