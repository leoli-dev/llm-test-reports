from pathlib import Path
import json,collections,time
E=Path(__file__).resolve().parents[1]
def snapshot(p):
 for attempt in range(4):
  try:return json.loads(p.read_text())
  except (ValueError,OSError):time.sleep(.03)
 return {'read_pending':True}
print(snapshot(E/'raw/matrix-progress.json'))
for c in json.loads((E/'matrix.json').read_text()):
 d=E/'raw'/c['id']/'formal'
 if not (d/'progress.json').exists():continue
 p=snapshot(d/'progress.json');print({k:p.get(k) for k in ['runid','phase','elapsed_s','tool_starts','assistant_output_tokens','reason']})
 if p.get('reason'):continue
 es=[]
 for s in (d/'pi-events.jsonl').read_text().splitlines():
  try:es.append(json.loads(s))
  except Exception:pass
 ended={r.get('toolCallId') for r in es if r.get('type')=='tool_execution_end'};print('active_tools',[{'tool':r.get('toolName'),'id':r.get('toolCallId')} for r in es if r.get('type')=='tool_execution_start' and r.get('toolCallId') not in ended]);tools=[r for r in es if r.get('type')=='tool_execution_start'];print('recent_tools',[{'tool':r.get('toolName'),'path':r.get('args',{}).get('path'),'cmd':r.get('args',{}).get('command','')[:150]} for r in tools[-3:]])
 for s in reversed((d/'resources.jsonl').read_text().splitlines()):
  try:r=json.loads(s);break
  except Exception:pass
 print('last_sample',{k:r.get(k) for k in ['gpu_device_utilization_percent','system_cpu_percent','process_physical_footprint_bytes','memory_pressure_name','swap_delta_bytes','errors']})
 ns=r.get('native_status') or {};print('native_activity',ns.get('activity',ns.get('scheduler')));print('request_results',len(list((d/'requests').glob('*/result.json'))))
