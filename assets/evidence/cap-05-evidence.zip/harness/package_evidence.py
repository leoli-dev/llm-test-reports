from pathlib import Path
import json,hashlib,shutil,zipfile,re
E=Path(__file__).resolve().parents[1];D=Path('/Users/benchmark/Code/llm-test-reports');P=E/'publication';P.mkdir(exist_ok=True);stage=P/'evidence';stage.mkdir(exist_ok=True);files=[]
def sha(b):return hashlib.sha256(b).hexdigest()
def write(rel,b):
 p=stage/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);files.append(rel)
def add(src,rel=None):
 src=Path(src);rel=rel or str(src.relative_to(E));b=src.read_bytes()
 if src.suffix.lower() not in ['.png','.jpg','.jpeg']:
  s=b.decode();s=s.replace('/Users/benchmark','/Users/benchmark');s=re.sub(r'/tmp/benchmark-browser-profile"\]]+', '/tmp/benchmark-browser-profile',s);b=s.encode()
 write(rel,b)
for name in ['PLAN.md','COMMON.md','BRIEF-movie.md','BRIEF-voxel.md','BRIEF-qingming.md','phase-1.txt','phase-2.txt','phase-3.txt','matrix.json'] :add(E/name)
for p in (E/'harness').glob('*'):
 if p.suffix in ['.py','.cjs']:add(p)
for name in ['host.json','power-mode.json','runtime-provenance.json','pretrial-summary.json','baseline-equivalence.json','seed-integrity.json','target-tensor-types.json','strata-pack-conversions.json','splash-latest-release.json']:add(E/'configs'/name)
for old in (stage/'analysis').glob('archive-*'):
 if old.is_file():old.unlink()
for p in (E/'analysis').glob('*'):
 if p.is_file() and p.suffix in ['.json','.csv','.md','.txt'] and not p.name.startswith('archive-'):add(p)
for name in ['scores.json','review-findings.json','source-review.txt','final-integrity.json']:add(E/'scoring'/name)
for d in (E/'scoring').iterdir():
 if not d.is_dir():continue
 add(d/'source-integrity.json')
 for p in (d/'independent').glob('*'):
  if p.suffix in ['.json','.png']:add(p)
for mode in ['splash-resident','splash-ple512m','strata-native']:
 data=json.loads((E/'pretrial'/(mode+'-results.json')).read_text());safe=[{k:r[k]for k in ['trial','ttft_s','wall_s','usage','timings']}for r in data];write('pretrial/'+mode+'-timings.json',json.dumps(safe,indent=2).encode())
for case in json.loads((E/'matrix.json').read_text()):
 for f in ['smoke/checks.json']:
  p=E/'raw'/case['id']/f
  if p.exists():add(p)
# Log only the timeout evidence needed to assess the intervention, excluding process command inventories.
timeouts=[]
for line in (E/'raw/tool-timeout-interventions.jsonl').read_text().splitlines():
 r=json.loads(line);safe={k:r[k]for k in ['at','runid','threshold_s','age_s','event','tool_command','note']};safe['verified_descendant_count']=len(r.get('descendants',[]));timeouts.append(safe)
write('supervision/tool-timeouts.json',json.dumps(timeouts,indent=2).encode());add(E/'raw/service-switches.json','supervision/service-switches.json')
record=Path('/Users/benchmark/local_llms/splash/records/2026-10-26-iq3s-comparison')
for name in ['weight-provenance.json','requirements.lock.txt','build.log','environment-install.log']:
 add(record/name,'installation/'+name)
for name in ['startup-compiler-sample.txt','startup-native-sample.txt']:
 old=stage/'installation'/name
 if old.exists():old.unlink()
startup={name:{'sha256':sha((record/name).read_bytes()),'MTLCompilerService_observed':'MTLCompilerService' in (record/name).read_text(errors='replace')}for name in ['startup-compiler-sample.txt','startup-native-sample.txt']}
write('installation/startup-summary.json',json.dumps({'weight_load_seconds':14.34,'first_pipeline_compile_approx_minutes':3,'private_sample_hashes':startup,'process_inventories_excluded':True},indent=2).encode())
add(Path('/Users/benchmark/local_llms/splash/README.md'),'installation/local-Splash-README.md')
write('README.md',b'''# CAP-05 sanitized evidence\n\nAll six candidate sources were frozen before independent review. Complete sources, Git bundles, raw request bodies/SSE and Pi sessions remain only in the local experiment. This package includes original independent PNGs, result JSON, protocol, evaluator corrections, selected setup provenance and numeric timing/resources. Paths generalized to /Users/benchmark; numeric observations and PNG bytes unchanged. No credentials, model weights/caches, live DBs or full process command inventories. Source-only finding F09 was not a 60002-edit live test. Reproduction scripts require matching local runtime/dependency paths.\n''')
manifest={str(p.relative_to(stage)):{'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())}for p in sorted(stage.rglob('*'))if p.is_file() and p.name!='manifest.json'}
write('manifest.json',json.dumps(manifest,indent=2).encode())
zip_path=D/'assets/evidence/cap-05-evidence.zip';zip_path.parent.mkdir(exist_ok=True)
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED,compresslevel=7) as z:
 for p in sorted(stage.rglob('*')):
  if p.is_file():z.write(p,str(p.relative_to(stage)))
with zipfile.ZipFile(zip_path) as z:
 assert z.testzip() is None
 for name,v in manifest.items():assert sha(z.read(name))==v['sha256']
# Individual downloads plus lossless copies of every report figure.
for source,dest in [('analysis/requests.csv','requests.csv'),('analysis/resources.csv','resources.csv'),('analysis/metrics.json','metrics.json'),('scoring/scores.json','scores.json'),('scoring/source-review.txt','source-review.txt')]:
 b=(stage/source).read_bytes();(D/'assets/evidence'/('cap-05-'+dest)).write_bytes(b)
fig=D/'assets/figures/cap-05';fig.mkdir(exist_ok=True);images=[]
for p in (E/'analysis/figures').glob('*.png'):
 shutil.copyfile(p,fig/p.name);images.append({'file':p.name,'source':str(p.relative_to(E)),'sha256':sha(p.read_bytes())})
for case,names in {'movie-splash':['detail-reviewed','mobile-detail'],'movie-strata':['detail-reviewed','mobile-detail'],'voxel-splash':['play-initial','followup-water','high-world-400','play-mobile'],'voxel-strata':['play-initial','high-world-400','play-mobile'],'qingming-splash':['view-bridge','view-city','view-mobile-bridge'],'qingming-strata':['view-bridge','view-market','view-mobile-bridge']}.items():
 for n in names:
  source=E/'scoring'/case/'independent'/(n+'.png');target=fig/(case+'-'+n+'.png');shutil.copyfile(source,target);images.append({'file':target.name,'source':str(source.relative_to(E)),'sha256':sha(source.read_bytes())});assert source.read_bytes()==target.read_bytes()
publication={'experiment':'CAP-05','local_only_no_push':True,'transforms':['/Users/benchmark -> /Users/benchmark in textual evidence','temporary browser profile paths generalized','full process command inventories omitted','private Pi sessions/request bodies/SSE/auth/config secrets/DBs/weights/caches/full product source excluded','PNG pixels and numeric results unchanged','archive reader acceptance published separately to avoid a self-referential ZIP checksum'],'zip':{'bytes':zip_path.stat().st_size,'sha256':sha(zip_path.read_bytes()),'entries':len(manifest)+1,'manifest_verified':True},'figures':images,'source_artifacts':'Separate local repositories, tar archives and Git bundles; no artifact was pushed'}
(D/'assets/evidence/cap-05-publication.json').write_text(json.dumps(publication,indent=2));(P/'publication.json').write_text(json.dumps(publication,indent=2));print(json.dumps({'zip':publication['zip'],'figures':len(images)},indent=2))
