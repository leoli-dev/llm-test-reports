import subprocess,json,psutil
from pathlib import Path
E=Path(__file__).resolve().parents[1];PY='/Users/benchmark/local_llms/strata/runtime/terminal/0.1.51/python/bin/python3'
assert (E/'configs/pretrial-summary.json').exists()
assert not (E/'raw/matrix-complete.json').exists()
with (E/'raw/matrix-driver.log').open('ab') as out:p=subprocess.Popen([PY,'-u','harness/matrix_runner.py'],cwd=E,stdout=out,stderr=out,stdin=subprocess.DEVNULL,start_new_session=True)
(E/'private/matrix-driver.json').write_text(json.dumps({'pid':p.pid,'create_time':psutil.Process(p.pid).create_time()}));print('Matrix driver started',p.pid)
