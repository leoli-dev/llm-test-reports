from pathlib import Path
import csv,json,datetime,statistics
E=Path(__file__).resolve().parents[1];allrows=[];intervals={}
keys=['stage','phase','engine_pid','process_cpu_percent','process_rss_bytes','process_physical_footprint_bytes','process_tree_rss_sum_bytes','process_tree_physical_footprint_sum_bytes','frontend_cpu_percent','gpu_device_utilization_percent','gpu_renderer_utilization_percent','gpu_tiler_utilization_percent','gpu_alloc_system_memory_bytes','gpu_in_use_system_memory_bytes','gpu_in_use_driver_memory_bytes','system_cpu_percent','memory_pressure_name','memory_pressure_level','swap_used_bytes','swap_delta_bytes','engine_allocated_bytes','engine_allocation_peak_bytes','sample_duration_seconds','native_status_local_age_seconds','native_status_stale']
for c in json.loads((E/'matrix.json').read_text()):
 d=E/'raw'/c['id']/'formal'
 if not (d/'summary.json').exists():continue
 launch=json.loads((d/'launch.json').read_text());zero=datetime.datetime.fromisoformat(launch['at']).timestamp();rows=[];ts=[]
 for line in (d/'resources.jsonl').read_text().splitlines():
  r=json.loads(line);t=r['unix_seconds'];ts.append(r['monotonic_seconds']);row={'run':c['id'],'utc':datetime.datetime.fromtimestamp(t,datetime.timezone.utc).isoformat(),'unix_s':t,'elapsed_s':t-zero,**{k:r.get(k) for k in keys}}
  v=r.get('system_virtual_memory',{});row.update({f'system_{k}_bytes':v.get(k) for k in ['total','available','used','free','active','inactive','wired']});row['errors']=json.dumps(r.get('errors',{}),sort_keys=True);rows.append(row)
 gaps=[b-a for a,b in zip(ts,ts[1:])];intervals[c['id']]={'samples':len(rows),'covered_span_s':ts[-1]-ts[0] if ts else None,'mean_interval_s':statistics.mean(gaps) if gaps else None,'max_interval_s':max(gaps) if gaps else None,'gaps_over_2s':sum(g>2 for g in gaps),'note':'Nominal1Hz. Resource summaries include10s pre-development baseline; request interval subsets exclude it.'}
 with (E/'analysis'/f'{c["id"]}-resources.csv').open('w') as f:w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
 allrows.extend(rows)
if allrows:
 with (E/'analysis/resources.csv').open('w') as f:w=csv.DictWriter(f,fieldnames=allrows[0].keys());w.writeheader();w.writerows(allrows)
(E/'analysis/sampling-intervals.json').write_text(json.dumps(intervals,indent=2));print('Exported',len(allrows),'resource rows across',len(intervals),'frozen cases')
