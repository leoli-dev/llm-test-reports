from pathlib import Path
import json,subprocess,sys,time,traceback,hashlib
from runner import api,backend_identity,stamp,dump
E=Path(__file__).resolve().parents[1];L=Path('/Users/benchmark/local_llms');PY=sys.executable
steps=[]
def step(name,cmd,timeout=600,check=True):
 dump(E/'raw/matrix-progress.json',{'at':stamp(),'phase':name});t=time.monotonic()
 with (E/'raw'/(name+'.log')).open('ab') as f:r=subprocess.run(cmd,cwd=E,stdout=f,stderr=subprocess.STDOUT,timeout=timeout)
 row={'name':name,'at':stamp(),'wall_s':time.monotonic()-t,'exit':r.returncode};steps.append(row);dump(E/'raw/service-switches.json',steps);print(json.dumps(row),flush=True)
 if check:r.check_returncode()
 return r.returncode

def verify_smoke(case):
 r=E/'raw'/case['id']/'smoke';events=[json.loads(x) for x in (r/'pi-events.jsonl').read_text().splitlines()];p=r/'smoke-project/probe.txt'
 checks={'write':p.exists() and p.read_text().strip()=='391','bash_readback':any(v.get('type')=='tool_execution_end' and v.get('toolName')=='bash' and not v.get('isError') for v in events),'context':any(v.get('type')=='response' and v.get('id')=='state-before' and ((v.get('data') or {}).get('model') or {}).get('contextWindow')==262144 for v in events)}
 dump(r/'checks.json',checks)
 if not all(checks.values()):raise RuntimeError('Smoke verification failed '+str(checks))

def main():
 checked=set();current='splash';fatal=None;initial={}
 for label in ['splash','strata']:
  try:initial[label]=api(label,'/status' if label=='splash' else '/v1/status')
  except Exception as ex:initial[label]={'error':repr(ex)}
 dump(E/'configs/pre-matrix-services.json',initial)
 try:
  for case in json.loads((E/'matrix.json').read_text()):
   # Restart even when the previous cell used the same engine: cold session boundary.
   if current:step('stop-before-'+case['id'],[str(L/current/'stop.sh')])
   current=case['label'];step('start-'+case['id'],[str(L/current/'start.sh')],timeout=600)
   status=api(current,'/v1/status' if current=='strata' else '/status');ctx=status.get('context',{}).get('native') if current=='strata' else status.get('maximum_context_tokens');assert ctx==262144,('Native context mismatch',current,ctx)
   dump(E/'configs'/('ready-'+case['id']+'.json'),{'at':stamp(),'status':status,'root_pid':backend_identity(current)})
   if current not in checked:
    step('smoke-'+case['id'],[PY,'-u','harness/runner.py',case['id'],'smoke'],timeout=300);verify_smoke(case);checked.add(current)
    step('post-smoke-stop-'+case['id'],[str(L/current/'stop.sh')]);step('post-smoke-start-'+case['id'],[str(L/current/'start.sh')],timeout=600)
   step('formal-'+case['id'],[PY,'-u','harness/runner.py',case['id'],'formal'],timeout=3680)
   summary=json.loads((E/'raw'/case['id']/'formal/summary.json').read_text());dump(E/'raw'/('cell-complete-'+case['id']+'.json'),{k:v for k,v in summary.items() if k!='backend_after'})
   if summary['reason']=='resource_abort':raise RuntimeError('Resource safety abort; preserve incomplete candidate')
 except BaseException as ex:
  fatal=repr(ex);dump(E/'raw/matrix-error.json',{'at':stamp(),'error':fatal,'traceback':traceback.format_exc()});print('MATRIX_ERROR '+fatal,flush=True)
 finally:
  if current:
   try:step('final-stop-'+current,[str(L/current/'stop.sh')],check=False)
   except Exception as ex:dump(E/'raw/final-stop-error.json',{'error':repr(ex)})
  # The user's previously running default service was Strata.
  if 'Resource safety abort' not in (fatal or ''):step('restore-original-strata',[str(L/'strata/start.sh')],check=False)
  cells=[]
  for c in json.loads((E/'matrix.json').read_text()):
   p=E/'raw'/c['id']/'formal/summary.json';cells.append({'id':c['id'],'summary':json.loads(p.read_text()) if p.exists() else None})
  dump(E/'raw/matrix-complete.json',{'at':stamp(),'fatal':fatal,'cells':cells,'all_six_frozen':all((E/'raw'/c['id']/'formal/source-snapshot.json').exists() for c in cells),'global_pi_unchanged':hashlib.sha256((Path.home()/'.pi/agent/models.json').read_bytes()).hexdigest()==json.loads((E/'configs/global-integrity-before.json').read_text())['pi_models_sha256']})
 if fatal:raise SystemExit(1)
if __name__=='__main__':main()
