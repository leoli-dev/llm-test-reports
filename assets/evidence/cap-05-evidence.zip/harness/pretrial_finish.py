from pathlib import Path
import json,subprocess,sys,time,statistics
E=Path(__file__).resolve().parents[1];L=Path('/Users/benchmark/local_llms')
# Called only once the three streaming trials have completed.
assert len(json.loads((E/'pretrial/splash-ple512m-results.json').read_text()))==3
subprocess.run([str(L/'splash/stop.sh')],check=True)
p=L/'splash/config.json';c=json.loads(p.read_text());c['ple_memory']='auto';c['expert_memory']='auto';p.write_text(json.dumps(c,indent=2)+'\n')
subprocess.run([str(L/'strata/start.sh')],check=True)
with (E/'pretrial-strata.log').open('w') as f:subprocess.run([sys.executable,'-u','harness/pretrial.py','strata','native'],cwd=E,stdout=f,stderr=subprocess.STDOUT,check=True)
subprocess.run([str(L/'strata/stop.sh')],check=True)
summary=[]
for label,profile in [('splash','resident'),('splash','ple512m'),('strata','native')]:
 rs=json.loads((E/'pretrial'/f'{label}-{profile}-results.json').read_text());row={'engine':label,'profile':profile,'n':len(rs),'mean_ttft_s':statistics.mean(r['ttft_s'] for r in rs),'total_prompt_tokens':sum(r['timings']['prompt_n'] for r in rs),'cached_tokens':sum(r['timings']['cache_n'] for r in rs),'output_tokens':sum(r['timings']['predicted_n'] for r in rs),'prefill_tps':sum(r['timings']['prompt_n']-r['timings']['cache_n'] for r in rs)/sum(r['timings']['prompt_ms']/1000 for r in rs),'decode_tps':sum((r.get('metrics') or {}).get('decode',{}).get('tokens',r['timings']['predicted_n']) for r in rs)/sum(r['timings']['predicted_ms']/1000 for r in rs)};summary.append(row)
(E/'configs/pretrial-summary.json').write_text(json.dumps({'trials':summary,'selected_splash':c,'selection':'Resident mode retains every expert and PLE. Best observed decode among tested Splash modes, if corroborated by trial data; no exhaustive global optimum claim. Three cold-KV coding trials per mode. Native timing definitions differ between engines; expose original timings.'},indent=2));print(json.dumps(summary,indent=2))
# Launch the selected resident service. Matrix restarts it before each formal cell.
subprocess.run([str(L/'splash/start.sh')],check=True)
