from pathlib import Path
import tempfile,importlib.util,json,threading,urllib.request
from http.server import ThreadingHTTPServer
E=Path(__file__).resolve().parents[1]
for engine in ['splash','strata']:
 source=E/'scoring'/('movie-'+engine)/'frozen/server.py';spec=importlib.util.spec_from_file_location('hidden_'+engine,source);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
 with tempfile.TemporaryDirectory() as td:
  setattr(m,'DB' if engine=='splash' else 'DB_PATH',td+'/fixture.db');m.init_db();m.TMDB_KEY='fixture';m.MODE='tmdb'
  item={'id':999002,'title':'Hidden Fixture','overview':'provider test','release_date':'2020-01-01','poster_path':'/fixture.jpg'}
  if engine=='splash':
   h=object.__new__(m.H);h.headers={};mid=h.upsert_tmdb(item)['id'];m.H.tmdb=lambda self,p,params:{'results':[item]}
   c=m.db();c.execute('UPDATE movies SET hidden=1 WHERE id=?',(mid,));c.commit();c.close()
  else:
   c=m.db();c.execute("INSERT INTO movies(source,ext_id,title,hidden,created_at) VALUES('tmdb','999002','Hidden Fixture',1,0)");c.commit();c.close();m.tmdb_get=lambda p:{'results':[item]}
  srv=ThreadingHTTPServer(('127.0.0.1',0),m.H);t=threading.Thread(target=srv.serve_forever,daemon=True);t.start()
  with urllib.request.urlopen(f'http://127.0.0.1:{srv.server_port}/api/search?q=Hidden') as r:data=json.load(r)
  srv.shutdown();srv.server_close();record={'kind':'original HTTP handler with controlled provider IO and hidden fixture row','response':data,'hidden_leaked':bool(data['results'])};(E/'scoring'/('movie-'+engine)/'independent/provider-hidden-fixture.json').write_text(json.dumps(record,indent=2));print(engine,record)
