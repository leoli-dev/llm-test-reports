from pathlib import Path
import json,csv
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
E=Path(__file__).resolve().parents[1];O=E/'analysis/figures';O.mkdir(exist_ok=True)
m=json.loads((E/'analysis/metrics.json').read_text());colors={'splash':'#b55e32','strata':'#39768d'}
fig,ax=plt.subplots(1,3,figsize=(14,4.2),layout='constrained')
for i,(field,title,unit) in enumerate([('wall_s','Development wall time','minutes'),('pooled_native_decode_tps','Native decode (mixed agent workload)','tokens / second'),('ttft','First generated event, median','seconds')]):
 for x,d in enumerate(m):
  v=d[field]['median'] if field=='ttft' else d[field]/60 if field=='wall_s' else d[field]
  ax[i].bar(x,v,color=colors[d['label']]);ax[i].text(x,v,f'{v:.2f}',ha='center',va='bottom',fontsize=8)
 ax[i].set_xticks(range(6),[d['run'].replace('-','\n') for d in m],fontsize=8);ax[i].set_title(title,fontsize=11);ax[i].set_ylabel(unit);ax[i].spines[['top','right']].set_visible(False)
fig.suptitle('CAP-05 · Same IQ3_S source, M5 Max · n=1 per task/engine',fontsize=14);fig.savefig(O/'performance.png',dpi=160);plt.close(fig)

for kind in ['memory','utilization']:
 fig,axes=plt.subplots(3,2,figsize=(13,10),layout='constrained')
 for ax,d in zip(axes.flat,m):
  rows=list(csv.DictReader((E/'analysis'/(d['run']+'-resources.csv')).open()))
  fields=[('system_used_bytes','System used','#222222'),('process_physical_footprint_bytes','Native footprint','#b55e32'),('process_rss_bytes','Native RSS','#39768d'),('gpu_in_use_system_memory_bytes','GPU driver in-use','#888b42')] if kind=='memory' else [('gpu_device_utilization_percent','Whole-device GPU','#39768d'),('system_cpu_percent','System CPU','#b55e32')]
  for field,label,color in fields:
   pts=[(float(r['elapsed_s'])/60,float(r[field])/(2**30 if kind=='memory' else 1)) for r in rows if r[field] and float(r['elapsed_s'])>=0]
   ax.plot([p[0] for p in pts],[p[1] for p in pts],label=label,color=color,lw=.8,alpha=.8)
  for r in rows:
   if r['memory_pressure_name']=='warn':ax.axvline(float(r['elapsed_s'])/60,color='#c12929',alpha=.35,lw=.7)
  ax.set_title(d['run']);ax.set_ylim(0,128 if kind=='memory' else 105);ax.set_xlabel('elapsed minutes');ax.set_ylabel('GiB (overlapping, do not add)' if kind=='memory' else 'percent');ax.spines[['top','right']].set_visible(False)
 axes.flat[0].legend(fontsize=8,loc='lower right');fig.suptitle('CAP-05 · '+('Unified memory counters; red ticks = warning samples' if kind=='memory' else 'Whole-device GPU and system CPU; agent tools included'));fig.savefig(O/(kind+'.png'),dpi=155);plt.close(fig)
