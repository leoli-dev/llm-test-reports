from pathlib import Path
import json,time,subprocess,urllib.request,urllib.error,http.cookiejar
import psutil
E=Path(__file__).resolve().parents[1];reg=json.loads((E/'private/evaluation-servers.json').read_text())
for engine,port in [('splash',4301),('strata',4302)]:
 c=next(x for x in reg if x['case']=='movie-'+engine);p=psutil.Process(c['pid']);assert abs(p.create_time()-c['created'])<.001 and p.cwd()==c['cwd']
 admin=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()));alice=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
 def req(op,path,body=None):
  z=op.open(urllib.request.Request(f'http://127.0.0.1:{port}'+path,data=json.dumps(body).encode() if body is not None else None,headers={'Content-Type':'application/json'}));return json.load(z)
 for op,name,pw in [(admin,'admin','admin123'),(alice,'alice','alice123')]:req(op,'/api/login',{'username':name,'password':pw})
 def collect():return {'library':req(alice,'/api/library'),'movies':req(admin,'/api/admin/movies'),'logs':req(admin,'/api/admin/logs')}
 before=collect();p.terminate();p.wait(5);log=open(E/'scoring'/c['case']/'independent/server.log','a');n=subprocess.Popen(['python3','server.py'],cwd=c['cwd'],stdout=log,stderr=subprocess.STDOUT,start_new_session=True);c.update(pid=n.pid,created=psutil.Process(n.pid).create_time());(E/'private/evaluation-servers.json').write_text(json.dumps(reg,indent=2));time.sleep(.7);after=collect();result={'kind':'same DB and cookies across verified server process restart','before':before,'after':after,'identical':before==after,'at':time.time()};(E/'scoring'/c['case']/'independent/persistence-restart.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(engine,result['identical'])
 # Confirm whether a comment lock applies to admin too; restore it afterwards.
 mid=11 if engine=='splash' else 17
 def act(lock):return req(admin,f'/api/admin/movies/{mid}/comments',{'disabled':lock}) if engine=='splash' else req(admin,f'/api/admin/movies/{mid}',{'action':'lock' if lock else 'unlock'})
 act(True)
 try:
  result=req(admin,f'/api/movies/{mid}/'+('reviews' if engine=='splash' else 'comment'),{'body':'locked-admin-fixture'});status=200
 except urllib.error.HTTPError as e:status=e.code;result=json.load(e)
 act(False);(E/'scoring'/c['case']/'independent/admin-lock.json').write_text(json.dumps({'status':status,'response':result,'lock_restored':False},indent=2));print('admin lock',engine,status)
