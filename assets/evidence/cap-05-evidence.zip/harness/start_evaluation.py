import pathlib,subprocess,json,time,sys
sys.path.insert(0,'/Users/benchmark/local_llms/splash/source/.venv/lib/python3.13/site-packages')
import psutil
E=pathlib.Path(__file__).resolve().parents[1]; rows=[]
for case in ['movie-splash','movie-strata','voxel-strata','voxel-splash','qingming-splash','qingming-strata']:
 d=E/'scoring'/case/'frozen'; out=E/'scoring'/case/'independent';out.mkdir(exist_ok=True)
 cmd=['node','server.cjs'] if case=='qingming-strata' else ['python3','server.py']
 f=open(out/'server.log','w');p=subprocess.Popen(cmd,cwd=d,stdout=f,stderr=subprocess.STDOUT,start_new_session=True);rows.append(dict(case=case,pid=p.pid,created=psutil.Process(p.pid).create_time(),cwd=str(d)))
(E/'private'/'evaluation-servers.json').write_text(json.dumps(rows,indent=2));time.sleep(2);print(json.dumps(rows))
