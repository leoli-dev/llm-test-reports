from pathlib import Path
import json,re,hashlib,collections
E=Path(__file__).resolve().parents[1];D=Path('/Users/benchmark/Code/llm-test-reports');base='2026-10-26-flash-next-iq3s-splash-strata-triad';en=(D/'reports/originals'/(base+'.md')).read_text();cn=(D/'reports/originals'/(base+'_CN.md')).read_text();rows=json.loads((E/'scoring/scores.json').read_text())['criteria'];checks=[]
def check(name,ok,detail=None):checks.append({'name':name,'pass':bool(ok),'detail':detail})
for text,lang in [(en,'en'),(cn,'cn')]:
 actual=[]
 for line in text.splitlines():
  if re.match(r'\| [MVQ]\d\d ',line):
   cells=line.split('|');actual.append((cells[1].strip().split()[0],*[float(cells[k])for k in [2,3,4]]))
 expected=[(r['id'],r['weight'],r['splash'],r['strata'])for r in rows];check(lang+':85 weighted criteria match structured source',actual==expected,len(actual))
 check(lang+':no private user path','/Users/benchmark'not in text)
 check(lang+':complete heading structure',len(re.findall(r'^## ',text,re.M))==17,len(re.findall(r'^## ',text,re.M)))
nums=lambda s:re.findall(r'(?<![A-Za-z])\d+(?:[,.]\d+)*(?:×\d+)?',s)
a=json.loads((E/'analysis/tables.json').read_text());b=json.loads((E/'analysis/tables_CN.json').read_text())
for k in a:check('table numeric parity:'+k,nums(a[k])==nums(b[k]))
images=lambda s:re.findall(r'!\[[^\]]*\]\(([^)]+)\)',s)
check('identical 20 figure references',images(en)==images(cn)and len(images(en))==20,len(images(en)))
check('original source-code fences identical',re.findall(r'```[\s\S]*?```',en)==re.findall(r'```[\s\S]*?```',cn))
check('64-character source hashes identical',set(re.findall(r'\b[0-9a-f]{64}\b',en))==set(re.findall(r'\b[0-9a-f]{64}\b',cn)))
prov=json.loads((E/'configs/runtime-provenance.json').read_text());hashes=set(re.findall(r'\b[0-9a-f]{64}\b',en));expected={r['sha256']for r in prov['weights']}|{'d6723f2a359eaf33ec0c95f22ae8edda896774020c552296a85e1913b4d3186f'};check('model hashes match recorded provenance',hashes==expected,sorted(hashes))
public=json.loads((D/'assets/evidence/cap-05-publication.json').read_text())
for x in public['figures']:
 check('unchanged PNG:'+x['file'],hashlib.sha256((D/'assets/figures/cap-05'/x['file']).read_bytes()).hexdigest()==x['sha256'])
# Exact secrets loaded locally for a boolean leak check, never emitted or copied.
secrets=[]
for p in [Path('/Users/benchmark/local_llms/splash/data/api-key')]:
 if p.exists():secrets.append(p.read_text().strip())
stage=E/'publication/evidence';leaks=[]
for p in stage.rglob('*'):
 if p.is_file()and p.suffix.lower()not in['.png','.jpg']:
  text=p.read_text(errors='replace')
  if any(s and s in text for s in secrets):leaks.append(str(p.relative_to(stage)))
check('no installed Splash credential in public text',not leaks,leaks)
# Natural-language numeric tokens may differ in grammar; shared tables/criteria/hashes are the authoritative numeric audit.
audit={'experiment':'CAP-05','checks':checks,'passed':sum(c['pass']for c in checks),'failed':sum(not c['pass']for c in checks),'report_sha256':{'en':hashlib.sha256(en.encode()).hexdigest(),'cn':hashlib.sha256(cn.encode()).hexdigest()},'complete_editions':{'en_chars':len(en),'cn_chars':len(cn)},'source_code_translation':'Original shell commands and source excerpts retain their original language; surrounding prose fully translated.'}
(D/'assets/evidence/cap-05-localization-audit.json').write_text(json.dumps(audit,indent=2));(E/'analysis/localization-audit.json').write_text(json.dumps(audit,indent=2));print({k:v for k,v in audit.items()if k in['passed','failed']});print([c for c in checks if not c['pass']])
