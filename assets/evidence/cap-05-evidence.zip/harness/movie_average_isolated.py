from pathlib import Path
import json,sqlite3,subprocess,time,urllib.request,http.cookiejar,psutil
E=Path(__file__).resolve().parents[1]
for e,port,file in [('splash',4301,'data.sqlite3'),('strata',4302,'data.db')]:
 folder=E/'scoring'/('movie-'+e)/'frozen';db=sqlite3.connect(folder/file);mid=db.execute('SELECT id FROM movies WHERE hidden=0 AND NOT EXISTS(SELECT 1 FROM ratings WHERE ratings.movie_id=movies.id) LIMIT 1').fetchone()[0];db.close()
 log=open(E/'scoring'/('movie-'+e)/'independent/server.log','a');p=subprocess.Popen(['python3','server.py'],cwd=folder,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);born=psutil.Process(p.pid).create_time();time.sleep(.5);events=[]
 def req(op,path,body=None):
  z=op.open(urllib.request.Request(f'http://127.0.0.1:{port}'+path,data=json.dumps(body).encode()if body is not None else None,headers={'Content-Type':'application/json'}));return json.load(z)
 try:
  ops=[]
  for i in range(2):
   op=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()));name=f'avg{int(time.time())}_{i}';creds={'username':name,'password':'EvalOnly42'};req(op,'/api/register',creds);req(op,'/api/login',creds);req(op,f'/api/movies/{mid}/'+('watch'if e=='splash'else'library'),{});ops.append(op)
  for who,score,expected in [(0,8,8),(1,4,6),(0,10,7)]:
   req(ops[who],f'/api/movies/{mid}/rate',{'score':score});d=req(ops[who],f'/api/movies/{mid}');v=d['movie']['avg']if e=='splash'else d['stats']['avg'];events.append({'who':who,'score':score,'expected':expected,'actual':v,'pass':v==expected})
  assert all(x['pass']for x in events)
 finally:
  x=psutil.Process(p.pid);assert abs(x.create_time()-born)<.001 and x.cwd()==str(folder);x.terminate();x.wait(5)
 (E/'scoring'/('movie-'+e)/'independent/average-isolated.json').write_text(json.dumps({'kind':'Previously unrated movie; two fresh synthetic users, actual HTTP writes and reads','movie_id':mid,'events':events,'temporary_server_stopped_identity_verified':True},indent=2));print(e,events)
