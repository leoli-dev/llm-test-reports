from pathlib import Path
import time,json,urllib.request,urllib.error,http.cookiejar,importlib.util,io,contextlib,tempfile
E=Path(__file__).resolve().parents[1]
for engine,port in [('splash',4301),('strata',4302)]:
 out=E/'scoring'/('movie-'+engine)/'independent';events=[];clients={}; stamp=str(int(time.time()))
 def req(who,path,body=None,method=None,origin=None):
  op=clients.setdefault(who,urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar())))
  headers={'Content-Type':'application/json'}
  if origin:headers['Origin']=origin
  r=urllib.request.Request(f'http://127.0.0.1:{port}'+path,data=json.dumps(body).encode() if body is not None else None,headers=headers,method=method)
  try:z=op.open(r,timeout=10)
  except urllib.error.HTTPError as er:z=er
  v=json.loads(z.read());events.append({'who':who,'path':path,'method':method or ('POST' if body is not None else 'GET'),'input':{k:('REDACTED' if k=='password' else v) for k,v in (body or {}).items()},'origin':origin,'status':z.code,'response':v});return z.code,v
 for who in ['eve','fred']:
  req(who,'/api/register',{'username':'e'+stamp+'_'+who,'password':'EvalPass42','role':'admin'});req(who,'/api/login',{'username':'e'+stamp+'_'+who,'password':'EvalPass42'})
 req('admin','/api/login',{'username':'admin','password':'admin123'})
 req('eve','/api/admin/movies');req('anon','/api/library');req('eve','/api/session')
 if engine=='splash':mid=12
 else:mid=req('eve','/api/import/demo/laLaLand',{})[1]['id']
 p=f'/api/movies/{mid}';review='/reviews' if engine=='splash' else '/comment';lib='/watch' if engine=='splash' else '/library'
 req('admin',f'/api/admin/movies/{mid}/hide',{'hidden':False}) if engine=='splash' else None
 req('eve',p+'/rate',{'score':7}) # unwatched
 req('eve',p+lib,{});req('fred',p+lib,{})
 req('eve',p+'/rate',{'score':8});req('fred',p+'/rate',{'score':4});req('eve',p+'/rate',{'score':10});req('eve',p+'/rate',{'score':11});req('eve',p+'/rate',{'score':'abc'})
 req('eve',p+review,{'body':'Independent review <img src=x onerror="window.EVAL_XSS=1">'});detail=req('fred',p)[1]
 rv=(detail.get('reviews') or detail.get('comments'))[0]['id']
 req('fred',f'{p}/reviews/{rv}' if engine=='splash' else f'/api/comments/{rv}',method='DELETE')
 def adminact(action):
  return req('admin',f'/api/admin/movies/{mid}/'+('hide' if action in ['hide','unhide'] else 'comments'),{'hidden':action=='hide'} if action in ['hide','unhide'] else {'disabled':action=='lock'}) if engine=='splash' else req('admin',f'/api/admin/movies/{mid}',{'action':action})
 adminact('lock');req('eve',p+review,{'body':'must be blocked'});req('eve',p);adminact('unlock')
 adminact('hide');req('eve',p);req('eve','/api/library');req('eve',p+'/rate',{'score':2});req('eve','/api/search?q='+('a' if engine=='splash' else 'La'));adminact('unhide')
 req('admin',f'/api/admin/'+('reviews' if engine=='splash' else 'comments')+f'/{rv}/delete',{'reason':'independent moderation'});req('fred',p);req('admin','/api/admin/logs')
 req('eve',p+'/rate',{'score':9},origin='http://127.0.0.1:4399');req('eve','/api/library');req('eve','/api/logout',{});req('eve','/api/session')
 (out/'api-tests.json').write_text(json.dumps(events,ensure_ascii=False,indent=2))
 # Controlled provider fixture executes original module unchanged; replace provider IO only.
 source=E/'scoring'/('movie-'+engine)/'frozen'/'server.py';spec=importlib.util.spec_from_file_location('candidate_'+engine,source);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
 with tempfile.TemporaryDirectory() as td:
  setattr(m,'DB' if engine=='splash' else 'DB_PATH',td+'/fixture.db');m.init_db();buf=io.StringIO()
  detail={'id':999001,'title':'Provider Fixture','release_date':'2020-01-02','overview':'Fixture synopsis','genres':[{'name':'Drama'}],'poster_path':'/fixture.jpg'}
  credits={'crew':[{'job':'Director','name':'Fixture Director'},{'job':'Producer','name':'Fixture Producer'}],'cast':[{'name':'Fixture Actor'}]}
  if engine=='strata':
   m.tmdb_get=lambda p:credits if p.endswith('/credits') else detail
   with contextlib.redirect_stdout(buf):result=m.import_tmdb(999001)
  else:
   h=object.__new__(m.H);h.headers={};result=h.upsert_tmdb(detail)
  fixture={'kind':'controlled provider fixture; no live TMDB key','result':result,'stdout':buf.getvalue()}
  (out/'provider-fixture.json').write_text(json.dumps(fixture,ensure_ascii=False,indent=2))
 print(engine,len(events),fixture)
