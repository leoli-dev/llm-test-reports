import pathlib,subprocess,json,sys,time,functools
import psutil
from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
E=pathlib.Path(__file__).resolve().parents[1];root=E/'private/archive-preview';root.mkdir(exist_ok=True);portfile=E/'private/archive-server-port.txt';link=root/'llm-test-reports'
if not link.exists():link.symlink_to('/Users/benchmark/Code/llm-test-reports/dist',target_is_directory=True)
if len(sys.argv)>1:
 srv=ThreadingHTTPServer(('127.0.0.1',0),functools.partial(SimpleHTTPRequestHandler,directory=str(root)));portfile.write_text(str(srv.server_port));srv.serve_forever()
else:
 if portfile.exists():portfile.unlink()
 f=open(E/'analysis/archive-server.log','w');p=subprocess.Popen([sys.executable,str(pathlib.Path(__file__).resolve()),'child'],stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
 for _ in range(50):
  if portfile.exists():break
  assert p.poll() is None,'Preview server failed';time.sleep(.05)
 assert portfile.exists();port=int(portfile.read_text());(E/'private/archive-server.json').write_text(json.dumps({'pid':p.pid,'created':psutil.Process(p.pid).create_time(),'port':port}));print(f'http://127.0.0.1:{port}/llm-test-reports/')
