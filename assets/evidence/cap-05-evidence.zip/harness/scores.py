from pathlib import Path
import json
E=Path(__file__).resolve().parents[1];rows=[]
def add(topic,group,weight,data):
 for en,cn,s,t,re,rc in data:
  rows.append(dict(id=topic[0].upper()+f'{sum(r["topic"]==topic for r in rows)+1:02}',topic=topic,group=group,criterion=en,criterion_cn=cn,weight=weight,splash=s,strata=t,evidence=re,evidence_cn=rc))
add('movie','functional',3,[
('External metadata search','外部元数据搜索',1.5,.75,'Controlled provider IO exercised original handlers; no live key. Strata search cannot complete import.','受控提供商响应执行原始处理器；无真实 key。Strata 在线搜索后无法完成导入。'),
('Poster, title and synopsis','海报、片名、简介',1.5,1.5,'Readable demo title/synopsis and placeholder posters; real poster download not verified.','演示片名和简介可读，海报为占位图；未验证真实海报下载。'),
('Producer, director and cast','制作人、导演与演员',1,1,'Demo director/cast exist; producer missing. Splash online credits empty; Strata import fails.','演示导演、演员存在，均缺制作人；Splash 在线演职员为空，Strata 导入失败。'),
('Registration, login, logout','注册、登录、退出',3,3,'New users, wrong privileges and logout exercised via HTTP; browser login works.','HTTP 实测新用户、角色与退出，浏览器登录成功。'),
('Server identity and private libraries','服务端身份与独立电影库',3,3,'Role escalation ignored; anonymous library 401, normal admin route 403, separate users.','注册伪造角色无效；匿名电影库 401，普通用户后台 403，各账户独立。'),
('Add watched films and persist','加入看过电影并持久化',3,2,'Both demo libraries persist restart; Strata cannot add provider films because import returns None.','两者演示电影库均跨重启保留；Strata 导入返回 None，无法添加在线影片。'),
('Create/update/validate ratings','创建、更新与校验评分',2,2,'Updates and range checks work. Splash permits unwatched scores; Strata nonnumeric score yields 500.','更新和范围校验可用；Splash 允许未看过影片评分，Strata 非数字输入返回 500。'),
('Cross-user reviews and individual scores','跨用户评论与个人评分展示',3,2,'Cross-user text works and HTML is escaped. Splash includes reviewer score; Strata omits it.','跨用户评论可见且 HTML 转义；Splash 展示评论者评分，Strata 没有展示。'),
('Server average and updates','服务端平均分与更新',3,3,'8 and 4, then 10 and 4 produce 7; actual HTTP values match server aggregation.','8 与 4，更新为 10 与 4 后均分为 7，真实 HTTP 值与后端聚合一致。'),
('Admin authorization','管理员权限',3,3,'User cannot access admin or delete another user review; admin moderation succeeds.','普通用户无法进入后台或删除他人评论，管理员审核成功。'),
('Global hiding across paths','搜索、详情和电影库全局隐藏',1.5,2,'Demo paths reject hidden films. Splash provider search leaks hidden row; Strata hidden rating write succeeds.','演示路径均过滤隐藏影片；Splash 在线搜索泄漏隐藏条目，Strata 隐藏后评分写入仍成功。'),
('Comment lock, information retained','禁评后保留信息并服务端阻止评论',2,3,'Normal users blocked while detail remains. Splash admin can still comment under lock.','普通用户禁评且详情仍可读；Splash 管理员仍能在锁定时评论。'),
('Admin deletes comments','管理员删除评论',3,3,'Soft deletion disappears from public detail and remains traceable in admin records.','软删除后公共详情不再显示，后台记录可追溯。'),
('Attributable persistent audit','可追查且持久的审计日志',2,3,'Actor/action/time survive restart; Splash action commit and audit insert are separate transactions.','操作者、动作、时间跨重启保留；Splash 业务提交与审计写入分属事务。'),
('Database survives server restart','数据库跨服务重启保留',3,3,'Verified process restart preserved exact movies/library/log response snapshots.','核验进程归属后重启，电影、电影库和日志响应快照完全一致。')])
add('movie','ux',4,[
('Desktop search/detail hierarchy','桌面搜索与详情层级',3,3,'Clear dark layouts and working search/detail flow; conventional and visually sparse.','深色层级清楚、搜索详情可用，但视觉常规且留白多。'),
('Mobile layout and inputs','手机布局与输入',3,3,'390px views have no page overflow; tall detail and dense admin tables require scrolling.','390px 无页面溢出；详情较长，后台表格密集，需要滚动。'),
('Metadata, loading and errors','元数据、加载与错误提示',2,2,'Honest demo banner and visible errors; placeholders and unverified online failure UX limit completeness.','演示标识和错误可见；占位海报、未验证在线失败交互限制完整度。'),
('Keyboard, labels and accessibility','键盘、标签与无障碍',2,1,'Splash has labelled login and score buttons; both result cards lack keyboard semantics; Strata scores are mouse spans.','Splash 登录有标签、评分为按钮；两者搜索卡片缺键盘语义，Strata 评分依赖鼠标 span。'),
('Library/review/admin workflow','电影库、评论与后台流程',3,3,'Visible controls complete common tasks; basic table moderation rather than refined workflow.','可见控件完成常见流程，审核仍为基础表格操作。')])
add('movie','code',5,[
('Password and session security','密码与会话安全',3.5,3.5,'Salted PBKDF2, random HttpOnly SameSite cookies and backend roles; no server-enforced session expiry.','有盐 PBKDF2、随机 HttpOnly SameSite cookie、服务端角色；缺服务端会话到期。'),
('Authorization, XSS and input validation','授权、XSS 与输入校验',3,2,'Cross-user deletion blocked and XSS escaped; Strata accepts demonstrated same-site cross-origin writes.','阻止跨用户删除、XSS 转义；Strata 实测接受同站不同源写入。'),
('Schema and transactions','数据结构与事务',2.5,4,'SQLite parameterization; Strata audit shares transaction, Splash audit can diverge from mutation.','SQLite 参数化查询；Strata 审计与业务同事务，Splash 可能产生不一致。'),
('Readable maintainable modules','代码可读性与模块结构',3,3,'Small stdlib stacks, readable functions, but large HTTP dispatchers and ad hoc client state.','标准库技术栈、函数可读，但路由分派较大、客户端状态较临时。'),
('Meaningful tests and provider failures','有效测试与提供商失败处理',2.5,2,'Substantial self-tests exist; neither caught important provider path defects.','有较多自测，两者都未捕获重要在线提供商路径缺陷。')])
add('movie','handoff',2,[
('Exact launch command','准确启动命令',2,2,'README launch succeeded unchanged.','README 命令原样启动成功。'),('Accounts and configuration','账户与配置可复现',2,2,'Demo accounts and environment key documented.','演示账户、环境变量 key 已说明。'),('Dependencies','依赖说明',2,2,'Python stdlib, no install surprises.','Python 标准库，无额外安装障碍。'),('Honest limitations and provenance','限制与数据来源说明',1.5,1.5,'Demo is honest, but operational online defects remain undisclosed.','演示数据说明诚实，但在线运行缺陷未披露。'),('Clean runnable delivery','交付整洁且可运行',1.5,1.5,'Runnable separate repo; many diagnostic screenshots/scripts retained.','独立仓库可运行，但保留较多诊断脚本和截图。')])
add('voxel','functional',3,[
('512³ logical coordinates','512³ 逻辑世界',1.5,3,'Both hold a y=400 platform and support collision; Splash does not render it because meshes only cover the original terrain envelope.','两者 y=400 石台数据与碰撞有效；Splash 仅渲染原地表高度范围，石台不可见。'),
('Random reproducible terrain','随机且可复现的地形',3,3,'Seeded generation, seed preserved in save, regenerate changes terrain.','种子生成、存档保留种子，重新生成改变地形。'),
('Mountains and generated water','山体与生成的水体',3,1.5,'Splash sampled 628/3844 wet columns; Strata complete 512² scans of both tested seeds found zero water.','Splash 抽样 3844 列中 628 列为水；Strata 两个测试种子各完整扫描 512² 列均无水。'),
('Resources and interactive props','资源与交互物品',3,3,'Wood/dirt/stone resources, tools and placeable blocks are functional; ore tiers are present.','木材、土石、工具和可放方块可用，存在分级矿物。'),
('First-person movement and look','第一人称移动与视角',3,3,'Real keys move about 5 units; mouse changes yaw; jump and touch UI exercised.','真实键盘移动约 5 格，鼠标改变视角，操作跳跃与触控界面。'),
('Collision and gravity','碰撞与重力',3,3,'Walking, slopes, jumping and settling visibly interact with solid terrain.','行走、坡地、跳跃和落地与实体地形发生真实作用。'),
('Mining changes world','采集实际修改世界',3,3,'Real hold-mouse mining produces four edits in each initial trial.','首轮均以真实长按鼠标产生 4 处方块修改。'),
('Inventory and collection','背包与收集',3,3,'Splash directly collects mined dirt/sand; Strata collected two logs after approaching drops.','Splash 直接收集土沙；Strata 接近掉落物后取得 2 个木头。'),
('Real recipes and crafting','真实配方与制作',3,3,'UI consumes logs/planks/sticks and produces wooden pickaxe and sword; insufficient recipes disabled.','界面消耗木头、木板、木棍并产出木镐木剑，材料不足的配方禁用。'),
('Attack, damage and enemy death','攻击、伤害与敌人死亡',3,3,'Real attacks damage and kill fixture-positioned enemies; helper use explicitly recorded.','真实攻击可伤害并击杀辅助定位敌人，明确记录辅助条件。'),
('Enemy spawn and behavior','敌人刷新与行为',3,3,'Enemies spawn, move and damage player; capped populations observed.','敌人刷新、移动并伤害玩家，观察到数量上限。'),
('Player HP and survival','玩家血量与生存',3,3,'Contact damage lowers HP; state/HUD and survival controls exist.','接触伤害降低血量，状态、界面和生存操作存在。'),
('Weather changes','天气变化',3,3,'Clock and rendered rain respond to weather state and continue over time.','时钟与实际雨景响应天气状态并持续变化。'),
('Complete single-slot save/load','完整单槽存档与读档',2,1.5,'Seed/edits/inventory/weather persist; Strata resets enemy HP, Splash silently caps saved edits at 60001.','种子、修改、背包和天气保留；Strata 重置敌人血量，Splash 静默限制存储 60001 处修改。'),
('Regenerate and replay','重新生成与重玩',3,3,'New seed clears edits and inventory in actual new-world test.','真实重开后种子改变，修改和背包清空。')])
add('voxel','play',5,[
('Readable Minecraft-like scene','Minecraft 风格可读性',3.5,3.5,'Recognizable voxel hills/trees, simple flat materials and limited environmental polish.','方块山林可辨，材质平坦，环境打磨有限。'),
('Responsive first-person controls','第一人称响应',4,4,'Metal renderer and roughly 60Hz rAF in short active samples; real input works.','Metal 渲染，短时活跃采样约 60Hz，真实输入有效。'),
('Gather/craft/combat enjoyment','采集、制作、战斗体验',3,3,'Components work; assisted subtests do not establish an unassisted complete progression run.','组件可用；辅助子测试不代表已无辅助完成整条成长流程。'),
('Coherent terrain and exploration','地形生态与探索',2.5,2.5,'Splash offers water and biome variation but invisible high edits and awkward initial cliff; Strata tested worlds lack water.','Splash 有水体与地形变化，但高空修改不可见、首个出生视野被崖壁遮挡；Strata 测试世界无水。'),
('Desktop/mobile HUD and controls','桌面与手机 HUD、操作',3.5,3,'Visible touch controls and compact hotbars work; dense labels and basic feedback reduce usability.','有可用触控控件与快捷栏，但文字密集、反馈较基础。')])
add('voxel','code',4,[
('Bounded generation and chunk memory','生成与区块内存有界',4,4,'Splash streams/evicts chunks; Strata dense 128MiB world plus visible chunk meshes is bounded.','Splash 流式加载并淘汰区块；Strata 为有界 128MiB 体素数组加可见区块网格。'),
('Reliable state serialization','状态序列化可靠性',2,1,'Small saves work, but edit cap and enemy HP restore defects violate full-state guarantees.','小规模保存可用，但修改上限和敌人血量读档缺陷破坏完整状态保证。'),
('Module/input/state maintainability','模块、输入与状态可维护性',3,2,'Splash separates world/player/weather/save; Strata concentrates generation, UI and state in main.js.','Splash 分离世界、玩家、天气、存档；Strata main.js 集中生成、界面和状态。'),
('No pause and robust boundaries','无暂停与边界稳健性',3,3,'Menus advance time; bounds exist, but background clamping is not wall-clock catch-up.','菜单内时间继续、有边界限制，但后台 dt 截断不等于真实时间补算。'),
('Stability and runtime frames','稳定性与运行帧间隔',4,4,'No candidate page errors after observer readiness correction; short active samples near 16.6ms.','修正评测器就绪等待后无候选页面错误，短时活跃采样约 16.6ms。')])
add('voxel','handoff',2,[
('Exact launch command','准确启动命令',2,2,'Documented local stdlib servers launch.','文档中的本地标准库服务可启动。'),('Seed/save/control configuration','种子、存档与控制说明',2,2,'Controls and slot documented with real UI.','控制与存档槽均有文档和真实界面。'),('Dependencies','依赖说明',2,2,'Bundled Three.js and stdlib server.','提供 Three.js 和标准库服务。'),('Honest limitations','限制披露',1,1,'Browser throttling disclosed; full-save defects and missing water cases not disclosed.','说明浏览器后台节流，但未披露完整保存缺陷或无水情况。'),('Clean runnable delivery','整洁且可运行的交付',1,1,'Runnable, but numerous debugging scripts/screenshots and environment-specific tests remain.','可运行，但保留大量调试脚本、截图及依赖特定环境的测试。')])
add('qingming','fidelity',5,[
('Continuous rural/river/city scroll','城郊、河流、城市连续长卷',2.5,2.5,'All regions exist, but composition is mostly horizontal bands and broad empty areas.','区域齐全，但构图多为水平条带和大面积空白。'),
('Timber rainbow bridge','木构虹桥',1.5,1,'Splash adds braces; both bridges lack the original interwoven timber structure and perspective.','Splash 有斜撑，但两者均缺原作编木结构与透视。'),
('River, boats and wharf','河道、船只与码头',3,2.5,'Visible crew/cargo/boats; river is simplified and Strata boats paint above bridge.','可见船员、货物和船只；河道简化，Strata 船只绘制在桥面上方。'),
('Caravans and pack animals','商队与驮兽',3,3,'Moving donkeys/carts/carriers visible, with highly simplified anatomy.','可见移动驴车和挑担者，但形体高度简化。'),
('Song shops, signs and buildings','宋代店铺、招牌与建筑',2.5,2.5,'Signs and shop types recognizable; flat repeated facades instead of architectural depth.','招牌与店铺种类可辨，但立面重复、缺建筑纵深。'),
('Many varied human activities','众多且有差异的人物活动',2.5,2.5,'153 agents versus 230 figures; different props but repetitive stick figures/clusters.','153 个代理与 230 个图形实体，有道具差异，但人物和群组重复。'),
('Fine linework, ink and earth palette','工细线描、墨色与土色',2.5,2.5,'Muted palette resembles aged silk; clean vector outlines lack original brush/detail richness.','低饱和底色接近旧绢，规整矢量线条缺原作笔触和细节。'),
('Oblique perspective, scale and depth','斜视透视、比例与纵深',1,1,'Front-facing buildings, straight river and scale jumps dominate.','建筑正立面、笔直河道和比例跳变明显。'),
('Narrative vignettes and crowd ecology','叙事小景与市井生态',2,2,'Porters, stalls and boating gestures exist, but few convincing connected narratives.','有挑担、摊贩与操船姿态，缺少可信连贯叙事。'),
('Overall resemblance to original','整体接近原作的程度',1.5,1.5,'An animated schematic town, visibly far from the museum bridge detail and original scroll language.','更像动态示意古镇，与故宫虹桥局部及原作绘画语言距离明显。')])
add('qingming','motion',5,[
('Autoplay and temporal change','自动播放与持续变化',5,5,'Clocks advance 3s over 3s; fixed-camera images change; 60s stability passed.','3 秒观察中时钟推进 3 秒，固定相机画面改变，通过 60 秒稳定检查。'),
('Plausible human walk paths','人物行走路径可信度',3,3,'People follow roads/bridge; repeated groups and overlaps limit natural movement.','人物沿路和桥行走，但重复群组与重叠削弱自然感。'),
('Boats/caravans and occlusion','舟车路径与遮挡',2.5,1.5,'Movement exists; Splash depth keys are approximate, Strata always draws boats above static bridge.','运动存在；Splash 深度排序近似，Strata 总在静态桥之后绘船而覆盖桥面。'),
('Pan, zoom, speed and replay','平移、缩放、速度与重播',4,5,'Real drag/wheel/buttons work; Strata visible region presets improve discovery.','真实拖动、滚轮和按钮有效；Strata 可见区域预设更易发现内容。'),
('Desktop/mobile composition and accessibility','桌面、手机构图与无障碍',2.5,3,'No overflow and touch controls work; narrow crops and small controls, no rich canvas alternative text.','无溢出、触控可用，但窄屏裁切明显、控件偏小，缺丰富画布替代文本。')])
add('qingming','code',3,[
('Readable architecture','架构可读性',3,1.5,'Splash separates scene/agents/world/util; Strata is a long monolithic script.','Splash 分离场景、代理、世界和工具；Strata 为较长单文件脚本。'),
('Reproducible animation state','动画状态可复现',2.5,2.5,'Time, presets and replay can restore scenes; not a complete persistent animation checkpoint.','时间、预设与重播可恢复场景，但不是完整持久动画检查点。'),
('Bounded drawing and frame cost','绘制与帧成本有界',3,3,'Static caching/culling and short rAF samples near 60Hz.','静态缓存、裁剪与短时 rAF 采样接近 60Hz。'),
('Resize and error handling','缩放适配与错误情况',3,3,'Desktop→390px→desktop retained canvas with no page errors.','桌面→390px→桌面保留画布且无页面错误。'),
('60-second animation stability','60 秒动画稳定性',3,3,'Independent timed capture completed, no fatal errors.','独立定时截图完成，无致命错误。')])
add('qingming','handoff',2,[
('Exact launch command','准确启动命令',2,2,'Documented Python/Node servers work.','文档中的 Python/Node 服务可运行。'),('Controls and configuration','控制与配置',2,2,'Controls, state hooks and presets documented.','控制、状态钩子和预设均有说明。'),('Dependencies','依赖说明',2,2,'Canvas2D with no network asset dependency.','Canvas2D，无联网素材依赖。'),('Honest artistic limitations','美术限制披露',2,2,'READMEs acknowledge stylization and simplified bridge/faces.','README 承认风格化、虹桥和面部简化。'),('Clean runnable delivery','整洁且可运行的交付',1.5,1.5,'Runnable local artifact with test material retained.','本地作品可运行，保留测试资料。')])
assert len(rows)==85
summary={t:{'maximum':sum(r['weight']for r in rows if r['topic']==t),**{e:sum(r[e]for r in rows if r['topic']==t)for e in ['splash','strata']}}for t in ['movie','voxel','qingming']}
assert all(x['maximum']==100 for x in summary.values())
(E/'scoring/scores.json').write_text(json.dumps({'method':'Predeclared weighted assessor rubric; identity-aware n=1, no statistical significance; source-only limitations explicitly distinguished from reproduced failures.','criteria':rows,'totals':summary},ensure_ascii=False,indent=2));print(summary)
