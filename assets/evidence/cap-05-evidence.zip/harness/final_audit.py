from pathlib import Path
import json,hashlib,subprocess,tarfile,io
E=Path(__file__).resolve().parents[1];R=E.parent;rows=[];A=R/'artifacts';A.mkdir(exist_ok=True)
for c in json.loads((E/'matrix.json').read_text()):
 d=E/'scoring'/c['id'];manifest=json.loads((d/'source-integrity.json').read_text());bad=[]
 for rel,v in manifest['files'].items():
  p=d/'frozen'/rel
  if not p.exists() or hashlib.sha256(p.read_bytes()).hexdigest()!=v['sha256']:bad.append(rel)
 head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=c['path'],text=True).strip();status=subprocess.check_output(['git','status','--porcelain'],cwd=c['path'],text=True)
 archive=subprocess.check_output(['git','archive','--format=tar.gz',head],cwd=c['path']);name=c['id']+'-source.tar.gz';(A/name).write_bytes(archive)
 bundle=A/(c['id']+'.bundle')
 if not bundle.exists():subprocess.run(['git','bundle','create',str(bundle),'--all'],cwd=c['path'],check=True,stdout=subprocess.DEVNULL)
 rows.append({'case':c['id'],'repo':Path(c['path']).name,'snapshot_commit':head,'snapshot_matches':head==manifest['snapshot_commit'],'author_worktree_clean':not status,'evaluation_tracked_files_unchanged':not bad,'mismatches':bad,'source_archive':name,'archive_bytes':len(archive),'archive_sha256':hashlib.sha256(archive).hexdigest(),'bundle_sha256':hashlib.sha256(bundle.read_bytes()).hexdigest(),'tracked_files':len(manifest['files'])})
assert all(x['snapshot_matches'] and x['author_worktree_clean'] and x['evaluation_tracked_files_unchanged']for x in rows)
(E/'scoring/final-integrity.json').write_text(json.dumps({'cases':rows,'source_edits_by_supervisor':0,'all_source_frozen_before_independent_review':True,'local_full_artifact_directory':str(A),'pushes':0},indent=2));print('6/6 source snapshots and evaluation files unchanged; local archives and git bundles saved.')
