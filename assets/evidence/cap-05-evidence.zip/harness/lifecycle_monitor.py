from pathlib import Path
import json,os,signal,time,subprocess
import psutil
from macos_telemetry import collect
E=Path(__file__).resolve().parents[1];stop=False
def end(*_):
 global stop
 stop=True
signal.signal(signal.SIGTERM,end);signal.signal(signal.SIGINT,end)
with (E/'raw/lifecycle-system.jsonl').open('a') as f:
 while not stop:
  t=time.monotonic();row=collect(os.getpid());row['system_virtual_memory']=dict(psutil.virtual_memory()._asdict());row['system_swap_memory']=dict(psutil.swap_memory()._asdict())
  try:row['controller_state']=json.loads((E/'raw/matrix-progress.json').read_text())
  except Exception:row['controller_state']={'phase':'installation-pretrial'}
  f.write(json.dumps(row)+'\n');f.flush();time.sleep(max(.05,1-time.monotonic()+t))
