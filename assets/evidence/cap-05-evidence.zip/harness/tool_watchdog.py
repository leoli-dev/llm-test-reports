"""Generic 300-second bash-tool cap; no application edits or tailored feedback.
Protocol amendment added after first stalled browser tool; all cells use it.
"""
from pathlib import Path
import datetime,json,time,os,signal
import psutil
E=Path(__file__).resolve().parents[1];stop=False;handled=set()
def end(*_):
 global stop
 stop=True
signal.signal(signal.SIGTERM,end)
def emit(d):
 with (E/'raw/tool-timeout-interventions.jsonl').open('a') as f:f.write(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'unix_s':time.time(),**d})+'\n')
def safe_signal(identity):
 try:
  p=psutil.Process(identity['pid'])
  if p.create_time()==identity['create_time'] and p.uids().real==os.getuid():p.terminate();return True
 except psutil.Error:pass
 return False
while not stop:
 for d in E.glob('raw/*/formal'):
  if (d/'summary.json').exists() or not (d/'launch.json').exists():continue
  events=[]
  try:
   for line in (d/'timeline.jsonl').read_text().splitlines():
    try:events.append(json.loads(line))
    except Exception:pass
   ended={x.get('toolCallId') for x in events if x.get('type')=='tool_execution_end'}
   active=[x for x in events if x.get('type')=='tool_execution_start' and x.get('toolName')=='bash' and x.get('toolCallId') not in ended]
   for ev in active:
    key=(d.parent.name,ev.get('toolCallId'));started=ev['unix_s']
    if key in handled or time.time()-started<300:continue
    root=psutil.Process(json.loads((d/'launch.json').read_text())['pi_pid']);branches=[q for q in root.children() if started-2<=q.create_time()<=started+15]
    identities=[];targets=[]
    for branch in branches:
     descendants=branch.children(recursive=True)
     for q in descendants:
      cmd=q.cmdline();ident={'pid':q.pid,'create_time':q.create_time(),'cmd':cmd};identities.append(ident)
      # Keep pipeline tail alive long enough to flush the captured output.
      if q.name()!='tail':targets.append(ident)
    emit({'runid':d.parent.name,'toolCallId':ev.get('toolCallId'),'threshold_s':300,'age_s':time.time()-started,'event':'owned_tool_timeout','tool_command':ev.get('args',{}).get('command'),'branches':[{'pid':q.pid,'create_time':q.create_time()} for q in branches],'descendants':identities,'note':'Controller-enforced timeout only; no source changes or defect-specific hint. All elapsed time remains counted.'})
    for ident in reversed(targets):safe_signal(ident)
    time.sleep(.5)
    for q in branches:
     try:
      if not q.children() and q.is_running():safe_signal({'pid':q.pid,'create_time':q.create_time()})
     except psutil.Error:pass
    handled.add(key)
  except (psutil.Error,OSError,ValueError,KeyError) as ex:emit({'event':'watchdog_error','runid':d.parent.name,'error':repr(ex)})
 time.sleep(2)
