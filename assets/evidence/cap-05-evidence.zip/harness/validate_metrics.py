from pathlib import Path
import json,math,collections,hashlib
E=Path(__file__).resolve().parents[1];checks=[];errors=[]
def check(name,ok,detail=None):
 row={'check':name,'pass':bool(ok),'detail':detail};checks.append(row)
 if not ok:errors.append(row)
for c in json.loads((E/'matrix.json').read_text()):
 d=E/'raw'/c['id']/'formal';p=d/'summary.json'
 if not p.exists():continue
 summary=json.loads(p.read_text());reqdirs=sorted((d/'requests').iterdir());check(c['id']+':all_results_written',all((r/'result.json').exists() for r in reqdirs),len(reqdirs));outputs=0;sampling=collections.Counter();http=collections.Counter()
 for rd in reqdirs:
  if not (rd/'result.json').exists():continue
  r=json.loads((rd/'result.json').read_text());u=r.get('usage') or {};t=r.get('timings') or {};payload=json.loads((rd/'request.json').read_text());name=c['id']+'/'+rd.name
  check(name+':usage_present',bool(u));check(name+':timings_present',bool(t));check(name+':http200',r.get('http_status')==200,r.get('http_status'));check(name+':sse_done',b'data: [DONE]' in (rd/'response.bin').read_bytes());check(name+':no_proxy_error',not r.get('error'),r.get('error'))
  if u:
   pn=u.get('prompt_tokens');on=u.get('completion_tokens');cn=t.get('cache_n',u.get('prompt_tokens_details',{}).get('cached_tokens'));outputs+=on or 0
   check(name+':token_sum',pn is not None and on is not None and pn+on==u.get('total_tokens'));check(name+':cache_range',cn is not None and 0<=cn<=pn)
   check(name+':native_prompt_semantics',t.get('prompt_n')==(pn-cn if c['label']=='strata' else pn),{'usage_prompt':pn,'native_prompt':t.get('prompt_n'),'cache':cn});check(name+':native_output_matches_usage',t.get('predicted_n')==on)
   uc=u.get('prompt_tokens_details',{}).get('cached_tokens');check(name+':cache_details_match',uc==cn)
  expected={'temperature':1,'top_p':.95,'top_k':20,'reasoning_effort':'medium','max_tokens':32768}
  for key,value in expected.items():
   got=payload.get(key);sampling[(key,str(got))]+=1;check(name+':'+key,got==value,got)
  check(name+':model',payload.get('model')==c['model'],payload.get('model'));check(name+':stream',payload.get('stream') is True)
 check(c['id']+':pi_api_output_agreement',outputs==summary['assistant_output_tokens'],{'api':outputs,'pi':summary['assistant_output_tokens']})
 resources=[]
 for line in (d/'resources.jsonl').read_text().splitlines():resources.append(json.loads(line))
 times=[r['monotonic_seconds'] for r in resources];check(c['id']+':resource_time_increases',all(b>a for a,b in zip(times,times[1:])));check(c['id']+':resource_errors',not any(r.get('errors') for r in resources));check(c['id']+':all_gpu_samples',all(r.get('gpu_device_utilization_percent') is not None and 0<=r['gpu_device_utilization_percent']<=100 for r in resources));check(c['id']+':native_pid_resolved',all(r.get('engine_pid') for r in resources));check(c['id']+':all_pressure_swap',all(r.get('memory_pressure_name') is not None and r.get('swap_used_bytes') is not None for r in resources))
 check(c['id']+':frozen_snapshot',(d/'source-snapshot.json').exists())
report={'total':len(checks),'passed':sum(c['pass'] for c in checks),'failed':len(errors),'errors':errors,'checks':checks}
(E/'analysis/measurement-validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps({k:v for k,v in report.items() if k!='checks'},indent=2,ensure_ascii=False));raise SystemExit(bool(errors))
