# Splash 1.4.1 / Flash Next IQ3_S

Installed 2026-10-26 on local M5 Max 18 CPU / 40 GPU / 128 GiB, macOS27.0.1 (26A434). Source tag1.4.1, commit1744cfafee415fb463b289449cec59a864e768e9. Built with `make -j6` and upstream `make install-environment`; source remains tracked-clean. Runtime and model are isolated under `~/local_llms/splash` and `~/local_llms/models/splash`.

```sh
~/local_llms/splash/start.sh
~/local_llms/splash/status.sh
~/local_llms/splash/stop.sh
```

Foreground: `serve.sh`. The scripts verify PID ownership and kernel start identity before signaling. No autostart. Only one large model service should be loaded at a time; stop Strata before starting Splash. Authentication is generated locally in `data/api-key` (0600); never publish it. Loopback API `http://127.0.0.1:8084/v1`; served name `qwen3.8-flash-next-iq3_s`. Source repository ID is `ISTA-DASLab/Qwen3.8-Flash-Next-GSQ-RCO-GGUF`.

The model is exactly the two ISTA GSQ-RCO IQ3_S GGUF shards used by Strata, revision `ed59f92082b1e93c0e96d60a8b11aab089b52f09`; full SHA256 checked against Hub LFS for both shards and BF16 vision projector. Distinct files/inodes are APFS copy-on-write clones, not hardlinks or symlinks into Strata. Altering a clone does not alter the original. Prepared installation links stay within Splash's model tree. The public `install.local.prepare_local_model` API prepared/checked the local GGUF split, vision and draft. No smaller quant or Coder-pruned variant is substituted.

Draft: `incoai/Qwen3.8-Flash-Next-DFlash2` revision `a22a1744e85c17364dcc54a6a420af7135d4c7f6`, BF16, SHA256 recorded by installer. Target IQ3_S uses some other tensor formats as authored by its publisher; Splash's runtime repacks IQ3_S without changing the target files and converts BF16/F16 hyper-connection projections toQ8_0 as documented upstream. Same source file does not imply identical numerical execution to Strata.

Configured native context262144, INT8 KV, FP32 state,96GiB Metal cap, idle release off, adaptive verification. Expert/PLE auto loads all of both in this128GiB machine. SSD prefix/KV cache disabled for the controlled single-session trials; no static YaRN beyond native256K. Family10/40-core Metal policy is automatic. ANE offloading is a27B feature and is not enabled for Flash Next. No unsupported Metal tuning environment variables were added.

First cold Metal compute-pipeline creation took minutes after the14.34s weight load; readiness is required before measuring requests. Later starts reuse the OS shader cache. `records/2026-10-26-iq3s-comparison/` holds build/install/model/source evidence. Engine warnings from upstream tokenizer configuration are preserved rather than locally patched.

The CAP-05 evaluation, pretrials, sampling, generated products and report evidence are in `~/Code/qwen3.8_tests/2026-10-26-flash-next-iq3s/`. Formal model/client parameters are isolated there and do not replace global Pi defaults. No push is authorized.
