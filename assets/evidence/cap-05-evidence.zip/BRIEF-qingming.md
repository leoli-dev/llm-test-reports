一个 2D 清明上河图，有很多二维人物、建筑物，自动播放，人物在画中走来走去，船只、商队、商店、桥梁都需要有，越接近真实清明上河图得分越高。
参考目标为故宫藏北宋张择端本（不是清院彩色仿本）：绢本淡设色长卷，城郊—汴河虹桥—城墙内外的叙事连续，工细线描、土色/墨色、舟车人物与市井活动。共同文字参考：https://www.dpm.org.cn/collection/paint/228226.html 。可以查阅该馆原作页面作为参考，但画面内容必须自己用 Canvas2D/SVG/HTML 绘制，不能把下载原画或现成动画铺底后称为自己的实现。画面应占主要空间，有可阅读细节，移动角色应与道路/桥/河流形成可信的关系。提供长卷平移缩放或同等可浏览方式、重播/速度等基本控制；自动播放必须实际持续。

你负责独立从零实现此产品。所有应用源代码必须由你编写；禁止读取其他实现、兄弟项目、评测器或历史项目，禁止调用其他模型、AI 服务或代理。不要修改项目外的文件、全局配置或既有服务。只终止你启动且记录的 PID，禁止 pkill/killall。不要 push 或访问 GitHub 写接口。
运行环境：macOS、Python3 标准库（含 SQLite）、Node。vendor/ 已提供同版本 Three.js；tools/screenshot.cjs 提供 Chromium 截图示例，可自行写更全面的测试。浏览器必须用 /Applications/Chromium.app/Contents/MacOS/Chromium，不可用 Google Chrome。Playwright 可从 /Users/benchmark/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright 导入。可使用 npm registry 下载普通依赖；禁止下载现成产品/游戏/美术实现。电影外部 metadata API 请求允许。其他任务不得依赖外部在线资源。不要使用 AI 生成图片。vendor/ 与 tools/ 是冻结公共工具，不要修改。
桌面 1440×900、手机 390×844，DPR1。实现真实功能而非仅 UI 原型；交付 README，包括准确启动命令、账号/测试方法、控制、已完成和未完成项。所有项目各自只有一个连续新会话，最多60分钟，包括三轮固定提示、思考、工具、自测与修复；提前完成可以返回，无须等满。读取 RUN.json 获取端口，最终可用入口 index.html（如需要 backend 则它应服务此入口）。应用可在本地独立启动，禁止连接其他项目的后端。测试数据只用虚构账号。
测试便利钩子：可暴露 window.__BENCH__.getState() 返回 JSON 可序列化状态，动画可提供 setTime/play/reset；此类钩子不能代替可见 UI 和真实输入。游戏不允许在产品中暂停。自己用 Chromium 看实际截图，并用 read 工具查看图片；不要把源码存在/恒真断言当作视觉或可玩性验证。记录自测到 REVIEW.md，说明实际看到/测到的内容与局限。你是产品作者，之后独立评审者会从冻结源码试玩评分；评审者不会替你修复代码。
