import {chromium} from '~/Code/water-garden-gpt61sol/node_modules/playwright/index.mjs';
const OUT=process.argv[2];
const b=await chromium.launch({headless:true,executablePath:'/Applications/Chromium.app/Contents/MacOS/Chromium',args:['--use-angle=metal','--ignore-gpu-blocklist']});
for(const [n,url] of [['gpt','http://127.0.0.1:5190/?scene=waterway&quality=high'],['opus','http://127.0.0.1:4173/?scene=channel&quality=high']]){
  const ctx=await b.newContext({viewport:{width:1440,height:900},deviceScaleFactor:2});const p=await ctx.newPage();if(process.env.NOFL==='1')await p.addInitScript(()=>{const P=WebGL2RenderingContext.prototype;const ge=P.getExtension,gs=P.getSupportedExtensions;P.getExtension=function(n){return n==='OES_texture_float_linear'?null:ge.call(this,n)};P.getSupportedExtensions=function(){return gs.call(this).filter(n=>n!=='OES_texture_float_linear')};});
  await p.goto(url);await p.waitForTimeout(4000);
  if(n==='opus')await p.evaluate(()=>{window.__wg.params.hoverRipples=false});
  await p.mouse.move(720,450);await p.waitForTimeout(1500);
  const clip={x:470,y:250,width:500,height:400};
  await p.mouse.down();await p.mouse.up();
  const t0=Date.now();
  for(const t of [60,150,300,600,1000,2000]){const w=t-(Date.now()-t0);if(w>0)await p.waitForTimeout(w);await p.screenshot({path:`${OUT}/series${process.env.NOFL==='1'?'-nofl':''}-${n}-${t}.png`,clip});}
  await ctx.close();
}
await b.close();
