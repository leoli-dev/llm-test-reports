import {chromium} from '~/Code/water-garden-gpt61sol/node_modules/playwright/index.mjs';
const b=await chromium.launch({headless:true,executablePath:'/Applications/Chromium.app/Contents/MacOS/Chromium',args:['--use-angle=metal','--ignore-gpu-blocklist']});
// GPT
{const ctx=await b.newContext({viewport:{width:1280,height:800}});const p=await ctx.newPage();const errs=[];p.on('pageerror',e=>errs.push(e.message));p.on('console',m=>m.type()==='error'&&errs.push(m.text()));
await p.goto('http://127.0.0.1:5190/');await p.waitForTimeout(3000);await p.click('#settings-toggle');const mem=[];
for(let i=0;i<16;i++){await p.click(`[data-scene="${i%2?'waterway':'grove'}"]`);await p.waitForTimeout(400);mem.push(await p.evaluate(()=>{const s=window.__garden.snapshot();return s.memory.geometries+'/'+s.memory.textures}));}
await p.setViewportSize({width:700,height:900});await p.waitForTimeout(800);await p.setViewportSize({width:1280,height:800});await p.waitForTimeout(800);
mem.push('after-resize '+await p.evaluate(()=>{const s=window.__garden.snapshot();return s.memory.geometries+'/'+s.memory.textures}));
const heap=await p.evaluate(()=>performance.memory?.usedJSHeapSize/1e6|0);
console.log('gpt geo/tex',mem.join(' '),'heapMB',heap,'errors',errs);await ctx.close();}
// Opus
{const ctx=await b.newContext({viewport:{width:1280,height:800}});const p=await ctx.newPage();const errs=[];p.on('pageerror',e=>errs.push(e.message));p.on('console',m=>m.type()==='error'&&errs.push(m.text()));
await p.goto('http://127.0.0.1:4173/');await p.waitForTimeout(3000);const mem=[];
for(let i=0;i<16;i++){await p.keyboard.press(String(1+i%4));await p.waitForTimeout(400);mem.push(await p.evaluate(()=>{const m=window.__wg.renderer.info;return m.memory.geometries+'/'+m.memory.textures+'/p'+m.programs.length}));}
await p.setViewportSize({width:700,height:900});await p.waitForTimeout(800);await p.setViewportSize({width:1280,height:800});await p.waitForTimeout(800);
mem.push('after-resize '+await p.evaluate(()=>{const m=window.__wg.renderer.info;return m.memory.geometries+'/'+m.memory.textures+'/p'+m.programs.length}));
const heap=await p.evaluate(()=>performance.memory?.usedJSHeapSize/1e6|0);
console.log('opus geo/tex/prog',mem.join(' '),'heapMB',heap,'errors',errs);await ctx.close();}
await b.close();
