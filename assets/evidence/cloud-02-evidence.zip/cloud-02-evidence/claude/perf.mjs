import {chromium} from '~/Code/water-garden-gpt61sol/node_modules/playwright/index.mjs';
const b=await chromium.launch({headless:true,executablePath:'/Applications/Chromium.app/Contents/MacOS/Chromium',args:['--use-angle=metal','--ignore-gpu-blocklist','--disable-gpu-vsync','--disable-frame-rate-limit']});
const fps=(p,ms)=>p.evaluate(ms=>new Promise(res=>{const s=[];let st,l;function f(t){if(st===undefined){st=l=t;return requestAnimationFrame(f);}s.push(t-l);l=t;if(t-st>=ms){s.sort((a,b)=>a-b);const m=s.reduce((a,b)=>a+b,0)/s.length;res({fps:+(1000/m).toFixed(0),meanMs:+m.toFixed(2),p95:+s[Math.floor(s.length*.95)].toFixed(2)});}else requestAnimationFrame(f);}requestAnimationFrame(f);}),ms);
const rows=[];
for(const dpr of [1,2])for(const q of ['low','medium','high'])for(const [n,base,scenes] of [['gpt','http://127.0.0.1:5190/',['waterway','grove']],['opus','http://127.0.0.1:4173/',['channel','dense']]])for(const sc of scenes){
  const ctx=await b.newContext({viewport:{width:1440,height:900},deviceScaleFactor:dpr});const p=await ctx.newPage();
  await p.goto(`${base}?scene=${sc}&quality=${q}`);await p.waitForTimeout(3500);
  const r=await fps(p,4000);
  const px=await p.evaluate(()=>{const c=document.querySelector('canvas');return `${c.width}x${c.height}`});
  rows.push({app:n,scene:sc,dpr,q,canvas:px,...r});console.log(JSON.stringify(rows.at(-1)));await ctx.close();
}
await b.close();
