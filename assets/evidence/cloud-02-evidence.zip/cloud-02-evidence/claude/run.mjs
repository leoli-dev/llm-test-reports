import {chromium} from '~/Code/water-garden-gpt61sol/node_modules/playwright/index.mjs';
import {writeFileSync} from 'node:fs';
const OUT=process.argv[2];
const EXE='/Applications/Chromium.app/Contents/MacOS/Chromium';
const apps={
  gpt:{url:'http://127.0.0.1:5190/',scenes:{channel:'?scene=waterway',dense:'?scene=grove'},
    ready:()=>window.__garden&&window.__garden.snapshot().frames>40,
    mem:()=>{const s=window.__garden.snapshot();return {geo:s.memory.geometries,tex:s.memory.textures,calls:s.render.calls,tris:s.render.triangles,grid:s.grid.join('x'),dpr:s.viewport.dpr,maxH:s.maxHeight,energy:s.energy,finite:s.finite}}},
  opus:{url:'http://127.0.0.1:4173/',scenes:{channel:'?scene=channel',dense:'?scene=dense',peak:'?scene=peak',sparse:'?scene=sparse'},
    ready:()=>window.__wg&&window.__wg.stats&&window.__wg.stats.fps>0,
    mem:()=>{const w=window.__wg,i=w.renderer.info;let m=0;for(const h of w.sim.height)m=Math.max(m,Math.abs(h));return {geo:i.memory.geometries,tex:i.memory.textures,progs:i.programs?.length,calls:w.stats.drawCalls,tris:w.stats.triangles,grid:w.stats.simGrid,rt:w.stats.rt,dpr:w.renderer.getPixelRatio(),quality:w.qualityLevel,maxH:m,energy:w.sim.energy(),finite:w.sim.isFinite()}}},
};
const which=(process.env.APPS||'gpt,opus').split(',');
const dpr=Number(process.env.DPR||2);
const noFloatLinear=process.env.NOFLOATLINEAR==='1';
const browser=await chromium.launch({headless:true,executablePath:EXE,args:['--no-first-run','--use-angle=metal','--enable-gpu','--ignore-gpu-blocklist','--disable-gpu-vsync','--disable-frame-rate-limit']});
const report={browser:await browser.version(),dpr,noFloatLinear,results:{}};
async function fps(page,ms=5000){return page.evaluate(ms=>new Promise(res=>{const s=[];let st,l;function f(t){if(st===undefined){st=l=t;return requestAnimationFrame(f);}s.push(t-l);l=t;if(t-st>=ms){s.sort((a,b)=>a-b);const m=s.reduce((a,b)=>a+b,0)/s.length;res({frames:s.length,meanMs:+m.toFixed(2),p95Ms:+s[Math.floor(s.length*.95)].toFixed(2),fps:+(1000/m).toFixed(1)});}else requestAnimationFrame(f);}requestAnimationFrame(f);}),ms);}
for(const name of which){
  const app=apps[name];report.results[name]={};
  for(const [scene,q] of Object.entries(app.scenes)){
    const ctx=await browser.newContext({viewport:{width:1440,height:900},deviceScaleFactor:dpr});
    const page=await ctx.newPage();const errors=[],warns=[];
    page.on('pageerror',e=>errors.push(e.message));page.on('console',m=>{if(m.type()==='error')errors.push(m.text());if(m.type()==='warning')warns.push(m.text());});
    if(noFloatLinear)await page.addInitScript(()=>{const P=WebGL2RenderingContext.prototype;const ge=P.getExtension,gs=P.getSupportedExtensions;P.getExtension=function(n){return n==='OES_texture_float_linear'?null:ge.call(this,n)};P.getSupportedExtensions=function(){return gs.call(this).filter(n=>n!=='OES_texture_float_linear')};});
    await page.goto(app.url+q);
    await page.waitForFunction(app.ready,null,{timeout:30000});await page.waitForTimeout(2500);
    const tag=`${name}-${scene}${noFloatLinear?'-nofl':''}-dpr${dpr}`;
    await page.screenshot({path:`${OUT}/${tag}-idle.png`});
    const perf=await fps(page);
    const before=await page.evaluate(app.mem);
    await page.mouse.click(720,450);await page.waitForTimeout(250);
    await page.screenshot({path:`${OUT}/${tag}-click.png`});
    const afterClick=await page.evaluate(app.mem);
    await page.mouse.move(300,300);await page.mouse.down();
    for(let i=0;i<=30;i++){await page.mouse.move(300+i*28,300+Math.sin(i/5)*120);await page.waitForTimeout(16);}
    await page.mouse.up();await page.waitForTimeout(200);
    await page.screenshot({path:`${OUT}/${tag}-drag.png`});
    const perfInteract=await fps(page,2000);
    await page.waitForTimeout(8000);
    const settled=await page.evaluate(app.mem);
    report.results[name][scene]={perf,perfInteract,before,afterClick,settled,errors,warns:[...new Set(warns)].slice(0,5)};
    console.log(tag,JSON.stringify(report.results[name][scene]));
    await ctx.close();
  }
}
await browser.close();
writeFileSync(`${OUT}/report-dpr${dpr}${noFloatLinear?'-nofl':''}.json`,JSON.stringify(report,null,2));
