import {chromium} from '~/Code/water-garden-gpt61sol/node_modules/playwright/index.mjs';
const b=await chromium.launch({headless:true,executablePath:'/Applications/Chromium.app/Contents/MacOS/Chromium',args:['--use-angle=metal','--ignore-gpu-blocklist','--disable-gpu-vsync','--disable-frame-rate-limit']});
const fps=p=>p.evaluate(()=>new Promise(res=>{const s=[];let st,l;function f(t){if(st===undefined){st=l=t;return requestAnimationFrame(f);}s.push(t-l);l=t;if(t-st>=4000){const m=s.reduce((a,b)=>a+b,0)/s.length;res(+(1000/m).toFixed(1));}else requestAnimationFrame(f);}requestAnimationFrame(f);}));
const scenes={main:{gpt:'waterway',opus:'channel'},dense:{gpt:'grove',opus:'dense'}};
const rows=[];
for(const sc of ['main','dense'])for(const q of ['medium','high'])for(const rep of [1,2])for(const k of ['gpt','opus','opus','gpt']){
  const ctx=await b.newContext({viewport:{width:1440,height:900},deviceScaleFactor:2});const p=await ctx.newPage();
  await p.goto(`http://127.0.0.1:${k==='gpt'?5190:4173}/?scene=${scenes[sc][k]}&quality=${q}`);await p.waitForTimeout(2500);
  rows.push({sc,q,rep,k,fps:await fps(p)});console.log(JSON.stringify(rows.at(-1)));await ctx.close();}
await b.close();
const agg={};for(const r of rows){const key=`${r.sc}/${r.q}/${r.k}`;(agg[key]??=[]).push(r.fps);}
for(const sc of ['main','dense'])for(const q of ['medium','high']){const g=agg[`${sc}/${q}/gpt`],o=agg[`${sc}/${q}/opus`];const mg=g.reduce((a,b)=>a+b)/g.length,mo=o.reduce((a,b)=>a+b)/o.length;console.log(`SUMMARY ${sc} ${q} gpt ${mg.toFixed(0)} [${Math.min(...g)}-${Math.max(...g)}] opus ${mo.toFixed(0)} [${Math.min(...o)}-${Math.max(...o)}] ratio ${(mg/mo).toFixed(2)}`);}
