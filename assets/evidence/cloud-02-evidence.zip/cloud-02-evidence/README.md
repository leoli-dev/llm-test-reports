# CLOUD-02 evidence bundle

- `prompt.md`: the brief both models received (forwarded 2026-10-23; SHA256 of the original 9b29a27bcc4d34f5920f6344424011cab8e7d8051221b266d2382296d14fb5d0 before path generalization).
- `claude/`: Claude-mbp harness scripts (Playwright library driving `/Applications/Chromium.app`, not Google Chrome) and raw outputs: `report-dpr2.json` (per-scene click/drag/settle), `report-dpr2-nofl.json` (OES_texture_float_linear hidden), `perf.jsonl` (single-pass uncapped), `abba.log` (ABBA×2 uncapped).
- `codex/`: Codex-mbp raw outputs: `comparison-results.json`, `edge-results.json`, `stability-results.json`, `uncapped-recheck.{mjs,json}`.

Publication transformation: absolute home paths were replaced with `~`, temporary scratch paths with `<claude-scratchpad>`, and the Codex session directory with `<codex-workspace>`. No numbers were changed.
